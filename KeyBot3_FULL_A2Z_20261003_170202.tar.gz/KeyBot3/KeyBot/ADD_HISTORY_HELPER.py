from pathlib import Path

p = Path("bot.py")
s = p.read_text(encoding="utf-8")

# 1) Add helper before get_wholesale_history
if "def save_successful_key_histories(" not in s:

    marker = "def get_wholesale_history(limit=500):"

    helper = r'''
def save_successful_key_histories(
    user_id,
    product,
    duration,
    pid,
    price,
    license_key,
    order_code,
    payment_order_id=None,
):
    """Save a successful key purchase to both user and wholesale history."""

    if not license_key:
        return

    try:
        save_purchase_history(
            user_id=user_id,
            product=product,
            duration=duration,
            pid=pid,
            price=price,
            license_key=license_key,
            order_code=order_code,
            payment_order_id=payment_order_id,
        )
    except Exception:
        logging.exception("PURCHASE HISTORY SAVE ERROR")

    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()

        # Prevent duplicate wholesale-history entries
        exists = cur.execute(
            """
            SELECT id FROM wholesale_history
            WHERE order_code=?
            LIMIT 1
            """,
            (str(order_code or "N/A"),)
        ).fetchone()

        if not exists:
            cur.execute(
                """
                INSERT INTO wholesale_history
                (
                    user_id,
                    product,
                    duration,
                    pid,
                    wholesale,
                    order_code,
                    license_key,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now','localtime'))
                """,
                (
                    str(user_id),
                    str(product),
                    str(duration),
                    str(pid),
                    float(price),
                    str(order_code or "N/A"),
                    str(license_key),
                )
            )

        conn.commit()
        conn.close()

    except Exception:
        logging.exception("WHOLESALE HISTORY SAVE ERROR")

'''

    if marker not in s:
        raise RuntimeError("get_wholesale_history marker not found")

    s = s.replace(marker, helper + marker, 1)

# 2) Add call after successful ORDERS creation
needle = '''                "status": "completed",
            }

            await query.message.reply_text('''

replacement = '''                "status": "completed",
            }

            save_successful_key_histories(
                user_id=user_id,
                product=product["name"],
                duration=package.get("duration"),
                pid=pid,
                price=expected_amount,
                license_key=license_key,
                order_code=order_code,
                payment_order_id=f"purchase:{pending_order}",
            )

            await query.message.reply_text('''

if "payment_order_id=f\"purchase:{pending_order}\"" not in s:

    if needle not in s:
        raise RuntimeError("Successful purchase insertion point not found")

    s = s.replace(needle, replacement, 1)

p.write_text(s, encoding="utf-8")

print("✅ HISTORY HELPER ADDED")
print("✅ NORMAL SUCCESSFUL PURCHASE -> BOTH HISTORIES")
