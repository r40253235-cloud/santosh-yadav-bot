import os
import sqlite3
import logging
import asyncio
import requests
from datetime import datetime

from dotenv import load_dotenv
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

# =========================================================
# CONFIG
# =========================================================

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
FAMPAY_API_KEY = os.getenv("FAMPAY_API_KEY", "").strip()
UPI_ID = os.getenv("UPI_ID", "").strip()

OWNER_ID = int(os.getenv("OWNER_ID", "0"))

FAMPAY_BASE = "https://fampay.anujbots.xyz"
PANEL_API_URL = "https://www.panelstore.shop/api/v1/index.php"

DB_FILE = "keybot.db"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

# =========================================================
# DATABASE
# =========================================================

db = sqlite3.connect(DB_FILE, check_same_thread=False)
db.row_factory = sqlite3.Row

db.execute("""
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    balance REAL DEFAULT 0,
    joined_at TEXT
)
""")

db.execute("""
CREATE TABLE IF NOT EXISTS payments (
    order_id TEXT PRIMARY KEY,
    user_id INTEGER,
    amount REAL,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    paid_at TEXT
)
""")

db.execute("""
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    category TEXT,
    product_name TEXT,
    pid TEXT,
    price REAL,
    license_key TEXT,
    order_code TEXT,
    status TEXT,
    created_at TEXT
)
""")

db.execute("""
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
)
""")

db.commit()


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def register_user(user):
    db.execute("""
        INSERT INTO users
        (user_id, username, first_name, joined_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
        username=excluded.username,
        first_name=excluded.first_name
    """, (
        user.id,
        user.username or "",
        user.first_name or "",
        now(),
    ))
    db.commit()


def get_balance(user_id):
    row = db.execute(
        "SELECT balance FROM users WHERE user_id=?",
        (user_id,)
    ).fetchone()

    return float(row["balance"]) if row else 0


def add_balance(user_id, amount):
    db.execute(
        "UPDATE users SET balance=balance+? WHERE user_id=?",
        (amount, user_id)
    )
    db.commit()


def remove_balance(user_id, amount):
    db.execute(
        "UPDATE users SET balance=balance-? WHERE user_id=?",
        (amount, user_id)
    )
    db.commit()


def save_payment(order_id, user_id, amount):
    db.execute("""
        INSERT OR REPLACE INTO payments
        (order_id, user_id, amount, status, created_at)
        VALUES (?, ?, ?, 'pending', ?)
    """, (
        order_id,
        user_id,
        amount,
        now(),
    ))
    db.commit()


def get_payment(order_id):
    return db.execute(
        "SELECT * FROM payments WHERE order_id=?",
        (order_id,)
    ).fetchone()


def mark_payment_paid(order_id):
    db.execute("""
        UPDATE payments
        SET status='paid', paid_at=?
        WHERE order_id=?
    """, (now(), order_id))
    db.commit()


def get_setting(key, default=""):
    row = db.execute(
        "SELECT value FROM settings WHERE key=?",
        (key,)
    ).fetchone()

    return row["value"] if row else default


def set_setting(key, value):
    db.execute("""
        INSERT INTO settings(key, value)
        VALUES (?, ?)
        ON CONFLICT(key) DO UPDATE SET value=excluded.value
    """, (key, value))
    db.commit()


# =========================================================
# PRODUCTS
# PID अभी NONE है
# =========================================================

PRODUCTS = {
    "android_nonroot": {
        "name": "🤖 ANDROID NON ROOT PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },

    "android_root": {
        "name": "🤖 ANDROID ROOT PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },

    "iphone": {
        "name": "🍎 IPHONE PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },

    "pc": {
        "name": "💻 PC PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },
}


# =========================================================
# KEYBOARDS
# =========================================================

def home_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🛍️ Product Store", callback_data="products"),
            InlineKeyboardButton("👤 My Profile", callback_data="profile"),
        ],
        [
            InlineKeyboardButton("💰 Add Balance", callback_data="deposit"),
            InlineKeyboardButton("📜 All History", callback_data="history"),
        ],
        [
            InlineKeyboardButton("🎁 Referral", callback_data="referral"),
            InlineKeyboardButton("📚 Tutorial", callback_data="tutorial"),
        ],
        [
            InlineKeyboardButton("🆘 Support", callback_data="support"),
            InlineKeyboardButton("🎲 Ludo Spin", callback_data="ludo"),
        ],
        [
            InlineKeyboardButton("📥 Download Files", callback_data="downloads"),
        ],
    ])


def back_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("↩️ BACK", callback_data="home")]
    ])


# =========================================================
# START / HOME
# =========================================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    register_user(user)

    welcome = get_setting(
        "welcome",
        "👋 Welcome to <b>KeyBot Store</b>!\n\n"
        "🛍️ यहां से अपने products खरीदें.\n"
        "💰 पहले Add Balance से payment करें.\n\n"
        "नीचे menu से option select करें."
    )

    await update.message.reply_text(
        welcome,
        parse_mode="HTML",
        reply_markup=home_keyboard(),
    )


async def home(query):
    await query.answer()

    await query.edit_message_text(
        "🏠 <b>KEYBOT STORE</b>\n\n"
        "अपना option चुनें:",
        parse_mode="HTML",
        reply_markup=home_keyboard(),
    )


# =========================================================
# PRODUCT STORE
# =========================================================

async def products_menu(query):
    await query.answer()

    buttons = []

    for key, item in PRODUCTS.items():
        buttons.append([
            InlineKeyboardButton(
                item["name"],
                callback_data=f"category:{key}"
            )
        ])

    buttons.append([
        InlineKeyboardButton("↩️ BACK", callback_data="home")
    ])

    await query.edit_message_text(
        "🛍️ <b>PRODUCT STORE</b>\n\n"
        "अपना panel select करें:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(buttons),
    )


async def category_menu(query, category_key):
    await query.answer()

    if category_key not in PRODUCTS:
        return

    category = PRODUCTS[category_key]

    buttons = []

    for i, product in enumerate(category["products"]):
        buttons.append([
            InlineKeyboardButton(
                f"🔑 {product['name']} — ₹{product['price']}",
                callback_data=f"product:{category_key}:{i}"
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            "↩️ BACK",
            callback_data="products"
        )
    ])

    await query.edit_message_text(
        f"{category['name']}\n\n"
        "अपना plan select करें:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(buttons),
    )


async def product_details(query, category_key, index):
    await query.answer()

    try:
        product = PRODUCTS[category_key]["products"][index]
    except:
        return

    pid_text = product["pid"] if product["pid"] else "⏳ PID Pending"

    keyboard = [
        [
            InlineKeyboardButton(
                "🛒 BUY NOW",
                callback_data=f"buy:{category_key}:{index}"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data=f"category:{category_key}"
            )
        ],
    ]

    await query.edit_message_text(
        f"🔑 <b>{product['name']}</b>\n\n"
        f"💰 Price: ₹{product['price']}\n"
        f"🆔 PID: <code>{pid_text}</code>\n\n"
        "BUY NOW दबाकर आगे बढ़ें.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


# =========================================================
# PANEL STORE API
# =========================================================

def panel_order(pid, quantity, notes):
    if not pid:
        return {
            "success": False,
            "error": "PID अभी सेट नहीं है."
        }

    try:
        response = requests.post(
            PANEL_API_URL,
            json={
                "key": os.getenv("PANEL_API_KEY", ""),
                "action": "order",
                "pid": pid,
                "quantity": quantity,
                "custom_notes": notes,
            },
            timeout=20,
        )

        return response.json()

    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


def panel_balance():
    try:
        response = requests.post(
            PANEL_API_URL,
            json={
                "key": os.getenv("PANEL_API_KEY", ""),
                "action": "balance",
            },
            timeout=20,
        )

        return response.json()

    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


# =========================================================
# BUY PRODUCT
# =========================================================

async def buy_product(query, category_key, index):
    await query.answer()

    try:
        product = PRODUCTS[category_key]["products"][index]
    except:
        return

    user_id = query.from_user.id
    price = float(product["price"])
    pid = product["pid"]

    if not pid:
        await query.edit_message_text(
            "⏳ <b>PRODUCT READY नहीं है</b>\n\n"
            "इस product का PID अभी provider से नहीं मिला है.\n\n"
            "PID मिलते ही इसे activate किया जा सकता है.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "↩️ BACK",
                        callback_data=f"category:{category_key}"
                    )
                ]
            ]),
        )
        return

    balance = get_balance(user_id)

    if balance < price:
        await query.edit_message_text(
            "❌ <b>Insufficient Balance</b>\n\n"
            f"💰 Price: ₹{price}\n"
            f"💳 Your Balance: ₹{balance:.2f}\n\n"
            "पहले Add Balance करें.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "💰 ADD BALANCE",
                        callback_data="deposit"
                    )
                ],
                [
                    InlineKeyboardButton(
                        "↩️ BACK",
                        callback_data=f"category:{category_key}"
                    )
                ],
            ]),
        )
        return

    await query.edit_message_text(
        "⏳ <b>Order Processing...</b>\n\n"
        "कृपया wait करें.",
        parse_mode="HTML",
    )

    result = await asyncio.to_thread(
        panel_order,
        pid,
        1,
        f"Telegram User {user_id}"
    )

    if not result.get("success"):
        await query.edit_message_text(
            "❌ <b>Order Failed</b>\n\n"
            f"{result.get('error', 'Unknown error')}",
            parse_mode="HTML",
            reply_markup=back_keyboard(),
        )
        return

    license_key = result.get("license_key", "N/A")
    order_code = result.get("order_code", "N/A")

    remove_balance(user_id, price)

    db.execute("""
        INSERT INTO orders
        (user_id, category, product_name, pid, price,
         license_key, order_code, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        user_id,
        category_key,
        product["name"],
        pid,
        price,
        license_key,
        order_code,
        "success",
        now(),
    ))

    db.commit()

    await query.edit_message_text(
        "✅ <b>ORDER SUCCESSFUL</b>\n\n"
        f"📦 Product: {product['name']}\n"
        f"💰 Price: ₹{price}\n"
        f"🧾 Order: <code>{order_code}</code>\n\n"
        f"🔑 <b>LICENSE KEY</b>\n"
        f"<code>{license_key}</code>\n\n"
        "⚠️ इस key को सुरक्षित रखें.",
        parse_mode="HTML",
        reply_markup=back_keyboard(),
    )


# =========================================================
# DEPOSIT
# =========================================================

async def deposit_menu(query):
    await query.answer()

    await query.edit_message_text(
        "💰 <b>ADD BALANCE</b>\n\n"
        "Amount select करें:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("₹50", callback_data="deposit:50"),
                InlineKeyboardButton("₹100", callback_data="deposit:100"),
            ],
            [
                InlineKeyboardButton("₹200", callback_data="deposit:200"),
                InlineKeyboardButton("₹500", callback_data="deposit:500"),
            ],
            [
                InlineKeyboardButton("↩️ BACK", callback_data="home")
            ],
        ]),
    )


def create_qr(user_id, amount):
    try:
        response = requests.get(
            f"{FAMPAY_BASE}/qr.php",
            params={
                "upi": UPI_ID,
                "amount": amount,
            },
            timeout=20,
        )

        data = response.json()

        if not data.get("order_id"):
            return None

        save_payment(
            data["order_id"],
            user_id,
            amount
        )

        return data

    except Exception as e:
        logging.error("QR error: %s", e)
        return None


def check_payment_api(order_id):
    try:
        response = requests.get(
            f"{FAMPAY_BASE}/verify.php",
            params={
                "order_id": order_id,
                "api_key": FAMPAY_API_KEY,
            },
            timeout=20,
        )

        return response.json()

    except Exception as e:
        logging.error("Verify error: %s", e)
        return None


async def create_deposit(query, amount):
    await query.answer()

    user_id = query.from_user.id

    if not UPI_ID or not FAMPAY_API_KEY:
        await query.edit_message_text(
            "❌ Payment system अभी configured नहीं है.\n\n"
            "Admin को FAMPAY_API_KEY और UPI_ID check करना होगा.",
            reply_markup=back_keyboard(),
        )
        return

    await query.edit_message_text(
        "⏳ <b>QR Generate हो रहा है...</b>",
        parse_mode="HTML",
    )

    data = await asyncio.to_thread(
        create_qr,
        user_id,
        amount
    )

    if not data:
        await query.edit_message_text(
            "❌ QR generate नहीं हो पाया.\n\n"
            "कुछ देर बाद फिर try करें.",
            reply_markup=back_keyboard(),
        )
        return

    order_id = data.get("order_id")
    qr_url = data.get("qr_url")

    if not qr_url:
        await query.edit_message_text(
            "❌ QR URL नहीं मिला.",
            reply_markup=back_keyboard(),
        )
        return

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🔄 CHECK PAYMENT",
                callback_data=f"check_payment:{order_id}"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data="deposit"
            )
        ],
    ])

    await query.message.reply_photo(
        photo=qr_url,
        caption=(
            "💰 <b>PAYMENT REQUEST</b>\n\n"
            f"💵 Amount: ₹{amount}\n"
            f"🧾 Order ID: <code>{order_id}</code>\n\n"
            "QR scan करके payment करें.\n"
            "Payment के बाद CHECK PAYMENT दबाएँ.\n\n"
            "⏳ QR लगभग 5 मिनट valid है."
        ),
        parse_mode="HTML",
        reply_markup=keyboard,
    )

    # Automatic verification
    asyncio.create_task(
        auto_verify_payment(
            query.get_bot(),
            order_id,
            user_id,
            amount,
        )
    )


async def auto_verify_payment(bot, order_id, user_id, amount):
    for _ in range(37):
        await asyncio.sleep(8)

        payment = get_payment(order_id)

        if not payment or payment["status"] == "paid":
            return

        data = await asyncio.to_thread(
            check_payment_api,
            order_id
        )

        if not data:
            continue

        if not data.get("success"):
            continue

        verified_amount = data.get("amount")

        try:
            if verified_amount is not None:
                if float(verified_amount) != float(amount):
                    continue
        except:
            continue

        mark_payment_paid(order_id)
        add_balance(user_id, amount)

        try:
            await bot.send_message(
                chat_id=user_id,
                text=(
                    "✅ <b>PAYMENT SUCCESSFUL</b>\n\n"
                    f"💰 Amount Added: ₹{amount}\n"
                    f"💳 New Balance: ₹{get_balance(user_id):.2f}\n\n"
                    "अब Product Store से product खरीद सकते हैं."
                ),
                parse_mode="HTML",
                reply_markup=home_keyboard(),
            )
        except Exception as e:
            logging.error("Notify error: %s", e)

        return


async def verify_payment(query):
    await query.answer()

    data = query.data

    if ":" not in data:
        return

    order_id = data.split(":", 1)[1]

    payment = get_payment(order_id)

    if not payment:
        await query.answer(
            "Payment order नहीं मिला.",
            show_alert=True
        )
        return

    if payment["status"] == "paid":
        await query.answer(
            "Payment already credited.",
            show_alert=True
        )
        return

    amount = float(payment["amount"])

    await query.answer("Payment check हो रहा है...")

    result = await asyncio.to_thread(
        check_payment_api,
        order_id
    )

    if not result:
        await query.answer(
            "Verification service से connection नहीं हुआ.",
            show_alert=True
        )
        return

    if not result.get("success"):
        await query.answer(
            "Payment अभी verify नहीं हुआ.",
            show_alert=True
        )
        return

    verified_amount = result.get("amount")

    if verified_amount is not None:
        try:
            if float(verified_amount) != amount:
                await query.answer(
                    "Payment amount match नहीं करता.",
          
