import ast
from pathlib import Path

CURRENT = Path("bot.py")
NORMAL_BACKUP = Path("bot.py.before_wholesale_fix_20260909_142349")
OWNER_BACKUP = Path("bot_backup.py")

current = CURRENT.read_text(encoding="utf-8")
normal_backup = NORMAL_BACKUP.read_text(encoding="utf-8")
owner_backup = OWNER_BACKUP.read_text(encoding="utf-8")


def extract_function(source, name):
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == name:
                return "".join(lines[node.lineno - 1:node.end_lineno])

    raise RuntimeError(f"Function not found: {name}")


# ==========================================
# 1. RESTORE MISSING FUNCTIONS
# ==========================================

functions_to_add = [
    (normal_backup, "buy_product"),
    (normal_backup, "verify_payment"),
    (owner_backup, "owner_buy_product"),
    (owner_backup, "owner_confirm_purchase"),
]

marker = "async def reseller_buy_product(query, category_key, index, package_index):"

if marker not in current:
    raise RuntimeError("reseller_buy_product marker not found")

blocks = []

for source, name in functions_to_add:
    if f"async def {name}(" not in current:
        blocks.append(extract_function(source, name))

if blocks:
    current = current.replace(
        marker,
        "\n\n".join(blocks) + "\n\n" + marker,
        1
    )

# ==========================================
# 2. HISTORY HELPER
# ==========================================

if "def save_successful_key_histories(" not in current:

    helper = r'''
def save_successful_key_histories(
    user_id,
    product,
    duration,
    pid,
    price,
    license_key,
    order_code,
    payment_order_id=None,
):
    """
    Save every successful key purchase into both histories.
    Only call this after a real license key is received.
    """

    if not license_key:
        return

    uid = str(user_id)
    product = str(product or "")
    duration = str(duration or "")
    pid = str(pid or "")
    license_key = str(license_key)
    order_code = str(order_code or "N/A")
    price = float(price or 0)

    # -----------------------------
    # USER / KEY PURCHASE HISTORY
    # -----------------------------
    try:
        save_purchase_history(
            user_id=uid,
            product=product,
            duration=duration,
            pid=pid,
            price=price,
            license_key=license_key,
            order_code=order_code,
            payment_order_id=payment_order_id,
        )
    except Exception:
        logging.exception("SUCCESS PURCHASE HISTORY SAVE ERROR")

    # -----------------------------
    # WHOLESALE HISTORY
    # -----------------------------
    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()

        exists = cur.execute(
            """
            SELECT id
            FROM wholesale_history
            WHERE order_code=?
            LIMIT 1
            """,
            (order_code,)
        ).fetchone()

        if not exists:
            cur.execute(
                """
                INSERT INTO wholesale_history
                (
                    user_id,
                    product,
                    duration,
                    pid,
                    wholesale,
                    order_code,
                    license_key,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now','localtime'))
                """,
                (
                    uid,
                    product,
                    duration,
                    pid,
                    price,
                    order_code,
                    license_key,
                )
            )

        conn.commit()
        conn.close()

    except Exception:
        logging.exception("SUCCESS WHOLESALE HISTORY SAVE ERROR")
'''

    history_marker = "def get_wholesale_history(limit=500):"

    if history_marker not in current:
        raise RuntimeError("get_wholesale_history marker not found")

    current = current.replace(
        history_marker,
        helper.strip() + "\n\n\n" + history_marker,
        1
    )


# ==========================================
# 3. NORMAL SUCCESSFUL PURCHASE HOOK
# ==========================================

if "payment_order_id=f\"purchase:{pending_order}\"" not in current:

    normal_marker = '''        ORDERS[order_id] = {
                "user_id": user_id,
                "category": category_key,
                "product": product["name"],
                "duration": package.get("duration"),
                "price": expected_amount,
                "pid": pid,
                "license_key": license_key,
                "order_code": order_code,
                "payment_order_id": pending_order,
                "transaction_id": data.get("transaction_id"),
                "utr": data.get("utr"),
                "status": "completed",
            }'''

    if normal_marker not in current:
        raise RuntimeError("Normal purchase success block not found")

    history_call = '''

        save_successful_key_histories(
            user_id=user_id,
            product=product["name"],
            duration=package.get("duration"),
            pid=pid,
            price=expected_amount,
            license_key=license_key,
            order_code=order_code,
            payment_order_id=f"purchase:{pending_order}",
        )
'''

    current = current.replace(
        normal_marker,
        normal_marker + history_call,
        1
    )


# ==========================================
# 4. OWNER SUCCESSFUL PURCHASE HOOK
# ==========================================

if "OWNER SUCCESS HISTORY SAVED" not in current:

    owner_remaining = '''    remaining = (
        result.get("remaining_balance")
        or result.get("data", {}).get("remaining_balance")
    )'''

    if owner_remaining not in current:
        raise RuntimeError("Owner remaining balance block not found")

    owner_history = '''    save_successful_key_histories(
        user_id=query.from_user.id,
        product=product["name"],
        duration=package["duration"],
        pid=pid,
        price=float(wholesale),
        license_key=license_key,
        order_code=order_code,
        payment_order_id=f"wholesale:{order_code}",
    )

    logging.info(
        "OWNER SUCCESS HISTORY SAVED: user=%s order=%s",
        query.from_user.id,
        order_code,
    )

'''

    current = current.replace(
        owner_remaining,
        owner_history + owner_remaining,
        1
    )


# ==========================================
# 5. WHOLESALE HISTORY LIMIT
# ==========================================

current = current.replace(
    "rows = get_wholesale_history(30)",
    "rows = get_wholesale_history(500)"
)


# ==========================================
# WRITE
# ==========================================

CURRENT.write_text(current, encoding="utf-8")

print("==========================================")
print("✅ MASTER HISTORY RESTORE APPLIED")
print("==========================================")
print("✅ buy_product restored")
print("✅ verify_payment restored")
print("✅ owner_buy_product restored")
print("✅ owner_confirm_purchase restored")
print("✅ Normal successful purchase -> both histories")
print("✅ Owner successful purchase -> both histories")
print("✅ Reseller flow preserved")
print("✅ Duplicate wholesale order protection")
print("✅ Wholesale History: 30 -> 500")
print("==========================================")
