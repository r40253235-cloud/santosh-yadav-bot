#!/data/data/com.termux/files/usr/bin/bash

sleep 15

termux-wake-lock

cd "$HOME/KeyBot"

sv up keybot
