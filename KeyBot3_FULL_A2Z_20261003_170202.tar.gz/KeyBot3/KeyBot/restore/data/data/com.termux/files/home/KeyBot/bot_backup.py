import os
import logging
import requests

from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

# ==================================================
# CONFIG
# ==================================================

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
FAMPAY_API_KEY = os.getenv("FAMPAY_API_KEY")
UPI_ID = os.getenv("UPI_ID")
OWNER_ID = os.getenv("OWNER_ID")
PANEL_API_KEY = os.getenv("PANEL_API_KEY")

FAMPAY_BASE = "https://fampay.anujbots.xyz"
PANEL_API_URL = "https://www.panelstore.shop/api/v1/index.php"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

# ==================================================
# DATA
# ==================================================

BALANCES = {}
PAYMENTS = {}
CUSTOM_DEPOSIT_USERS = {}
ORDERS = {}

# ==================================================
# PRODUCTS
# ==================================================

PRODUCTS = {
    "android_nonroot": {
        "name": "🤖 ANDROID NON ROOT PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },

    "android_root": {
        "name": "🤖 ANDROID ROOT PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },

    "iphone": {
        "name": "🍎 IPHONE PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },

    "pc": {
        "name": "💻 PC PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },
}

# ==================================================
# BALANCE
# ==================================================

def get_balance(user_id):
    return BALANCES.get(user_id, 0)


def add_balance(user_id, amount):
    BALANCES[user_id] = get_balance(user_id) + amount


def remove_balance(user_id, amount):
    BALANCES[user_id] = max(0, get_balance(user_id) - amount)


# ==================================================
# MAIN MENU
# ==================================================

def main_menu():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🛍️ PRODUCT STORE",
                callback_data="products"
            )
        ],
        [
            InlineKeyboardButton(
                "👤 MY PROFILE",
                callback_data="profile"
            ),
            InlineKeyboardButton(
                "💰 ADD BALANCE",
                callback_data="deposit"
            )
        ],
        [
            InlineKeyboardButton(
                "📜 ALL HISTORY",
                callback_data="history"
            ),
            InlineKeyboardButton(
                "🎁 REFERRAL",
                callback_data="referral"
            )
        ],
        [
            InlineKeyboardButton(
                "📚 TUTORIAL",
                callback_data="tutorial"
            ),
            InlineKeyboardButton(
                "🆘 SUPPORT",
                callback_data="support"
            )
        ],
        [
            InlineKeyboardButton(
                "🎲 LUDO SPIN",
                callback_data="ludo"
            ),
            InlineKeyboardButton(
                "📥 DOWNLOAD FILES",
                callback_data="downloads"
            )
        ],
    ])


# ==================================================
# START
# ==================================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):

    text = (
        "✨ <b>WELCOME TO THE STORE</b> ✨\n\n"

        "🛍️ <b>Product Store</b> : "
        "All key purchase & instantly delivery\n"

        "👤 <b>My Profile</b> : "
        "Check your account information\n"

        "💰 <b>Add Balance</b> : "
        "Deposit balance & secure service\n"

        "📜 <b>All History</b> : "
        "Check all key purchase history\n"

        "🎁 <b>Referral</b> : "
        "Invite friends & earn rewards\n"

        "📚 <b>Tutorial</b> : "
        "View tutorial and work this bot\n"

        "🆘 <b>Support</b> : "
        "Bot problem fixed for support admin\n"

        "🎲 <b>Ludo Spin</b> : "
        "Demo game\n"

        "📥 <b>Download Files</b> : "
        "Download latest files for safety\n\n"

        "👇 <b>Select an option below</b>"
    )

    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=main_menu()
    )


# ==================================================
# HOME
# ==================================================

async def home(query):

    await query.answer()

    await query.edit_message_text(
        "🏠 <b>STORE HOME</b>\n\n"
        "Welcome to our digital store.\n\n"
        "👇 Select an option:",
        parse_mode="HTML",
        reply_markup=main_menu()
    )


# ==================================================
# PRODUCTS MENU
# ==================================================

async def products_menu(query):

    await query.answer()

    text = (
        "🛒 <b>SELECT PRODUCT PANEL</b>\n\n"
        "🛡️ <b>Choose a panel to view its packages:</b>"
    )

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🤖 ANDROID NON ROOT PANEL",
                callback_data="category:android_nonroot"
            )
        ],
        [
            InlineKeyboardButton(
                "🤖 ANDROID ROOT PANEL",
                callback_data="category:android_root"
            )
        ],
        [
            InlineKeyboardButton(
                "🍎 IPHONE PANEL",
                callback_data="category:iphone"
            )
        ],
        [
            InlineKeyboardButton(
                "💻 PC PANEL",
                callback_data="category:pc"
            )
        ],
        [
            InlineKeyboardButton(
                "💰 CUSTOM DEPOSIT",
                callback_data="custom_deposit"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data="home"
            )
        ],
    ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )


# ==================================================
# CATEGORY MENU
# ==================================================

async def category_menu(query, category_key):

    await query.answer()

    category = PRODUCTS.get(category_key)

    if not category:
        return

    buttons = []

    for index, product in enumerate(category["products"]):

        buttons.append([
            InlineKeyboardButton(
                f"🔑 {product['name']} — ₹{product['price']}",
                callback_data=f"product:{category_key}:{index}"
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            "↩️ BACK",
            callback_data="products"
        )
    ])

    await query.edit_message_text(
        f"{category['name']}\n\n"
        "Select your plan:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


# ==================================================
# PRODUCT DETAILS
# ==================================================

async def product_details(query, category_key, index):

    await query.answer()

    category = PRODUCTS.get(category_key)

    if not category:
        return

    try:
        product = category["products"][int(index)]
    except (ValueError, IndexError):
        return

    text = (
        "🛍️ <b>PRODUCT DETAILS</b>\n\n"
        f"📦 Category: <b>{category['name']}</b>\n"
        f"🔑 Plan: <b>{product['name']}</b>\n"
        f"💰 Price: <b>₹{product['price']}</b>\n\n"
        "⚡ Fast digital delivery\n"
        "🔐 Secure payment"
    )

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🛒 BUY NOW",
                callback_data=f"buy:{category_key}:{index}"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data=f"category:{category_key}"
            )
        ],
    ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )


# ==================================================
# BUY PRODUCT
# ==================================================

async def panel_api_order(pid, quantity=1, custom_notes=""):
    if not PANEL_API_KEY:
        raise RuntimeError("PANEL_API_KEY missing in .env")

    payload = {
        "key": PANEL_API_KEY,
        "action": "order",
        "pid": pid,
        "quantity": quantity,
        "custom_notes": custom_notes,
    }

    response = requests.post(
        PANEL_API_URL,
        json=payload,
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


async def buy_product(query, category_key, index):
    await query.answer()

    category = PRODUCTS.get(category_key)
    if not category:
        await query.message.reply_text("❌ Product category नहीं मिली।")
        return

    products = category.get("products", [])
    if index < 0 or index >= len(products):
        await query.message.reply_text("❌ Invalid product.")
        return

    product = products[index]
    pid = product.get("pid")
    price = int(product.get("price", 0))
    user_id = query.from_user.id

    if not pid:
        await query.message.reply_text(
            "⏳ <b>PRODUCT COMING SOON</b>\n\n"
            "इस product का PID अभी add नहीं किया गया है।\n\n"
            "PID मिलने के बाद automatic purchase और key delivery चालू हो जाएगी।",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💰 ADD BALANCE", callback_data="deposit")],
                [InlineKeyboardButton("↩️ HOME", callback_data="home")]
            ])
        )
        return

    balance = get_balance(user_id)

    if balance < price:
        await query.message.reply_text(
            "❌ <b>INSUFFICIENT BALANCE</b>\n\n"
            f"💰 Price: ₹{price}\n"
            f"💳 Your Balance: ₹{balance}\n\n"
            "पहले Add Balance करें।",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💰 ADD BALANCE", callback_data="deposit")],
                [InlineKeyboardButton("↩️ HOME", callback_data="home")]
            ])
        )
        return

    await query.message.reply_text(
        "⏳ <b>PROCESSING ORDER...</b>\n\n"
        "Panel Store से key generate की जा रही है।",
        parse_mode="HTML"
    )

    try:
        result = await panel_api_order(
            pid=pid,
            quantity=1,
            custom_notes=f"Telegram User ID: {user_id}"
        )

        logging.info("PANEL ORDER RESPONSE: %s", result)

        if not result.get("success", True):
            message = result.get("message", "Panel Store order failed.")
            await query.message.reply_text(
                f"❌ <b>ORDER FAILED</b>\n\n{message}",
                parse_mode="HTML"
            )
            return

        data = result.get("data", result)

        license_key = (
            data.get("license_key")
            or result.get("license_key")
            or data.get("key")
        )

        order_code = (
            data.get("order_code")
            or result.get("order_code")
            or data.get("order_id")
        )

        if not license_key:
            await query.message.reply_text(
                "❌ Order response में license key नहीं मिली।\n"
                "आपका balance नहीं काटा गया।",
                parse_mode="HTML"
            )
            return

        # API order successful होने के बाद ही user balance काटें
        remove_balance(user_id, price)

        ORDERS[order_code or f"order_{len(ORDERS)+1}"] = {
            "user_id": user_id,
            "category": category_key,
            "product": product["name"],
            "price": price,
            "pid": pid,
            "license_key": license_key,
            "order_code": order_code,
            "status": "completed",
        }

        await query.message.reply_text(
            "✅ <b>ORDER SUCCESSFUL</b>\n\n"
            f"📦 Product: <b>{product['name']}</b>\n"
            f"💵 Price: ₹{price}\n"
            f"🆔 Order: <code>{order_code or 'N/A'}</code>\n\n"
            "🔑 <b>YOUR LICENSE KEY</b>\n"
            f"<code>{license_key}</code>\n\n"
            f"💰 Remaining Balance: ₹{get_balance(user_id)}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🛍️ BUY MORE", callback_data="products")],
                [InlineKeyboardButton("↩️ HOME", callback_data="home")]
            ])
        )

    except Exception as e:
        logging.exception("PANEL ORDER ERROR: %s", e)
        await query.message.reply_text(
            "❌ <b>ORDER ERROR</b>\n\n"
            "Panel Store API से order नहीं हो पाया।\n"
            "आपका balance नहीं काटा गया।",
            parse_mode="HTML"
        )

# ==================================================
# DEPOSIT
# ==================================================

async def deposit_menu(query):
    await query.answer()

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("₹50", callback_data="deposit:50"),
            InlineKeyboardButton("₹100", callback_data="deposit:100")
        ],
        [
            InlineKeyboardButton("₹200", callback_data="deposit:200"),
            InlineKeyboardButton("₹500", callback_data="deposit:500")
        ],
        [
            InlineKeyboardButton("💰 CUSTOM DEPOSIT", callback_data="custom_deposit")
        ],
        [
            InlineKeyboardButton("↩️ BACK", callback_data="home")
        ]
    ])

    await query.edit_message_text(
        "💰 <b>ADD BALANCE</b>\n\n"
        "Select deposit amount:",
        parse_mode="HTML",
        reply_markup=keyboard
    )

# ==================================================
# CREATE QR
# ==================================================

async def custom_deposit(query):
    await query.answer()
    await query.message.reply_text(
        "💰 <b>CUSTOM DEPOSIT</b>\n\n"
        "अपना amount भेजें।\n"
        "Minimum: ₹10\n"
        "Maximum: ₹10,000\n\n"
        "Example: <code>150</code>",
        parse_mode="HTML"
    )
    context_user = query.from_user.id
    CUSTOM_DEPOSIT_USERS[context_user] = True


async def create_qr(query, amount):
    await query.answer()

    if not UPI_ID:
        await query.message.reply_text("❌ UPI ID configured नहीं है.")
        return

    try:
        response = requests.get(
            f"{FAMPAY_BASE}/qr.php",
            params={"upi": UPI_ID, "amount": amount},
            timeout=15,
        )
        response.raise_for_status()
        data = response.json()
    except Exception as e:
        logging.error("QR API ERROR: %s", e)
        await query.message.reply_text("❌ QR बनाने में error आया.")
        return

    qr_data = data.get("data", {})
    order_id = qr_data.get("order_id")
    qr_url = qr_data.get("qr_url")

    if not order_id or not qr_url:
        logging.error("INVALID QR RESPONSE: %s", data)
        await query.message.reply_text("❌ QR API ने valid QR नहीं दिया.")
        return

    user_id = query.from_user.id

    PAYMENTS[order_id] = {
        "user_id": user_id,
        "amount": amount,
        "status": "pending"
    }

    text = (
        "💰 <b>ADD BALANCE</b>\n\n"
        f"💵 Amount: <b>₹{amount}</b>\n"
        f"🆔 Order ID: <code>{order_id}</code>\n\n"
        "📲 ऊपर दिया QR scan करके payment करें.\n"
        "⏱️ QR लगभग 5 मिनट valid है.\n\n"
        "Payment के बाद नीचे CHECK PAYMENT दबाएँ."
    )

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "✅ CHECK PAYMENT",
                callback_data="check_payment"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data="deposit"
            )
        ]
    ])

    try:
        qr_response = requests.get(
            qr_url,
            timeout=15,
            headers={"User-Agent": "Mozilla/5.0"}
        )
        qr_response.raise_for_status()

        content_type = qr_response.headers.get("content-type", "").lower()

        if "image" not in content_type:
            raise ValueError(
                f"QR URL did not return image. Content-Type: {content_type}"
            )

        await query.message.reply_photo(
            photo=qr_response.content,
            caption=text,
            parse_mode="HTML",
            reply_markup=keyboard
        )

    except Exception as e:
        logging.error("QR IMAGE ERROR: %s", e)

        await query.message.reply_text(
            text + "\n\n❌ QR image Telegram पर upload नहीं हो पाई।",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "📲 OPEN QR",
                        url=qr_url
                    )
                ],
                [
                    InlineKeyboardButton(
                        "↩️ BACK",
                        callback_data="deposit"
                    )
                ]
            ])
        )


async def verify_payment(query):

    await query.answer()

    user_id = query.from_user.id
    pending_order = None

    for order_id, payment in PAYMENTS.items():

        if (
            payment.get("user_id") == user_id
            and payment.get("status") == "pending"
        ):
            pending_order = order_id
            break

    if not pending_order:

        await query.message.reply_text(
            "❌ <b>NO PENDING PAYMENT</b>\n\n"
            "पहले Add Balance से payment QR generate करें.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "💰 ADD BALANCE",
                        callback_data="deposit"
                    )
                ]
            ])
        )

        return

    if not FAMPAY_API_KEY:

        await query.message.reply_text(
            "❌ Payment API key configured नहीं है."
        )

        return

    try:

        response = requests.get(
            f"{FAMPAY_BASE}/verify.php",
            params={
                "order_id": pending_order,
                "api_key": FAMPAY_API_KEY,
            },
            timeout=15,
        )

        data = response.json()

    except Exception as e:

        logging.error("VERIFY ERROR: %s", e)

        await query.message.reply_text(
            "❌ Payment verification service से connection नहीं हो पाया."
        )

        return

    if not data.get("success"):

        await query.message.reply_text(
            "⏳ <b>PAYMENT NOT RECEIVED</b>\n\n"
            "Payment अभी detect नहीं हुआ है.\n"
            "कुछ समय wait करके फिर CHECK PAYMENT दबाएँ.",
            parse_mode="HTML"
        )

        return

    payment = PAYMENTS.get(pending_order)

    if not payment:
        return

    paid_amount = data.get("amount")
    expected_amount = payment["amount"]

    try:
        paid_amount = float(paid_amount)
        expected_amount = float(expected_amount)
    except (TypeError, ValueError):

        await query.message.reply_text(
            "❌ Payment amount verify नहीं हो पाया."
        )

        return

    if paid_amount != expected_amount:

        await query.message.reply_text(
            "❌ <b>AMOUNT MISMATCH</b>\n\n"
            f"Expected: ₹{expected_amount}\n"
            f"Received: ₹{paid_amount}",
            parse_mode="HTML"
        )

        return

    add_balance(user_id, expected_amount)

    payment["status"] = "paid"
    payment["transaction_id"] = data.get("transaction_id")
    payment["utr"] = data.get("utr")

    await query.message.reply_text(
        "✅ <b>PAYMENT SUCCESSFUL</b>\n\n"
        f"💰 Added Balance: <b>₹{expected_amount}</b>\n"
        f"💳 Current Balance: <b>₹{get_balance(user_id)}</b>\n\n"
        "🎉 आपका balance successfully add हो गया.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🛍️ PRODUCT STORE",
                    callback_data="products"
                )
            ],
            [
                InlineKeyboardButton(
                    "🏠 HOME",
                    callback_data="home"
                )
            ],
        ])
    )


# ==================================================
# PROFILE
# ==================================================

async def profile(query):

    await query.answer()

    user = query.from_user

    text = (
        "👤 <b>MY PROFILE</b>\n\n"
        f"🆔 User ID: <code>{user.id}</code>\n"
        f"👤 Name: <b>{user.first_name}</b>\n"
        f"💰 Balance: <b>₹{get_balance(user.id)}</b>\n\n"
        "🔐 Account status: Active"
    )

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="home"
                )
            ]
        ])
    )


# ==================================================
# HISTORY
# ==================================================

async def history(query):

    await query.answer()

    user_id = query.from_user.id
    payments = []

    for order_id, payment in PAYMENTS.items():

        if payment.get("user_id") == user_id:

            payments.append(
                f"💰 ₹{payment.get('amount')} — "
                f"<b>{payment.get('status', 'pending').upper()}</b>"
            )

    if payments:
        history_text = "\n".join(payments[-10:])
    else:
        history_text = "📭 अभी कोई payment history नहीं है."

    await query.edit_message_text(
        "📜 <b>ALL HISTORY</b>\n\n"
        + history_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="home"
                )
            ]
        ])
    )


# ==================================================
# REFERRAL
# ==================================================

async def referral(query):

    await query.answer()

    try:
        me = await query.get_bot().get_me()
        bot_username = me.username or ""
    except Exception:
        bot_username = ""

    user_id = query.from_user.id

    if bot_username:
        link = f"https://t.me/{bot_username}?start=ref_{user_id}"
    else:
        link = "Bot username unavailable"

    await query.edit_message_text(
        "🎁 <b>REFERRAL</b>\n\n"
        "अपने friends को invite करें.\n\n"
        f"🔗 Your referral link:\n"
        f"<code>{link}</code>\n\n"
        "🎁 Referral rewards बाद में configure किए जा सकते हैं.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="home"
                )
            ]
        ])
    )



# ==================================================
# TUTORIAL
# ==================================================

async def tutorial(query):
    await query.answer()

    await query.edit_message_text(
        "📚 <b>TUTORIAL</b>\n\n"
        "1️⃣ Product Store खोलें.\n"
        "2️⃣ Panel select करें.\n"
        "3️⃣ Plan select करें.\n"
        "4️⃣ Add Balance से payment करें.\n"
        "5️⃣ Payment verify होने के बाद अपना product खरीदें.\n\n"
        "अगर कोई समस्या आए तो 🆘 Support पर संपर्क करें.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💰 CUSTOM DEPOSIT", callback_data="custom_deposit")],
        [InlineKeyboardButton("↩️ BACK", callback_data="home")]
        ])
    )


# ==================================================
# SUPPORT
# ==================================================

async def support(query):
    await query.answer()

    await query.edit_message_text(
        "🆘 <b>SUPPORT</b>\n\n"
        "किसी भी समस्या के लिए Admin से संपर्क करें.\n\n"
        "📩 अपना Order ID और समस्या जरूर भेजें.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("↩️ BACK", callback_data="home")]
        ])
    )


# ==================================================
# LUDO SPIN
# ==================================================

async def ludo_spin(query):
    await query.answer()

    await query.edit_message_text(
        "🎲 <b>LUDO SPIN</b>\n\n"
        "यह अभी Demo Mode में है.\n"
        "💡 Real-money betting/payment अभी enabled नहीं है.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("↩️ BACK", callback_data="home")]
        ])
    )


# ==================================================
# DOWNLOAD FILES
# ==================================================

async def downloads(query):
    await query.answer()

    await query.edit_message_text(
        "📥 <b>DOWNLOAD FILES</b>\n\n"
        "अभी कोई file available नहीं है.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("↩️ BACK", callback_data="home")]
        ])
    )


# ==================================================
# BUTTON HANDLER
# ==================================================

async def handle_custom_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if user_id not in CUSTOM_DEPOSIT_USERS:
        return

    try:
        amount = int(update.message.text.strip())
    except (ValueError, AttributeError):
        await update.message.reply_text("❌ केवल amount भेजें। Example: 150")
        return

    if amount < 10 or amount > 10000:
        await update.message.reply_text(
            "❌ Amount ₹10 से ₹10,000 के बीच होना चाहिए।"
        )
        return

    CUSTOM_DEPOSIT_USERS.pop(user_id, None)

    # create_qr को callback query चाहिए, इसलिए सीधे QR flow के लिए
    # नया pending custom amount save करते हैं।
    if not UPI_ID:
        await update.message.reply_text("❌ Payment system configured नहीं है।")
        return

    try:
        response = requests.get(
            f"{FAMPAY_BASE}/qr.php",
            params={"upi": UPI_ID, "amount": amount},
            timeout=15,
        )
        data = response.json()
    except Exception as e:
        logging.error("CUSTOM QR ERROR: %s", e)
        await update.message.reply_text("❌ QR बनाने में error आया।")
        return

    qr_data = data.get("data", {})
    order_id = qr_data.get("order_id")
    qr_url = qr_data.get("qr_url")

    if not order_id or not qr_url:
        await update.message.reply_text("❌ QR API ने valid QR नहीं दिया।")
        return

    PAYMENTS[order_id] = {
        "user_id": user_id,
        "amount": amount,
        "status": "pending"
    }

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📲 OPEN QR", url=qr_url)],
        [InlineKeyboardButton("✅ CHECK PAYMENT", callback_data="check_payment")],
        [InlineKeyboardButton("↩️ BACK", callback_data="deposit")]
    ])

    await update.message.reply_text(
        "💰 <b>CUSTOM DEPOSIT</b>\n\n"
        f"💵 Amount: <b>₹{amount}</b>\n"
        f"🆔 Order ID: <code>{order_id}</code>\n\n"
        "📲 QR scan करके payment करें।\n"
        "⏱️ QR लगभग 5 मिनट valid है।\n\n"
        "Payment के बाद नीचे CHECK PAYMENT दबाएँ।",
        parse_mode="HTML",
        reply_markup=keyboard
    )


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data

    try:
        if data == "owner:home":
            if str(query.from_user.id) != str(OWNER_ID):
                await query.answer("Access Denied", show_alert=True)
                return
            await query.edit_message_text(
                "👑 <b>OWNER PANEL</b>\n\n"
                "नीचे से option चुनें:",
                parse_mode="HTML",
                reply_markup=owner_keyboard()
            )

        elif data.startswith("owner:"):
            section = data.split(":", 1)[1]
            await owner_panel(query, section)

        elif data == "home":
            await home(query)

        elif data == "products":
            await products_menu(query)

        elif data == "profile":
            await profile(query)

        elif data == "deposit":
            await deposit_menu(query)

        elif data == "custom_deposit":
            await custom_deposit(query)

        elif data.startswith("deposit:"):
            try:
                amount = int(data.split(":", 1)[1])
            except (ValueError, IndexError):
                await query.answer("Invalid amount", show_alert=True)
                return

            if amount not in (50, 100, 200, 500):
                await query.answer("Invalid amount", show_alert=True)
                return

            await create_qr(query, amount)

        elif data == "history":
            await history(query)

        elif data == "referral":
            await referral(query)

        elif data == "tutorial":
            await tutorial(query)

        elif data == "support":
            await support(query)

        elif data == "ludo":
            await ludo_spin(query)

        elif data == "downloads":
            await downloads(query)

        elif data.startswith("category:"):
            category_key = data.split(":", 1)[1]
            await category_menu(query, category_key)

        elif data.startswith("product:"):
            parts = data.split(":")
            category_key = parts[1]
            index = int(parts[2])
            await product_details(query, category_key, index)

        elif data.startswith("buy:"):
            parts = data.split(":")
            category_key = parts[1]
            index = int(parts[2])
            await buy_product(query, category_key, index)

        elif data == "check_payment":
            await verify_payment(query)

        else:
            await query.answer("Unknown button", show_alert=True)

    except Exception as e:
        logging.exception("BUTTON HANDLER ERROR: %s", e)
        try:
            await query.answer("Something went wrong", show_alert=True)
        except Exception:
            pass

# ==================================================
# MAIN
# ==================================================


async def panel_api_balance():
    if not PANEL_API_KEY:
        raise RuntimeError("PANEL_API_KEY missing in .env")

    response = requests.post(
        PANEL_API_URL,
        json={
            "key": PANEL_API_KEY,
            "action": "balance",
        },
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


def owner_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📊 DASHBOARD", callback_data="owner:dashboard"),
            InlineKeyboardButton("👥 USERS", callback_data="owner:users"),
        ],
        [
            InlineKeyboardButton("💳 PAYMENTS", callback_data="owner:payments"),
            InlineKeyboardButton("🛒 ORDERS", callback_data="owner:orders"),
        ],
        [
            InlineKeyboardButton("💰 PANEL BALANCE", callback_data="owner:panel_balance"),
            InlineKeyboardButton("📈 TOTAL", callback_data="owner:total"),
        ],
        [
            InlineKeyboardButton("📥 DOWNLOAD FILES", callback_data="owner:downloads"),
            InlineKeyboardButton("🆘 SUPPORT", callback_data="owner:support"),
        ],
        [
            InlineKeyboardButton("🔗 LINKS", callback_data="owner:links"),
            InlineKeyboardButton("⚙️ SETTINGS", callback_data="owner:settings"),
        ],
        [
            InlineKeyboardButton("❌ CLOSE", callback_data="owner:close"),
        ],
    ])


async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if str(update.effective_user.id) != str(OWNER_ID):
        await update.message.reply_text("❌ Access Denied")
        return

    await update.message.reply_text(
        "👑 <b>OWNER PANEL</b>\n\n"
        "Welcome Owner! नीचे से option चुनें:",
        parse_mode="HTML",
        reply_markup=owner_keyboard()
    )


async def owner_panel(query, section):
    await query.answer()

    if str(query.from_user.id) != str(OWNER_ID):
        await query.answer("Access Denied", show_alert=True)
        return

    if section == "dashboard":
        users = set(BALANCES.keys())
        total_balance = sum(BALANCES.values())
        orders = len(ORDERS)
        payments = len(PAYMENTS)

        text = (
            "📊 <b>OWNER DASHBOARD</b>\n\n"
            f"👥 Users: <b>{len(users)}</b>\n"
            f"🛒 Orders: <b>{orders}</b>\n"
            f"💳 Payments: <b>{payments}</b>\n"
            f"💰 User Balances Total: <b>₹{total_balance}</b>"
        )

    elif section == "users":
        text = (
            "👥 <b>USERS</b>\n\n"
            f"Total tracked users: <b>{len(BALANCES)}</b>\n\n"
            "User data अभी memory में है।"
        )

    elif section == "payments":
        pending = sum(
            1 for p in PAYMENTS.values()
            if p.get("status") == "pending"
        )
        paid = sum(
            1 for p in PAYMENTS.values()
            if p.get("status") == "paid"
        )

        text = (
            "💳 <b>PAYMENTS</b>\n\n"
            f"📌 Total: <b>{len(PAYMENTS)}</b>\n"
            f"⏳ Pending: <b>{pending}</b>\n"
            f"✅ Paid: <b>{paid}</b>"
        )

    elif section == "orders":
        completed = sum(
            1 for o in ORDERS.values()
            if o.get("status") == "completed"
        )

        text = (
            "🛒 <b>ORDERS</b>\n\n"
            f"📦 Total Orders: <b>{len(ORDERS)}</b>\n"
            f"✅ Completed: <b>{completed}</b>"
        )

    elif section == "balance":
        try:
            result = await panel_api_balance()
            logging.info("PANEL BALANCE RESPONSE: %s", result)

            data = result.get("data", result)
            balance = data.get("balance", result.get("balance"))
            currency = data.get("currency", result.get("currency", "INR"))

            text = (
                "💰 <b>PANEL STORE BALANCE</b>\n\n"
                f"Balance: <b>{balance if balance is not None else 'N/A'} {currency}</b>\n\n"
                "🌐 Connected to Panel Store API."
            )
        except Exception as e:
            logging.exception("PANEL BALANCE ERROR: %s", e)
            text = (
                "❌ <b>PANEL BALANCE ERROR</b>\n\n"
                "Panel Store API से balance नहीं मिल पाया।\n"
                "`.env` में PANEL_API_KEY check करें।"
            )

    elif section == "settings":
        text = (
            "⚙️ <b>SETTINGS</b>\n\n"
            f"👑 Owner ID: <code>{OWNER_ID}</code>\n"
            f"🌐 Panel API: <b>Connected Config</b>\n"
            f"💳 Payment API: <b>Configured</b>\n\n"
            "Product PIDs अभी बाद में add किए जाएंगे।"
        )

    else:
        text = "❌ Unknown section"

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("↩️ OWNER PANEL", callback_data="owner:home")],
        [InlineKeyboardButton("❌ CLOSE", callback_data="home")],
    ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )

def main():

    if not BOT_TOKEN:
        print("❌ BOT_TOKEN missing in .env")
        return

    app = (
        Application
        .builder()
        .token(BOT_TOKEN)
        .build()
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_custom_deposit))
    app.add_handler(CallbackQueryHandler(button_handler))

    print("🤖 Bot Started...")

    app.run_polling()


if __name__ == "__main__":
    main()
