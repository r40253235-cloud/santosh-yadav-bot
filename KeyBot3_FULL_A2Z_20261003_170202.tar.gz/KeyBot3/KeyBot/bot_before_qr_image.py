import os
import logging
import requests

from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
)

# ==================================================
# CONFIG
# ==================================================

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
FAMPAY_API_KEY = os.getenv("FAMPAY_API_KEY")
UPI_ID = os.getenv("UPI_ID")
OWNER_ID = os.getenv("OWNER_ID")

FAMPAY_BASE = "https://fampay.anujbots.xyz"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

# ==================================================
# DATA
# ==================================================

BALANCES = {}
PAYMENTS = {}
ORDERS = {}

# ==================================================
# PRODUCTS
# ==================================================

PRODUCTS = {
    "android_nonroot": {
        "name": "🤖 ANDROID NON ROOT PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },

    "android_root": {
        "name": "🤖 ANDROID ROOT PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },

    "iphone": {
        "name": "🍎 IPHONE PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },

    "pc": {
        "name": "💻 PC PANEL",
        "products": [
            {"name": "3 Days Key", "price": 50, "pid": None},
            {"name": "7 Days Key", "price": 100, "pid": None},
        ],
    },
}

# ==================================================
# BALANCE
# ==================================================

def get_balance(user_id):
    return BALANCES.get(user_id, 0)


def add_balance(user_id, amount):
    BALANCES[user_id] = get_balance(user_id) + amount


def remove_balance(user_id, amount):
    BALANCES[user_id] = max(0, get_balance(user_id) - amount)


# ==================================================
# MAIN MENU
# ==================================================

def main_menu():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🛍️ PRODUCT STORE",
                callback_data="products"
            )
        ],
        [
            InlineKeyboardButton(
                "👤 MY PROFILE",
                callback_data="profile"
            ),
            InlineKeyboardButton(
                "💰 ADD BALANCE",
                callback_data="deposit"
            )
        ],
        [
            InlineKeyboardButton(
                "📜 ALL HISTORY",
                callback_data="history"
            ),
            InlineKeyboardButton(
                "🎁 REFERRAL",
                callback_data="referral"
            )
        ],
        [
            InlineKeyboardButton(
                "📚 TUTORIAL",
                callback_data="tutorial"
            ),
            InlineKeyboardButton(
                "🆘 SUPPORT",
                callback_data="support"
            )
        ],
        [
            InlineKeyboardButton(
                "🎲 LUDO SPIN",
                callback_data="ludo"
            ),
            InlineKeyboardButton(
                "📥 DOWNLOAD FILES",
                callback_data="downloads"
            )
        ],
    ])


# ==================================================
# START
# ==================================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):

    text = (
        "✨ <b>WELCOME TO THE STORE</b> ✨\n\n"

        "🛍️ <b>Product Store</b> : "
        "All key purchase & instantly delivery\n"

        "👤 <b>My Profile</b> : "
        "Check your account information\n"

        "💰 <b>Add Balance</b> : "
        "Deposit balance & secure service\n"

        "📜 <b>All History</b> : "
        "Check all key purchase history\n"

        "🎁 <b>Referral</b> : "
        "Invite friends & earn rewards\n"

        "📚 <b>Tutorial</b> : "
        "View tutorial and work this bot\n"

        "🆘 <b>Support</b> : "
        "Bot problem fixed for support admin\n"

        "🎲 <b>Ludo Spin</b> : "
        "Demo game\n"

        "📥 <b>Download Files</b> : "
        "Download latest files for safety\n\n"

        "👇 <b>Select an option below</b>"
    )

    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=main_menu()
    )


# ==================================================
# HOME
# ==================================================

async def home(query):

    await query.answer()

    await query.edit_message_text(
        "🏠 <b>STORE HOME</b>\n\n"
        "Welcome to our digital store.\n\n"
        "👇 Select an option:",
        parse_mode="HTML",
        reply_markup=main_menu()
    )


# ==================================================
# PRODUCTS MENU
# ==================================================

async def products_menu(query):

    await query.answer()

    text = (
        "🛒 <b>SELECT PRODUCT PANEL</b>\n\n"
        "🛡️ <b>Choose a panel to view its packages:</b>"
    )

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🤖 ANDROID NON ROOT PANEL",
                callback_data="category:android_nonroot"
            )
        ],
        [
            InlineKeyboardButton(
                "🤖 ANDROID ROOT PANEL",
                callback_data="category:android_root"
            )
        ],
        [
            InlineKeyboardButton(
                "🍎 IPHONE PANEL",
                callback_data="category:iphone"
            )
        ],
        [
            InlineKeyboardButton(
                "💻 PC PANEL",
                callback_data="category:pc"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data="home"
            )
        ],
    ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )


# ==================================================
# CATEGORY MENU
# ==================================================

async def category_menu(query, category_key):

    await query.answer()

    category = PRODUCTS.get(category_key)

    if not category:
        return

    buttons = []

    for index, product in enumerate(category["products"]):

        buttons.append([
            InlineKeyboardButton(
                f"🔑 {product['name']} — ₹{product['price']}",
                callback_data=f"product:{category_key}:{index}"
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            "↩️ BACK",
            callback_data="products"
        )
    ])

    await query.edit_message_text(
        f"{category['name']}\n\n"
        "Select your plan:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


# ==================================================
# PRODUCT DETAILS
# ==================================================

async def product_details(query, category_key, index):

    await query.answer()

    category = PRODUCTS.get(category_key)

    if not category:
        return

    try:
        product = category["products"][int(index)]
    except (ValueError, IndexError):
        return

    text = (
        "🛍️ <b>PRODUCT DETAILS</b>\n\n"
        f"📦 Category: <b>{category['name']}</b>\n"
        f"🔑 Plan: <b>{product['name']}</b>\n"
        f"💰 Price: <b>₹{product['price']}</b>\n\n"
        "⚡ Fast digital delivery\n"
        "🔐 Secure payment"
    )

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🛒 BUY NOW",
                callback_data=f"buy:{category_key}:{index}"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data=f"category:{category_key}"
            )
        ],
    ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )


# ==================================================
# BUY PRODUCT
# ==================================================

async def buy_product(query, category_key, index):

    await query.answer()

    category = PRODUCTS.get(category_key)

    if not category:
        return

    try:
        product = category["products"][int(index)]
    except (ValueError, IndexError):
        return

    pid = product.get("pid")

    if pid is None:

        await query.message.reply_text(
            "⏳ <b>PRODUCT COMING SOON</b>\n\n"
            "इस product का PID अभी add नहीं किया गया है.\n\n"
            "PID मिलने के बाद automatic purchase "
            "और key delivery connect होगी.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "💰 ADD BALANCE",
                        callback_data="deposit"
                    )
                ],
                [
                    InlineKeyboardButton(
                        "↩️ HOME",
                        callback_data="home"
                    )
                ],
            ])
        )

        return

    price = product["price"]
    user_id = query.from_user.id
    balance = get_balance(user_id)

    if balance < price:

        await query.message.reply_text(
            "❌ <b>INSUFFICIENT BALANCE</b>\n\n"
            f"💰 Price: ₹{price}\n"
            f"💳 Your Balance: ₹{balance}\n\n"
            "पहले Add Balance करें.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "💰 ADD BALANCE",
                        callback_data="deposit"
                    )
                ]
            ])
        )

        return

    await query.message.reply_text(
        "⏳ <b>ORDER SYSTEM</b>\n\n"
        "PID configured है, लेकिन Panel Store का "
        "order API endpoint अभी connect नहीं है.\n\n"
        "API details मिलने के बाद automatic order "
        "और key delivery यहाँ connect की जाएगी.",
        parse_mode="HTML"
    )


# ==================================================
# DEPOSIT
# ==================================================

async def deposit_menu(query):

    await query.answer()

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "₹50",
                callback_data="deposit:50"
            ),
            InlineKeyboardButton(
                "₹100",
                callback_data="deposit:100"
            ),
        ],
        [
            InlineKeyboardButton(
                "₹200",
                callback_data="deposit:200"
            ),
            InlineKeyboardButton(
                "₹500",
                callback_data="deposit:500"
            ),
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data="home"
            )
        ],
    ])

    await query.edit_message_text(
        "💰 <b>ADD BALANCE</b>\n\n"
        "Select deposit amount:",
        parse_mode="HTML",
        reply_markup=keyboard
    )


# ==================================================
# CREATE QR
# ==================================================

async def create_qr(query, amount):

    await query.answer()

    if not UPI_ID:

        await query.message.reply_text(
            "❌ UPI ID .env में configured नहीं है."
        )

        return

    try:

        response = requests.get(
            f"{FAMPAY_BASE}/qr.php",
            params={
                "upi": UPI_ID,
                "amount": amount,
            },
            timeout=15,
        )

        data = response.json()

    except Exception as e:

        logging.error("QR ERROR: %s", e)

        await query.message.reply_text(
            "❌ QR generate नहीं हो पाया.\n"
            "थोड़ी देर बाद फिर try करें."
        )

        return

    qr_data = data.get("data", {})
    order_id = qr_data.get("order_id")
    qr_url = qr_data.get("qr_url")

    if not order_id or not qr_url:

        await query.message.reply_text(
            "❌ QR API ने valid response नहीं दिया."
        )

        return

    user_id = query.from_user.id

    PAYMENTS[order_id] = {
        "user_id": user_id,
        "amount": amount,
        "status": "pending",
    }

    text = (
        "💰 <b>ADD BALANCE</b>\n\n"
        f"💵 Amount: <b>₹{amount}</b>\n"
        f"🆔 Order ID: <code>{order_id}</code>\n\n"
        "📲 QR scan करके payment करें.\n"
        "⏱️ QR लगभग 5 मिनट valid है.\n\n"
        "Payment करने के बाद नीचे CHECK PAYMENT दबाएँ."
    )

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "📲 OPEN QR",
                url=qr_url
            )
        ],
        [
            InlineKeyboardButton(
                "✅ CHECK PAYMENT",
                callback_data="check_payment"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data="deposit"
            )
        ],
    ])

    await query.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )


# ==================================================
# VERIFY PAYMENT
# ==================================================

async def verify_payment(query):

    await query.answer()

    user_id = query.from_user.id
    pending_order = None

    for order_id, payment in PAYMENTS.items():

        if (
            payment.get("user_id") == user_id
            and payment.get("status") == "pending"
        ):
            pending_order = order_id
            break

    if not pending_order:

        await query.message.reply_text(
            "❌ <b>NO PENDING PAYMENT</b>\n\n"
            "पहले Add Balance से payment QR generate करें.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "💰 ADD BALANCE",
                        callback_data="deposit"
                    )
                ]
            ])
        )

        return

    if not FAMPAY_API_KEY:

        await query.message.reply_text(
            "❌ Payment API key configured नहीं है."
        )

        return

    try:

        response = requests.get(
            f"{FAMPAY_BASE}/verify.php",
            params={
                "order_id": pending_order,
                "api_key": FAMPAY_API_KEY,
            },
            timeout=15,
        )

        data = response.json()

    except Exception as e:

        logging.error("VERIFY ERROR: %s", e)

        await query.message.reply_text(
            "❌ Payment verification service से connection नहीं हो पाया."
        )

        return

    if not data.get("success"):

        await query.message.reply_text(
            "⏳ <b>PAYMENT NOT RECEIVED</b>\n\n"
            "Payment अभी detect नहीं हुआ है.\n"
            "कुछ समय wait करके फिर CHECK PAYMENT दबाएँ.",
            parse_mode="HTML"
        )

        return

    payment = PAYMENTS.get(pending_order)

    if not payment:
        return

    paid_amount = data.get("amount")
    expected_amount = payment["amount"]

    try:
        paid_amount = float(paid_amount)
        expected_amount = float(expected_amount)
    except (TypeError, ValueError):

        await query.message.reply_text(
            "❌ Payment amount verify नहीं हो पाया."
        )

        return

    if paid_amount != expected_amount:

        await query.message.reply_text(
            "❌ <b>AMOUNT MISMATCH</b>\n\n"
            f"Expected: ₹{expected_amount}\n"
            f"Received: ₹{paid_amount}",
            parse_mode="HTML"
        )

        return

    add_balance(user_id, expected_amount)

    payment["status"] = "paid"
    payment["transaction_id"] = data.get("transaction_id")
    payment["utr"] = data.get("utr")

    await query.message.reply_text(
        "✅ <b>PAYMENT SUCCESSFUL</b>\n\n"
        f"💰 Added Balance: <b>₹{expected_amount}</b>\n"
        f"💳 Current Balance: <b>₹{get_balance(user_id)}</b>\n\n"
        "🎉 आपका balance successfully add हो गया.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🛍️ PRODUCT STORE",
                    callback_data="products"
                )
            ],
            [
                InlineKeyboardButton(
                    "🏠 HOME",
                    callback_data="home"
                )
            ],
        ])
    )


# ==================================================
# PROFILE
# ==================================================

async def profile(query):

    await query.answer()

    user = query.from_user

    text = (
        "👤 <b>MY PROFILE</b>\n\n"
        f"🆔 User ID: <code>{user.id}</code>\n"
        f"👤 Name: <b>{user.first_name}</b>\n"
        f"💰 Balance: <b>₹{get_balance(user.id)}</b>\n\n"
        "🔐 Account status: Active"
    )

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="home"
                )
            ]
        ])
    )


# ==================================================
# HISTORY
# ==================================================

async def history(query):

    await query.answer()

    user_id = query.from_user.id
    payments = []

    for order_id, payment in PAYMENTS.items():

        if payment.get("user_id") == user_id:

            payments.append(
                f"💰 ₹{payment.get('amount')} — "
                f"<b>{payment.get('status', 'pending').upper()}</b>"
            )

    if payments:
        history_text = "\n".join(payments[-10:])
    else:
        history_text = "📭 अभी कोई payment history नहीं है."

    await query.edit_message_text(
        "📜 <b>ALL HISTORY</b>\n\n"
        + history_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="home"
                )
            ]
        ])
    )


# ==================================================
# REFERRAL
# ==================================================

async def referral(query):

    await query.answer()

    try:
        me = await query.get_bot().get_me()
        bot_username = me.username or ""
    except Exception:
        bot_username = ""

    user_id = query.from_user.id

    if bot_username:
        link = f"https://t.me/{bot_username}?start=ref_{user_id}"
    else:
        link = "Bot username unavailable"

    await query.edit_message_text(
        "🎁 <b>REFERRAL</b>\n\n"
        "अपने friends को invite करें.\n\n"
        f"🔗 Your referral link:\n"
        f"<code>{link}</code>\n\n"
        "🎁 Referral rewards बाद में configure किए जा सकते हैं.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="home"
                )
            ]
        ])
    )



# ==================================================
# TUTORIAL
# ==================================================

async def tutorial(query):
    await query.answer()

    await query.edit_message_text(
        "📚 <b>TUTORIAL</b>\n\n"
        "1️⃣ Product Store खोलें.\n"
        "2️⃣ Panel select करें.\n"
        "3️⃣ Plan select करें.\n"
        "4️⃣ Add Balance से payment करें.\n"
        "5️⃣ Payment verify होने के बाद अपना product खरीदें.\n\n"
        "अगर कोई समस्या आए तो 🆘 Support पर संपर्क करें.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("↩️ BACK", callback_data="home")]
        ])
    )


# ==================================================
# SUPPORT
# ==================================================

async def support(query):
    await query.answer()

    await query.edit_message_text(
        "🆘 <b>SUPPORT</b>\n\n"
        "किसी भी समस्या के लिए Admin से संपर्क करें.\n\n"
        "📩 अपना Order ID और समस्या जरूर भेजें.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("↩️ BACK", callback_data="home")]
        ])
    )


# ==================================================
# LUDO SPIN
# ==================================================

async def ludo_spin(query):
    await query.answer()

    await query.edit_message_text(
        "🎲 <b>LUDO SPIN</b>\n\n"
        "यह अभी Demo Mode में है.\n"
        "💡 Real-money betting/payment अभी enabled नहीं है.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("↩️ BACK", callback_data="home")]
        ])
    )


# ==================================================
# DOWNLOAD FILES
# ==================================================

async def downloads(query):
    await query.answer()

    await query.edit_message_text(
        "📥 <b>DOWNLOAD FILES</b>\n\n"
        "अभी कोई file available नहीं है.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("↩️ BACK", callback_data="home")]
        ])
    )


# ==================================================
# BUTTON HANDLER
# ==================================================

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data

    if data == "home":
        await home(query)

    elif data == "products":
        await products_menu(query)

    elif data == "profile":
        await profile(query)

    elif data == "deposit":
        await deposit_menu(query)

    elif data == "history":
        await history(query)

    elif data == "referral":
        await referral(query)

    elif data == "tutorial":
        await tutorial(query)

    elif data == "support":
        await support(query)

    elif data == "ludo":
        await ludo_spin(query)

    elif data == "downloads":
        await downloads(query)

    elif data.startswith("category:"):
        category_key = data.split(":", 1)[1]
        await category_menu(query, category_key)

    elif data.startswith("product:"):
        parts = data.split(":")
        category_key = parts[1]
        index = int(parts[2])
        await product_details(query, category_key, index)

    elif data.startswith("buy:"):
        parts = data.split(":")
        category_key = parts[1]
        index = int(parts[2])
        await buy_product(query, category_key, index)

    elif data == "check_payment":
        await verify_payment(query)


# ==================================================
# MAIN
# ==================================================


async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if str(update.effective_user.id) != str(OWNER_ID):
        await update.message.reply_text("Access Denied")
        return

    await update.message.reply_text(
        "OWNER PANEL\n\n"
        "Dashboard\n"
        "Users\n"
        "Payments\n"
        "Orders\n"
        "Balance\n"
        "Settings"
    )

def main():

    if not BOT_TOKEN:
        print("❌ BOT_TOKEN missing in .env")
        return

    app = (
        Application
        .builder()
        .token(BOT_TOKEN)
        .build()
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(CallbackQueryHandler(button_handler))

    print("🤖 Bot Started...")

    app.run_polling()


if __name__ == "__main__":
    main()
