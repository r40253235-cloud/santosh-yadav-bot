#!/data/data/com.termux/files/usr/bin/bash

cd "$(dirname "$0")"

echo ""
echo "========================================"
echo "   🔒 KEYBOT AUTO-RESTART SYSTEM"
echo "========================================"
echo "🤖 यह bot हमेशा चलने के लिए configured है।"
echo "🛠️ कोई समस्या आए तो bot अपने-आप restart होगा।"
echo "🔄 bot.py बदलने पर नया code automatically load होगा।"
echo "⚠️ Bot को manually बंद न करें। समस्या हो तो code ठीक करें।"
echo "========================================"
echo ""

LAST_MTIME=""

while true
do
    CURRENT_MTIME=$(stat -c %Y bot.py 2>/dev/null)

    if [ "$CURRENT_MTIME" != "$LAST_MTIME" ]; then
        if [ -n "$LAST_MTIME" ]; then
            echo ""
            echo "📝 bot.py में बदलाव मिला — bot restart हो रहा है..."
            sleep 2
        fi

        LAST_MTIME="$CURRENT_MTIME"

        echo "🔍 Syntax check..."
        if python -m py_compile bot.py; then
            echo "✅ Syntax OK"
        else
            echo "❌ Syntax error — पुराना bot process बंद नहीं किया जाएगा।"
            echo "🛠️ bot.py ठीक करके save करो।"
            sleep 5
            continue
        fi
    fi

    echo "🚀 Starting KeyBot..."

    python bot.py
    EXIT_CODE=$?

    echo ""
    echo "⚠️ KeyBot stopped/crashed. Exit code: $EXIT_CODE"
    echo "🔄 3 seconds में automatic restart..."
    sleep 3
done
