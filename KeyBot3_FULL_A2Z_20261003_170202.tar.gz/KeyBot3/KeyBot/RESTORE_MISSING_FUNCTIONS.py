import ast
from pathlib import Path

current_file = Path("bot.py")
normal_backup = Path("bot.py.before_wholesale_fix_20260909_142349")
owner_backup = Path("bot_backup.py")

current = current_file.read_text(encoding="utf-8")
normal = normal_backup.read_text(encoding="utf-8")
owner = owner_backup.read_text(encoding="utf-8")


def get_function(source, name):
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == name:
                return "".join(lines[node.lineno - 1:node.end_lineno])

    raise RuntimeError("Function not found: " + name)


functions = [
    (normal, "buy_product"),
    (normal, "verify_payment"),
    (owner, "owner_buy_product"),
    (owner, "owner_confirm_purchase"),
]

marker = "async def reseller_buy_product(query, category_key, index, package_index):"

if marker not in current:
    raise RuntimeError("reseller_buy_product marker not found")

added = []

for source, name in functions:
    if f"async def {name}(" not in current:
        added.append(get_function(source, name))

if added:
    current = current.replace(
        marker,
        "\n\n".join(added) + "\n\n" + marker,
        1
    )

current_file.write_text(current, encoding="utf-8")

print("✅ Missing functions restored:")
print("   • buy_product")
print("   • verify_payment")
print("   • owner_buy_product")
print("   • owner_confirm_purchase")
