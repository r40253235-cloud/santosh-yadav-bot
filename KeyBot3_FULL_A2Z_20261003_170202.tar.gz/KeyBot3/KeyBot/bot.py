import asyncio
import fcntl
import sqlite3
from pathlib import Path
import os
import logging
import requests
import time

from dotenv import load_dotenv
load_dotenv(dotenv_path=Path(__file__).resolve().parent / '.env')
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove, ForceReply
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    filters,
    ExtBot,
)

# ==================================================
# CONFIG
# ==================================================

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
FAMPAY_API_KEY = os.getenv("FAMPAY_API_KEY")
UPI_ID = os.getenv("UPI_ID")
OWNER_ID = os.getenv("OWNER_ID")
PANEL_API_KEY = os.getenv("PANEL_API_KEY")

FAMPAY_BASE = "https://fampay.anujbots.xyz"
PANEL_API_URL = "https://www.panelstore.shop/api/v1/index.php"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

# ==================================================
# DATA
# ==================================================

BALANCES = {}
USERS = set()
RESELLERS = set()
RESELLER_VALIDITY = 30 * 24 * 60 * 60

def init_reseller_db():
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS reseller_users "
        "(user_id TEXT PRIMARY KEY, activated_at REAL NOT NULL)"
    )
    conn.commit()
    conn.close()

def activate_reseller(user_id):
    uid = str(user_id)
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "INSERT OR REPLACE INTO reseller_users (user_id, activated_at) VALUES (?, ?)",
        (uid, time.time())
    )
    conn.commit()
    conn.close()
    RESELLERS.add(uid)

def get_reseller_total_saved(user_id):
    uid = str(user_id)
    total_saved = 0.0

    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute(
            "SELECT pid, duration, wholesale FROM wholesale_history WHERE user_id=?",
            (uid,)
        )
        rows = cur.fetchall()
        conn.close()
    except sqlite3.Error:
        return 0.0

    for pid, duration, wholesale in rows:
        for category in PRODUCTS.values():
            for product in category.get("products", []):
                for package in product.get("packages", []):
                    package_pid = package.get("pid") or product.get("pid")
                    if str(package_pid) == str(pid) and package.get("duration") == duration:
                        retail = float(package.get("price", 0))
                        total_saved += max(0.0, retail - float(wholesale))
                        break

    return total_saved


def get_reseller_activation(user_id):
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "SELECT activated_at FROM reseller_users WHERE user_id=?",
        (str(user_id),)
    )
    row = cur.fetchone()
    conn.close()
    return row[0] if row else None

def is_reseller_active(user_id):
    activated_at = get_reseller_activation(user_id)

    if not activated_at:
        RESELLERS.discard(str(user_id))
        return False

    if time.time() - float(activated_at) >= RESELLER_VALIDITY:
        RESELLERS.discard(str(user_id))
        return False

    RESELLERS.add(str(user_id))
    return True

init_reseller_db()
PAYMENTS = {}
PAYMENT_UTR_USERS = {}

# ==================================================
# PAYMENT / WALLET DATABASE
# ==================================================

def init_payment_db():
    conn = sqlite3.connect("keybot.db", timeout=30)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS wallets (
            user_id TEXT PRIMARY KEY,
            balance REAL NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS payment_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id TEXT NOT NULL UNIQUE,
            user_id TEXT NOT NULL,
            requested_amount REAL NOT NULL,
            verified_amount REAL,
            submitted_utr TEXT,
            verified_utr TEXT,
            transaction_id TEXT,
            payment_type TEXT NOT NULL DEFAULT 'deposit',
            status TEXT NOT NULL DEFAULT 'PENDING',
            credited INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            message_id INTEGER
        )
    """)
    cur.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS idx_payment_verified_utr
        ON payment_transactions(verified_utr)
        WHERE verified_utr IS NOT NULL AND verified_utr <> ''
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS wallet_ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            entry_type TEXT NOT NULL,
            amount REAL NOT NULL,
            balance_before REAL NOT NULL,
            balance_after REAL NOT NULL,
            reference TEXT,
            order_id TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
        )
    """)
    conn.commit()
    conn.close()


def load_balances_from_db():
    try:
        conn = sqlite3.connect("keybot.db", timeout=30)
        rows = conn.execute("SELECT user_id, balance FROM wallets").fetchall()
        conn.close()
        for uid, balance in rows:
            try:
                BALANCES[int(uid)] = float(balance)
            except (TypeError, ValueError):
                BALANCES[uid] = float(balance)
    except sqlite3.Error:
        logging.exception("WALLET LOAD ERROR")


def get_balance(user_id):
    uid = str(user_id)
    try:
        conn = sqlite3.connect("keybot.db", timeout=30)
        row = conn.execute("SELECT balance FROM wallets WHERE user_id=?", (uid,)).fetchone()
        conn.close()
        if row is not None:
            balance = float(row[0])
            try:
                BALANCES[int(user_id)] = balance
            except Exception:
                BALANCES[user_id] = balance
            return balance
    except sqlite3.Error:
        logging.exception("GET BALANCE ERROR")
    return float(BALANCES.get(user_id, 0) or 0)


def add_balance(user_id, amount, reference=None, order_id=None):
    amount = float(amount)
    if amount <= 0:
        raise ValueError("Balance amount must be positive")
    uid = str(user_id)
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT balance FROM wallets WHERE user_id=?", (uid,)).fetchone()
        before = float(row[0]) if row else 0.0
        after = before + amount
        conn.execute(
            "INSERT INTO wallets(user_id,balance,updated_at) VALUES(?,?,datetime('now','localtime')) "
            "ON CONFLICT(user_id) DO UPDATE SET balance=excluded.balance, updated_at=excluded.updated_at",
            (uid, after),
        )
        conn.execute(
            "INSERT INTO wallet_ledger(user_id,entry_type,amount,balance_before,balance_after,reference,order_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (uid, "CREDIT", amount, before, after, reference, order_id),
        )
        conn.commit()
        BALANCES[user_id] = after
        return after
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def remove_balance(user_id, amount):
    amount = float(amount)
    if amount <= 0:
        return get_balance(user_id)
    uid = str(user_id)
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT balance FROM wallets WHERE user_id=?", (uid,)).fetchone()
        before = float(row[0]) if row else 0.0
        after = max(0.0, before - amount)
        conn.execute(
            "INSERT INTO wallets(user_id,balance,updated_at) VALUES(?,?,datetime('now','localtime')) "
            "ON CONFLICT(user_id) DO UPDATE SET balance=excluded.balance, updated_at=excluded.updated_at",
            (uid, after),
        )
        conn.execute(
            "INSERT INTO wallet_ledger(user_id,entry_type,amount,balance_before,balance_after,reference,order_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (uid, "DEBIT", before-after, before, after, "manual/product debit", None),
        )
        conn.commit()
        BALANCES[user_id] = after
        return after
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def save_payment_order(order_id, user_id, amount, payment_type="deposit", message_id=None):
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute(
            "INSERT INTO payment_transactions "
            "(order_id,user_id,requested_amount,payment_type,status,message_id) "
            "VALUES(?,?,?,?,?,?)",
            (str(order_id), str(user_id), float(amount), payment_type, "PENDING", message_id),
        )
        conn.commit()
    finally:
        conn.close()


def update_payment_order(order_id, **fields):
    allowed = {
        "submitted_utr", "verified_utr", "transaction_id", "verified_amount",
        "status", "credited", "message_id"
    }
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return
    fields["updated_at"] = "__NOW__"
    sets = []
    values = []
    for key, value in fields.items():
        if value == "__NOW__":
            sets.append("updated_at=datetime('now','localtime')")
        else:
            sets.append(f"{key}=?")
            values.append(value)
    values.append(str(order_id))
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute(f"UPDATE payment_transactions SET {', '.join(sets)} WHERE order_id=?", values)
        conn.commit()
    finally:
        conn.close()


def get_payment_order(order_id):
    conn = sqlite3.connect("keybot.db", timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute("SELECT * FROM payment_transactions WHERE order_id=?", (str(order_id),)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def find_pending_payment(user_id):
    # Prefer the in-memory record while the bot is running because purchase/reseller
    # payments also carry product metadata there. DB is the restart-safe fallback.
    for order_id, payment in reversed(list(PAYMENTS.items())):
        if payment.get("user_id") == user_id and payment.get("status") in ("pending", "verifying"):
            row = get_payment_order(order_id) or {}
            return {**row, "order_id": order_id, **payment}

    conn = sqlite3.connect("keybot.db", timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            "SELECT * FROM payment_transactions WHERE user_id=? AND status IN ('PENDING','VERIFYING') "
            "ORDER BY id DESC LIMIT 1",
            (str(user_id),),
        ).fetchone()
        if row:
            return dict(row)
    finally:
        conn.close()
    return None


def claim_and_credit_deposit(order_id, user_id, amount, verified_utr, transaction_id):
    """Atomically credit one verified payment exactly once."""
    uid = str(user_id)
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute(
            "SELECT user_id, requested_amount, credited, status, verified_utr FROM payment_transactions WHERE order_id=?",
            (str(order_id),),
        ).fetchone()
        if not row:
            raise ValueError("Payment order not found")
        db_uid, requested, credited, status, old_utr = row
        if str(db_uid) != uid:
            raise ValueError("Payment owner mismatch")
        if int(credited) == 1:
            return False, "already_credited", None
        if status == "SUCCESS" and old_utr:
            return False, "already_processed", None

        # UTR can never credit two different orders.
        dup = conn.execute(
            "SELECT order_id, user_id FROM payment_transactions "
            "WHERE verified_utr=? AND order_id<>? LIMIT 1",
            (str(verified_utr), str(order_id)),
        ).fetchone()
        if dup:
            return False, "duplicate_utr", None

        wallet = conn.execute("SELECT balance FROM wallets WHERE user_id=?", (uid,)).fetchone()
        before = float(wallet[0]) if wallet else 0.0
        after = before + float(amount)
        conn.execute(
            "INSERT INTO wallets(user_id,balance,updated_at) VALUES(?,?,datetime('now','localtime')) "
            "ON CONFLICT(user_id) DO UPDATE SET balance=excluded.balance, updated_at=excluded.updated_at",
            (uid, after),
        )
        conn.execute(
            "INSERT INTO wallet_ledger(user_id,entry_type,amount,balance_before,balance_after,reference,order_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (uid, "CREDIT", float(amount), before, after, "Fampay verified payment", str(order_id)),
        )
        conn.execute(
            "UPDATE payment_transactions SET verified_amount=?, verified_utr=?, transaction_id=?, "
            "status='SUCCESS', credited=1, updated_at=datetime('now','localtime') WHERE order_id=? AND credited=0",
            (float(amount), str(verified_utr), str(transaction_id or ""), str(order_id)),
        )
        conn.commit()
        BALANCES[user_id] = after
        return True, "credited", after
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

init_payment_db()
load_balances_from_db()

async def expire_qr_message(bot, user_id, order_id):
    try:
        await asyncio.sleep(300)

        payment = PAYMENTS.get(order_id)
        if not payment or payment.get("status") != "pending":
            return

        payment["status"] = "expired"
        try:
            update_payment_order(order_id, status="EXPIRED")
        except Exception:
            logging.exception("PAYMENT DB EXPIRY UPDATE ERROR")
        message_id = payment.get("message_id")

        if not message_id:
            return

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="deposit",
                    style="danger"
                )
            ]
        ])

        # 5 minutes complete: remove the QR completely
        try:
            await bot.delete_message(
                chat_id=user_id,
                message_id=message_id
            )
        except Exception:
            logging.exception("QR MESSAGE DELETE ERROR")

        await bot.send_message(
            chat_id=user_id,
            text=(
                "⌛ <b>QR CODE EXPIRED</b>\n\n"
                "यह QR Code 5 मिनट के बाद expire हो गया है।\n"
                "💳 इस QR पर अब payment न करें।\n\n"
                "नीचे से नया QR generate करें।"
            ),
            parse_mode="HTML",
            reply_markup=keyboard
        )

    except Exception:
        logging.exception("QR AUTO EXPIRY EDIT ERROR")

CUSTOM_DEPOSIT_USERS = {}
BROADCAST_USERS = set()

OWNER_LINKS = {
    "downloads": "https://t.me/ALLINONEAPKCHANEEL",
    "support": "https://t.me/Santoshyaadav",
    "tutorial": "https://t.me/balamodkeyapk",
}

ORDERS = {}

# ==================================================
# PRODUCTS
# ==================================================

PRODUCTS = {
    "android_nonroot": {
        "name": "🤖 ANDROID NON ROOT PANEL",
        "products": [
            {
                "name": "📦 DRIP CLIENT APKMOD",
                "packages": [
                    {"duration": "1 Day", "price": 50, "pid": 109},
                    {"duration": "3 Days", "price": 130, "pid": 110},
                    {"duration": "7 Days", "price": 230, "pid": 111},
                    {"duration": "15 Days", "price": 370, "pid": 112},
                    {"duration": "30 Days", "price": 550, "pid": 113},
                ],
            },
            {
                "name": "🟠 PATOTEAM ORANGE",
                "packages": [
                    {"duration": "3 Days", "price": 210, "pid": 156},
                    {"duration": "7 Days", "price": 350, "pid": 157},
                    {"duration": "15 Days", "price": 585, "pid": 158},
                    {"duration": "30 Days", "price": 950, "pid": 159},
                ],
            },
            {
                "name": "🛡️ DRIP CLIENT PROXY APK",
                "packages": [
                    {"duration": "1 Day", "price": 60, "pid": 114},
                    {"duration": "3 Days", "price": 140, "pid": 115},
                    {"duration": "7 Days", "price": 250, "pid": 116},
                    {"duration": "30 Days", "price": 600, "pid": 117},
                ],
            },
            {
                "name": "🧪 HG CHEATS APK",
                "packages": [
                    {"duration": "1 Day", "price": 55, "pid": 122},
                    {"duration": "7 Days", "price": 140, "pid": 123},
                    {"duration": "10 Days", "price": 179, "pid": 124},
                    {"duration": "30 Days", "price": 425, "pid": 125},
                ],
            },
            {
                "name": "🔧 PRIME MOD APK",
                "packages": [
                    {"duration": "1 Day", "price": 72, "pid": 129},
                    {"duration": "3 Days", "price": 90, "pid": 130},
                    {"duration": "7 Days", "price": 270, "pid": 131},
                ],
            },
            {
                "name": "🔴 HG PROXY APK",
                "packages": [
                    {"duration": "1 Day", "price": 70, "pid": 126},
                    {"duration": "7 Days", "price": 220, "pid": 127},
                    {"duration": "10 Days", "price": 290},
                    {"duration": "30 Days", "price": 585, "pid": 128},
                ],
            },
            {
                "name": "💀 CTB MOD APK",
                "packages": [
                    {"duration": "12 Hour", "price": 20, "pid": 136},
                    {"duration": "1 Day", "price": 30, "pid": 137},
                    {"duration": "3 Days", "price": 80, "pid": 138},
                    {"duration": "7 Days", "price": 150, "pid": 139},
                ],
            },
            {
                "name": "🔧 PATOTEAM BLUE",
                "packages": [
                    {"duration": "3 Days", "price": 175, "pid": 140, "stock": False},
                    {"duration": "7 Days", "price": 350, "pid": 141},
                    {"duration": "15 Days", "price": 520, "pid": 142},
                    {"duration": "30 Days", "price": 850, "pid": 143},
                ],
            },
            {
                "name": "🦂 ABCD WIRE APK",
                "packages": [
                    {"duration": "12 Hour", "price": 25, "pid": 132},
                    {"duration": "1 Day", "price": 40, "pid": 133},
                    {"duration": "3 Days", "price": 100, "pid": 134},
                    {"duration": "7 Days", "price": 160, "pid": 135},
                ],
            },
            {
                "name": "🟦 DRIP WIRE APK",
                "packages": [
                    {"duration": "6 Hour", "price": 35, "pid": 118},
                    {"duration": "12 Hour", "price": 50, "pid": 119},
                    {"duration": "1 Day", "price": 90, "pid": 120},
                    {"duration": "7 Days", "price": 350, "pid": 121},
                ],
            },
            {
                "name": "👹 BALA MOD APK",
                "packages": [
                    {"duration": "1 Hour", "price": 15, "pid": 160},
                    {"duration": "2 Hour", "price": 22, "pid": 161},
                    {"duration": "3 Hour", "price": 32, "pid": 162},
                    {"duration": "4 Hour", "price": 40, "pid": 163},
                    {"duration": "5 Hour", "price": 50, "pid": 164},
                    {"duration": "6 Hour", "price": 60, "pid": 165},
                    {"duration": "7 Hour", "price": 72, "pid": 166},
                    {"duration": "8 Hour", "price": 80, "pid": 167},
                    {"duration": "9 Hour", "price": 85, "pid": 168},
                    {"duration": "10 Hour", "price": 88, "pid": 169},
                    {"duration": "1 Day", "price": 245, "pid": 170},
                    {"duration": "2 Days", "price": 480, "pid": 171},
                    {"duration": "3 Days", "price": 650, "pid": 172},
                    {"duration": "7 Days", "price": 1500, "pid": 173},
                    {"duration": "30 Days", "price": 5500, "pid": 174},
                ],
            },
            {
                "name": "🤖 AIMHACK [NONROOT+iOS]",
                "packages": [
                    {"duration": "1 Hour", "price": 20, "pid": 234},
                    {"duration": "3 Hour", "price": 40, "pid": 235},
                    {"duration": "6 Hour", "price": 55, "pid": 236},
                    {"duration": "12 Hour", "price": 90, "pid": 237},
                    {"duration": "1 Day", "price": 120, "pid": 238},
                    {"duration": "3 Days", "price": 190, "pid": 239},
                    {"duration": "7 Days", "price": 360, "pid": 240},
                    {"duration": "30 Days", "price": 900, "pid": 241},
                ],
            },
            {
                "name": "⚔️ HEX BLADE APKMOD",
                "packages": [
                    {"duration": "1 Day", "price": 70, "pid": 179},
                    {"duration": "3 Days", "price": 130, "pid": 180},
                    {"duration": "7 Days", "price": 230, "pid": 181},
                    {"duration": "15 Days", "price": 350, "pid": 182},
                    {"duration": "30 Days", "price": 580, "pid": 183},
                ],
            },
            {"name": "☠️ NINE X MODS APK", "packages": [{"duration": "10 Days", "price": 350, "pid": 224}, {"duration": "20 Days", "price": 680, "pid": 225}, {"duration": "30 Days", "price": 1100, "pid": 226}]},
            {"name": "⚔️ XREG APKMOD", "packages": [{"duration": "1 Hour", "price": 15, "pid": 227}, {"duration": "3 Hours", "price": 33, "pid": 228}, {"duration": "6 Hours", "price": 60, "pid": 229}, {"duration": "12 Hours", "price": 94, "pid": 230}, {"duration": "1 Day", "price": 105, "pid": 231}, {"duration": "3 Days", "price": 125, "pid": 232}, {"duration": "30 Days", "price": 550, "pid": 233}]},
    {
        "name": "👹 TROLL MODZ APK",
        "packages": [
            {"duration": "1 Hour", "price": 15, "pid": 276},
            {"duration": "3 Hours", "price": 25, "pid": 277},
            {"duration": "6 Hours", "price": 40, "pid": 278},
            {"duration": "12 Hours", "price": 55, "pid": 279},
            {"duration": "1 Day", "price": 80, "pid": 280},
            {"duration": "3 Days", "price": 140, "pid": 281},
            {"duration": "7 Days", "price": 250, "pid": 282},
            {"duration": "15 Days", "price": 350, "pid": 283},
            {"duration": "30 Days", "price": 550, "pid": 284},
        ],
    },
        ],
    },

    "android_root": {
        "name": "🤖 ANDROID ROOT PANEL",
        "products": [
            {
                "name": "😡 ANGRY MOD APK",
                "packages": [
                    {"duration": "1 Day", "price": 75, "pid": 144},
                    {"duration": "7 Days", "price": 320, "pid": 145},
                    {"duration": "15 Days", "price": 530, "pid": 146},
                    {"duration": "30 Days", "price": 750, "pid": 147},
                ],
            },
            {
                "name": "👑 DRIP CILENT ROOT APK",
                "packages": [
                    {"duration": "1 Day", "price": 70, "pid": 149},
                    {"duration": "7 Days", "price": 320, "pid": 150},
                    {"duration": "30 Days", "price": 650, "pid": 151},
                ],
            },
            {
                "name": "⚡ RAPID CORE APK",
                "packages": [
                    {"duration": "1 Day", "price": 70, "pid": 189},
                    {"duration": "7 Days", "price": 240, "pid": 190},
                    {"duration": "14 Days", "price": 350, "pid": 191},
                    {"duration": "30 Days", "price": 520, "pid": 192},
                ],
            },
            {
                "name": "💀 BR MODS APK",
                "packages": [
                    {"duration": "1 Day", "price": 50, "pid": 193},
                    {"duration": "7 Days", "price": 220, "pid": 197},
                    {"duration": "15 Days", "price": 320, "pid": 198},
                    {"duration": "30 Days", "price": 500, "pid": 199},
                ],
            },
            {
                "name": "🛡️ SILENT CHEATS SAFE",
                "packages": [
                    {"duration": "1 Day", "price": 75, "pid": 203},
                    {"duration": "3 Days", "price": 130, "pid": 204},
                    {"duration": "7 Days", "price": 250, "pid": 205},
                    {"duration": "14 Days", "price": 500, "pid": 206},
                    {"duration": "30 Days", "price": 720, "pid": 207},
                ],
            },
            {
                "name": "⚔️ HEX BLADE APK",
                "packages": [
                    {"duration": "1 Day", "price": 75, "pid": 184},
                    {"duration": "3 Days", "price": 150, "pid": 185},
                    {"duration": "7 Days", "price": 250, "pid": 186},
                    {"duration": "15 Days", "price": 380, "pid": 187},
                    {"duration": "30 Days", "price": 620, "pid": 188},
                ],
            },
            {"name": "🩸 SILENT CHEATS BRUTAL", "packages": [{"duration": "1 Day", "price": 75, "pid": 208}, {"duration": "3 Days", "price": 125, "pid": 209}, {"duration": "7 Days", "price": 250, "pid": 210}, {"duration": "14 Days", "price": 500, "pid": 211}, {"duration": "30 Days", "price": 720, "pid": 212}]},
            {"name": "💀 HAXX-CKER PRO", "packages": [{"duration": "5 Days", "price": 200, "pid": 218}, {"duration": "10 Days", "price": 400, "pid": 219}]},
            {"name": "👿 ZYTRON PRO APK", "packages": [{"duration": "1 Day", "price": 70, "pid": 242}, {"duration": "7 Days", "price": 210, "pid": 243}, {"duration": "15 Days", "price": 350, "pid": 244}]},
        ],
    },

    "iphone": {
        "name": "🍎 IPHONE PANEL",
        "products": [
            {
                "name": "🛒 ESING CERTIFICATE",
                "packages": [
                    {"duration": "1 Year", "price": 500, "pid": 148},
                ],
            },
            {
                "name": "⚡ ALPHA REGEDIT EXTERNAL",
                "packages": [
                    {"duration": "1 Day", "price": 90, "pid": 152},
                    {"duration": "3 Days", "price": 180, "pid": 153},
                    {"duration": "7 Days", "price": 350, "pid": 154},
                    {"duration": "30 Days", "price": 800, "pid": 155},
                ],
            },
        ],
    },

    "pc": {
        "name": "💻 PC PANEL",
        "products": [
            {
                "name": "💻 BR MODS PC",
                "packages": [
                    {"duration": "1 Day", "price": 75, "pid": 200},
                    {"duration": "10 Days", "price": 320, "pid": 201},
                    {"duration": "30 Days", "price": 600, "pid": 202},
                ],
            },            {
                "name": "🖥️ PC LOGO BYPASS NON ROOT",
                "packages": [
                    {"duration": "30 Day", "price": 400, "pid": 246},
                ],
            },
        ],
    },
}

WHOLESALE_RATES = {
    276: 7,
    277: 12,
    278: 20,
    279: 28,
    280: 40,
    281: 75,
    282: 125,
    283: 230,
    284: 450,
    246: 300,

    109: 25,
    110: 60,
    111: 110,
    112: 180,
    113: 275,
    114: 30,
    115: 70,
    116: 125,
    117: 300,
    118: 18,
    119: 25,
    120: 45,
    121: 175,
    122: 40,
    123: 100,
    124: 140,
    125: 250,
    126: 45,
    127: 100,
    128: 350,
    129: 36,
    130: 75,
    131: 145,
    132: 10,
    133: 25,
    134: 50,
    135: 89,
    136: 10,
    137: 15,
    138: 40,
    139: 70,
    140: 100,
    141: 200,
    142: 250,
    143: 400,
    144: 40,
    145: 90,
    146: 150,
    147: 200,
    148: 250,

    149: 45,
    150: 130,
    151: 330,
    152: 50,
    153: 99,
    154: 190,
    155: 410,
    156: 150,
    157: 200,
    158: 300,
    159: 500,
    234: 12,
    235: 25,
    236: 33,
    237: 45,
    238: 65,
    239: 135,
    240: 243,
    241: 650,
    160: 7,
    161: 15,
    162: 21,
    163: 30,
    164: 42,
    165: 47,
    166: 56,
    167: 65,
    168: 69,
    169: 70,
    170: 185,
    171: 365,
    172: 530,
    173: 1250,
    174: 5000,
    179: 37,
    180: 69,
    181: 110,
    182: 190,
    183: 290,
    184: 40,
    185: 70,
    186: 120,
    187: 200,
    188: 300,
    189: 30,
    190: 149,
    191: 199,
    192: 320,
    193: 35,
    197: 90,
    198: 150,
    199: 290,
    200: 45,
    201: 160,
    202: 300,
    203: 45,
    204: 75,
    205: 125,
    206: 225,
    207: 350,
    208: 50,
    209: 75,
    210: 125,
    211: 250,
    212: 360,
    218: 160,
    219: 300,
    224: 250,
    225: 495,
    226: 750,
    227: 10,
    228: 18,
    229: 30,
    230: 47,
    231: 65,
    232: 100,
    233: 450,
    242: 50,
    243: 120,
    244: 200,
}

def get_reseller_price(package, product=None):
    wholesale = package.get("wholesale")
    if wholesale is not None:
        return float(wholesale)

    pid = package.get("pid")
    if not pid and product:
        pid = product.get("pid")

    rate = get_wholesale_rate(pid) if pid else None
    return float(rate) if rate is not None else None


def get_wholesale_rate(pid):
    try:
        return WHOLESALE_RATES.get(int(pid))
    except (TypeError, ValueError):
        return None



# ==================================================
# MAIN MENU
# ==================================================

def main_menu(user_id=None):
    rows = [
        [
            InlineKeyboardButton(
                "🛍️ PRODUCT STORE",
                callback_data="products",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "👤 MY PROFILE",
                callback_data="profile",
                style="primary"
            ),
            InlineKeyboardButton(
                "💰 ADD BALANCE",
                callback_data="deposit",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "📜 ALL HISTORY",
                callback_data="history",
                style="primary"
            ),
            InlineKeyboardButton(
                "🎁 REFERRAL",
                callback_data="referral",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "📚 TUTORIAL",
                callback_data="tutorial",
                style="primary"
            ),
            InlineKeyboardButton(
                "🆘 SUPPORT",
                callback_data="support",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "🎲 LUDO SPIN",
                callback_data="ludo",
                style="primary"
            ),
            InlineKeyboardButton(
                "📥 DOWNLOAD FILES",
                callback_data="downloads",
                style="primary"
            )
        ],
    ]

    if str(user_id) == str(OWNER_ID):
        rows.append([
            InlineKeyboardButton(
                "👑 ADMIN PANEL",
                callback_data="open_admin",
                style="primary"
            )
        ])
    else:
        rows.append([
            InlineKeyboardButton(
                "🤝 RESELLER PANEL",
                callback_data="reseller:panel",
                style="success"
            )
        ])
    return InlineKeyboardMarkup(rows)



async def front_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Open the same front/store panel from a text command."""
    USERS.add(update.effective_user.id)
    await update.message.reply_text(
        "🏠 <b>FRONT PANEL</b>\n\n"
        "👇 Select an option below:",
        parse_mode="HTML",
        reply_markup=main_menu(update.effective_user.id),
    )


# ==================================================
# START
# ==================================================

def init_user_db():
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS users "
        "(user_id TEXT PRIMARY KEY, username TEXT, first_name TEXT, last_name TEXT, phone TEXT, created_at TEXT, updated_at TEXT)"
    )
    conn.commit()
    conn.close()


def save_user(update):
    user = update.effective_user
    if not user:
        return

    uid = str(user.id)
    username = user.username or ""
    first_name = user.first_name or ""
    last_name = user.last_name or ""

    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()

    cur.execute("SELECT user_id FROM users WHERE user_id=?", (uid,))
    exists = cur.fetchone()

    if exists:
        cur.execute(
            "UPDATE users SET username=?, first_name=?, last_name=?, "
            "updated_at=datetime('now', 'localtime') WHERE user_id=?",
            (username, first_name, last_name, uid),
        )
    else:
        cur.execute(
            "INSERT INTO users "
            "(user_id, username, first_name, last_name, phone, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, '', datetime('now', 'localtime'), datetime('now', 'localtime'))",
            (uid, username, first_name, last_name),
        )

    conn.commit()
    conn.close()
    USERS.add(user.id)


def get_user_phone(user_id):
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "SELECT phone FROM users WHERE user_id=?",
        (str(user_id),)
    )
    row = cur.fetchone()
    conn.close()
    return row[0] if row and row[0] else None


def save_user_phone(update):
    user = update.effective_user
    contact = update.effective_message.contact if update.effective_message else None

    if not user or not contact:
        return

    if contact.user_id and int(contact.user_id) != int(user.id):
        return

    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "UPDATE users SET phone=?, updated_at=datetime('now', 'localtime') WHERE user_id=?",
        (contact.phone_number, str(user.id)),
    )
    conn.commit()
    conn.close()


init_user_db()


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user(update)

    user_id = update.effective_user.id

    if not get_user_phone(user_id):
        await update.message.reply_text(
            "📱 <b>CONTACT SAVE</b>\n\n"
            "पहले अपना contact share करें।\n"
            "इसके बाद आपका My Profile खुलेगा।",
            parse_mode="HTML",
            reply_markup=ReplyKeyboardMarkup(
                [[KeyboardButton("📱 SHARE CONTACT", request_contact=True)]],
                resize_keyboard=True,
                one_time_keyboard=True
            )
        )
        return

    text = (
        "✨ <b>WELCOME TO THE STORE</b> ✨\n\n"
        "🛍️ <b>Product Store</b> : All key purchase & instantly delivery\n"
        "👤 <b>My Profile</b> : Check your account information\n"
        "💰 <b>Add Balance</b> : Deposit balance & secure service\n"
        "📜 <b>All History</b> : Check all key purchase history\n"
        "🎁 <b>Referral</b> : Invite friends & earn rewards\n"
        "📚 <b>Tutorial</b> : View tutorial and work this bot\n"
        "🆘 <b>Support</b> : Bot problem fixed for support admin\n"
        "🎲 <b>Ludo Spin</b> : Demo game\n"
        "📥 <b>Download Files</b> : Download latest files for safety\n\n"
        "👇 <b>Select an option below</b>"
    )

    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=main_menu(user_id)
    )


async def handle_shared_contact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user(update)
    save_user_phone(update)

    user = update.effective_user
    phone = get_user_phone(user.id) or "Not shared"
    username = f"@{user.username}" if user.username else "Not set"
    name = user.full_name or user.first_name or "Not set"

    text = (
        "👤 <b>MY PROFILE</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"👤 Name: <b>{name}</b>\n"
        f"🔹 Username: <b>{username}</b>\n"
        f"📱 Phone: <code>{phone}</code>\n"
        f"🆔 User ID: <code>{user.id}</code>\n"
        f"💰 Balance: <b>₹{get_balance(user.id)}</b>\n\n"
        "🔐 Account status: Active"
    )

    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove()
    )


# ==================================================
# HOME
# ==================================================

async def home(query):

    await query.answer()

    await query.edit_message_text(
        "🏠 <b>STORE HOME</b>\n\n"
        "Welcome to our digital store.\n\n"
        "👇 Select an option:",
        parse_mode="HTML",
        reply_markup=main_menu(query.from_user.id)
    )


def panel_button_name(name):
    """Return the product name without adding a shopping-cart emoji."""
    return str(name or "").strip()


# ==================================================
# PRODUCTS MENU
# ==================================================

async def reseller_panel(query):
    user_id = query.from_user.id
    await query.answer()

    # Force reseller status from database
    activation = get_reseller_activation(user_id)

    if activation:
        try:
            if time.time() - float(activation) < RESELLER_VALIDITY:
                RESELLERS.add(str(user_id))
            else:
                RESELLERS.discard(str(user_id))
        except (TypeError, ValueError):
            RESELLERS.discard(str(user_id))
    else:
        RESELLERS.discard(str(user_id))

    # Always sync reseller status from database
    activation = get_reseller_activation(user_id)
    if activation:
        try:
            if time.time() - float(activation) < RESELLER_VALIDITY:
                RESELLERS.add(str(user_id))
        except (TypeError, ValueError):
            pass

    if not is_reseller_active(user_id):
        text = (
            "🤝 <b>RESELLER PANEL</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "🔴 <b>Reseller Not Active</b>\n\n"
            "Reseller activate करने के लिए ₹100 activation payment करें."
        )
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "💳 ACTIVATE ₹100",
                    callback_data="reseller:activate",
                    style="success"
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ HOME",
                    callback_data="home",
                    style="danger"
                )
            ]
        ])
    else:
        activated_at = get_reseller_activation(user_id)
        activated = (
            time.strftime("%d-%m-%Y", time.localtime(activated_at))
            if activated_at else "N/A"
        )

        text = (
            "🤝 <b>RESELLER PANEL</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "🟢 <b>Reseller Active</b>\n"
            f"📅 Activated: <b>{activated}</b>\n\n"
            f"💰 <b>Total Saved:</b> ₹{get_reseller_total_saved(user_id):.2f}"
        )

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🛍️ PRODUCT STORE",
                    callback_data="products",
                    style="primary"
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ HOME",
                    callback_data="home",
                    style="danger"
                )
            ]
        ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )

async def reseller_activation(query):
    await query.answer()

    user_id = query.from_user.id

    if is_reseller_active(user_id):
        await query.answer(
            "🟢 Reseller already active",
            show_alert=True
        )
        return

    await create_qr(query, 100, payment_type="reseller_activation")


async def products_menu(query):
    await query.answer(cache_time=1)

    text = (
        "🛒 <b>SELECT PRODUCT PANEL</b>\n\n"
        "🛡️ <b>Choose a panel to view its products:</b>"
    )

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🤖 ANDROID NON ROOT PANEL", callback_data="category:android_nonroot", style="primary")],
        [InlineKeyboardButton("🤖 ANDROID ROOT PANEL", callback_data="category:android_root", style="primary")],
        [InlineKeyboardButton("🍎 IPHONE PANEL", callback_data="category:iphone", style="primary")],
        [InlineKeyboardButton("💻 PC PANEL", callback_data="category:pc", style="primary")],
        [InlineKeyboardButton("↩️ BACK", callback_data="home", style="danger")],
    ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )


async def category_menu(query, category_key):
    await query.answer()

    category = PRODUCTS.get(category_key)
    if not category:
        await query.answer("❌ Category not found", show_alert=True)
        return

    products = category.get("products", [])

    # Running products first, MAINTENANCE products at the bottom
    products_with_index = list(enumerate(products))
    products_with_index.sort(
        key=lambda item: "MAINTENANCE" in item[1].get("name", "").upper()
    )

    buttons = []

    for index, product in products_with_index:
        buttons.append([
            InlineKeyboardButton(
                panel_button_name(product["name"]),
                callback_data=f"product:{category_key}:{index}",
                style="primary"
            )
        ])

    if not buttons:
        buttons.append([
            InlineKeyboardButton(
                "⏳ COMING SOON",
                callback_data="home",
                style="primary"
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            "↩️ BACK",
            callback_data="products",
            style="danger"
        )
    ])

    await query.edit_message_text(
        f"🛒 <b>{category['name']}</b>\n\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "🛡️ <b>SELECT PANEL</b>\n"
        "━━━━━━━━━━━━━━━━━━",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def product_details(query, category_key, index):
    await query.answer()

    category = PRODUCTS.get(category_key)

    if not category:
        return

    try:
        product = category["products"][int(index)]
    except (ValueError, IndexError):
        await query.answer("❌ Invalid product", show_alert=True)
        return

    buttons = []

    for package_index, package in enumerate(product.get("packages", [])):
        duration = package["duration"]
        retail_price = package["price"]
        pid = package.get("pid") or product.get("pid")

        if is_reseller_active(query.from_user.id):
            wholesale_rate = get_wholesale_rate(pid)
            price = wholesale_rate if wholesale_rate is not None else retail_price
        else:
            price = retail_price

        stock = package.get("stock", True)

        if stock:
            buttons.append([
                InlineKeyboardButton(
                    f"🛒 BUY {duration.upper()} — ₹{price:.2f}",
                    callback_data=f"buy:{category_key}:{index}:{package_index}",
                    style="success"
                )
            ])
        else:
            buttons.append([
                InlineKeyboardButton(
                    f"⛔ OUT OF STOCK — {duration} — ₹{price:.2f}",
                    callback_data=f"buy:{category_key}:{index}:{package_index}",
                    style="danger"
                )
            ])

    buttons.append([
        InlineKeyboardButton(
            "↩️ BACK",
            callback_data=f"category:{category_key}",
            style="danger"
        )
    ])

    text = (
        f"🛒 <b>{product['name']} PACKAGES</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
    )

    for package in product.get("packages", []):
        stock_text = (
            "📦 ✅ In Stock"
            if package.get("stock", True)
            else "📦 ❌ Out of Stock"
        )

        pid = package.get("pid") or product.get("pid")
        retail_price = float(package.get("price", 0))

        if is_reseller_active(query.from_user.id):
            reseller_price = get_reseller_price(package, product)
            display_price = reseller_price if reseller_price is not None else retail_price
        else:
            display_price = retail_price

        text += (
            f"🛒 ⏱️ <b>Validity:</b> {package['duration']}\n"
            f"💰 <b>Price:</b> ₹{display_price:.2f}\n"
            f"📱 <b>Limit:</b> 1 Device | {stock_text}\n\n"
        )

    text += (
        "━━━━━━━━━━━━━━━━━━\n"
        "🛡️ <b>Select a package below to purchase</b>"
    )

    markup = InlineKeyboardMarkup(buttons)

    # Product Store pages may be photo messages.
    # Telegram requires edit_message_caption() for photo messages.
    if query.message and query.message.photo:
        await query.edit_message_caption(
            caption=text,
            parse_mode="HTML",
            reply_markup=markup
        )
    else:
        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=markup
        )


async def reseller_store_menu(query):
    await query.answer()
    buttons = []
    for key, category in PRODUCTS.items():
        buttons.append([InlineKeyboardButton(category["name"], callback_data=f"reseller:category:{key}", style="primary")])
    buttons.append([InlineKeyboardButton("↩️ BACK", callback_data="home", style="danger")])
    await query.edit_message_text("🤝 <b>RESELLER STORE</b>\n━━━━━━━━━━━━━━━━━━\n\n🛒 <b>Wholesale Price Store</b>\n\nनीचे panel चुनें:", parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

async def reseller_category_menu(query, category_key):
    await query.answer()
    if str(query.from_user.id) not in RESELLERS:
        await query.answer("❌ Reseller access नहीं है।", show_alert=True)
        return
    category = PRODUCTS.get(category_key)
    if not category:
        await query.answer("❌ Category not found", show_alert=True)
        return
    buttons = []
    for index, product in enumerate(category.get("products", [])):
        buttons.append([InlineKeyboardButton(product["name"], callback_data=f"reseller:product:{category_key}:{index}", style="primary")])
    buttons.append([InlineKeyboardButton("↩️ BACK", callback_data="reseller:store", style="danger")])
    await query.edit_message_text(f"🤝 <b>{category['name']}</b>\n━━━━━━━━━━━━━━━━━━\n\n🛒 <b>SELECT PRODUCT</b>", parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

async def reseller_product_details(query, category_key, index):
    await query.answer()
    if str(query.from_user.id) not in RESELLERS:
        await query.answer("❌ Reseller access नहीं है।", show_alert=True)
        return
    category = PRODUCTS.get(category_key)
    try:
        product = category["products"][int(index)]
    except (TypeError, ValueError, KeyError, IndexError):
        await query.answer("❌ Invalid product", show_alert=True)
        return
    buttons = []
    text = f"📦 <b>{product['name']} PACKAGES</b>\n━━━━━━━━━━━━━━━━━━\n\n📱 <b>1 Device</b>\n\n"
    for package_index, package in enumerate(product.get("packages", [])):
        pid = package.get("pid")
        rate = get_wholesale_rate(pid) if pid else None
        if rate is None:
            continue
        stock_text = "📦 ✅ In Stock" if package.get("stock", True) else "📦 ❌ Out of Stock"
        text += f"🛒 ⏱️ Validity: <b>{package['duration']}</b>\n💰 Price: <b>₹{rate:.2f}</b>\n📱 Limit: 1 Device | {stock_text}\n\n"
        buttons.append([InlineKeyboardButton(f"🛒 BUY {package["duration"].upper()} — ₹{rate:.2f}", callback_data=f"reseller:buy:{category_key}:{index}:{package_index}", style="success")])
    buttons.append([InlineKeyboardButton("↩️ BACK", callback_data=f"reseller:category:{category_key}", style="danger")])
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

async def buy_product(query, category_key, index, package_index=None):
    await query.answer()

    category = PRODUCTS.get(category_key)
    if not category:
        await query.message.reply_text("❌ Product category नहीं मिली।")
        return

    products = category.get("products", [])

    try:
        index = int(index)
    except (TypeError, ValueError):
        await query.message.reply_text("❌ Invalid product.")
        return

    if index < 0 or index >= len(products):
        await query.message.reply_text("❌ Invalid product.")
        return

    product = products[index]
    packages = product.get("packages", [])

    if package_index is None:
        package_index = 0

    try:
        package_index = int(package_index)
    except (TypeError, ValueError):
        await query.message.reply_text("❌ Invalid package.")
        return

    if package_index < 0 or package_index >= len(packages):
        await query.message.reply_text("❌ Invalid package.")
        return

    package = packages[package_index]

    if package.get("stock", True) is False:
        await query.answer("❌ OUT OF STOCK", show_alert=True)
        return

    pid = package.get("pid") or product.get("pid")
    price = int(package.get("price", product.get("price", 0)))
    user_id = query.from_user.id

    if not pid:
        await query.message.reply_text(
            "⏳ <b>PRODUCT COMING SOON</b>\n\n"
            "इस product का PID अभी add नहीं किया गया है।\n\n"
            "PID मिलने के बाद automatic purchase और key delivery चालू हो जाएगी।",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("↩️ HOME", callback_data="home", style="primary")]
            ])
        )
        return

    if price <= 0:
        await query.message.reply_text("❌ Product price invalid है।")
        return

    # Direct product payment QR
    await create_purchase_qr(
        query=query,
        amount=price,
        category_key=category_key,
        product_index=index,
        package_index=package_index,
        pid=pid,
    )


async def verify_payment(query):
    await query.answer()

    user_id = query.from_user.id
    pending_order = None

    # Find user's pending payment
    for order_id, payment in PAYMENTS.items():
        if (
            payment.get("user_id") == user_id
            and payment.get("status") == "pending"
        ):
            pending_order = order_id
            break

    if not pending_order:
        await query.message.reply_text(
            "❌ <b>NO PENDING PAYMENT</b>\n\n"
            "कोई pending payment नहीं मिला.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "💰 ADD BALANCE",
                        callback_data="deposit"
                    , style="primary")
                ],
                [
                    InlineKeyboardButton(
                        "🛍️ PRODUCT STORE",
                        callback_data="products"
                    , style="primary")
                ],
            ])
        )
        return

    if not FAMPAY_API_KEY:
        await query.message.reply_text(
            "❌ Payment API key configured नहीं है."
        )
        return

    try:
        response = requests.get(
            f"{FAMPAY_BASE}/verify.php",
            params={
                "order_id": pending_order,
                "api_key": FAMPAY_API_KEY,
            },
            timeout=15,
        )

        response.raise_for_status()
        data = response.json()

    except Exception as e:
        logging.error("VERIFY ERROR: %s", e)

        await query.message.reply_text(
            "❌ Payment verification service से connection नहीं हो पाया."
        )
        return

    if not data.get("success"):
        await query.message.reply_text(
            "⏳ <b>PAYMENT NOT RECEIVED</b>\n\n"
            "Payment अभी detect नहीं हुआ है.\n"
            "कुछ समय wait करके फिर CHECK PAYMENT दबाएँ.",
            parse_mode="HTML"
        )
        return

    payment = PAYMENTS.get(pending_order)

    if not payment:
        await query.message.reply_text(
            "❌ Payment record नहीं मिला."
        )
        return

    paid_amount = data.get("amount")
    expected_amount = payment.get("amount")

    try:
        paid_amount = float(paid_amount)
        expected_amount = float(expected_amount)
    except (TypeError, ValueError):
        await query.message.reply_text(
            "❌ Payment amount verify नहीं हो पाया."
        )
        return

    # Exact amount verification
    if abs(paid_amount - expected_amount) > 0.001:
        await query.message.reply_text(
            "❌ <b>AMOUNT MISMATCH</b>\n\n"
            f"Expected: ₹{expected_amount:g}\n"
            f"Received: ₹{paid_amount:g}",
            parse_mode="HTML"
        )
        return

    # ==================================================
    # PRODUCT PURCHASE
    # ==================================================

    if payment.get("type") == "purchase":

        category_key = payment.get("category")
        product_index = payment.get("product_index")
        package_index = payment.get("package_index")
        pid = payment.get("pid")

        if not category_key or product_index is None or package_index is None or not pid:
            logging.error(
                "INVALID PURCHASE PAYMENT DATA: %s",
                payment
            )
            payment["status"] = "invalid_purchase"

            await query.message.reply_text(
                "❌ Purchase information incomplete है.\n"
                "Owner से contact करें."
            )
            return

        category = PRODUCTS.get(category_key)

        if not category:
            payment["status"] = "invalid_purchase"
            await query.message.reply_text(
                "❌ Product category नहीं मिली."
            )
            return

        try:
            product = category["products"][int(product_index)]
            package = product["packages"][int(package_index)]
        except (KeyError, IndexError, TypeError, ValueError):
            payment["status"] = "invalid_purchase"
            await query.message.reply_text(
                "❌ Product package नहीं मिला."
            )
            return

        # Prevent duplicate Panel Store orders
        payment["status"] = "processing"

        await query.message.reply_text(
            "✅ <b>PAYMENT VERIFIED</b>\n\n"
            "💳 Payment successfully received.\n"
            "⏳ अब Panel Store से license key generate की जा रही है...",
            parse_mode="HTML"
        )

        try:
            result = await panel_api_order(
                pid=pid,
                quantity=1,
                custom_notes=f"Telegram User ID: {user_id}",
            )

            logging.info(
                "DIRECT PURCHASE ORDER RESPONSE: %s",
                result
            )
            print("🔥 PANEL STORE BOT RESPONSE:", result, flush=True)

            if not result.get("success", True):
                payment["status"] = "paid_order_failed"

                message = result.get(
                    "message",
                    "Panel Store order failed."
                )

                await query.message.reply_text(
                    "❌ <b>ORDER FAILED</b>\n\n"
                    f"{message}\n\n"
                    "Payment receive हो चुका है। Owner से contact करें.",
                    parse_mode="HTML"
                )
                return

            order_data = result.get("data", result)

            license_key = (
                order_data.get("license_key")
                or result.get("license_key")
                or order_data.get("key")
            )

            order_code = (
                order_data.get("order_code")
                or result.get("order_code")
                or order_data.get("order_id")
            )

            if not license_key:
                payment["status"] = "paid_key_missing"

                await query.message.reply_text(
                    "❌ Payment successful है, लेकिन Panel Store response में "
                    "license key नहीं मिली.\n\n"
                    "Owner से contact करें.",
                    parse_mode="HTML"
                )
                return

            # Payment + order completed
            payment["status"] = "paid"
            payment["transaction_id"] = data.get("transaction_id")
            payment["utr"] = data.get("utr")
            payment["panel_order_code"] = order_code

            order_id = order_code or f"order_{len(ORDERS) + 1}"

            ORDERS[order_id] = {
                "user_id": user_id,
                "category": category_key,
                "product": product["name"],
                "duration": package.get("duration"),
                "price": expected_amount,
                "pid": pid,
                "license_key": license_key,
                "order_code": order_code,
                "payment_order_id": pending_order,
                "transaction_id": data.get("transaction_id"),
                "utr": data.get("utr"),
                "status": "completed",
            }

            save_successful_key_histories(
                user_id=user_id,
                product=product["name"],
                duration=package.get("duration"),
                pid=pid,
                price=expected_amount,
                license_key=license_key,
                order_code=order_code,
                payment_order_id=f"purchase:{pending_order}",
            )

            await query.message.reply_text(
                "🎉 <b>ORDER SUCCESSFUL</b>\n"
                "━━━━━━━━━━━━━━━━━━\n\n"
                f"📦 Product: <b>{product['name']}</b>\n"
                f"⏱️ Validity: <b>{package.get('duration', 'N/A')}</b>\n"
                f"💵 Price: <b>₹{expected_amount:g}</b>\n"
                f"🆔 Order: <code>{order_code or 'N/A'}</code>\n\n"
                "🔑 <b>YOUR LICENSE KEY</b>\n"
                f"<code>{license_key}</code>\n\n"
                "✅ Payment verified\n"
                "✅ Key generated successfully",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton(
                            "🛍️ BUY MORE",
                            callback_data="products",
                            style="primary"
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "🏠 HOME",
                            callback_data="home"
                        , style="primary")
                    ],
                ])
            )

        except Exception as e:
            logging.exception(
                "DIRECT PURCHASE PANEL ORDER ERROR: %s",
                e
            )

            payment["status"] = "paid_order_error"

            await query.message.reply_text(
                "❌ <b>ORDER ERROR</b>\n\n"
                "Payment receive हो चुका है लेकिन Panel Store order "
                "में error आया.\n\n"
                "Owner से contact करें.",
                parse_mode="HTML"
            )

        return

    # ==================================================
    # NORMAL ADD BALANCE PAYMENT
    # ==================================================

    add_balance(user_id, expected_amount)

    payment["status"] = "paid"
    payment["transaction_id"] = data.get("transaction_id")
    payment["utr"] = data.get("utr")

    await query.message.reply_text(
        "✅ <b>PAYMENT SUCCESSFUL</b>\n\n"
        f"💰 Added Balance: <b>₹{expected_amount:g}</b>\n"
        f"💳 Current Balance: <b>₹{get_balance(user_id)}</b>\n\n"
        "🎉 आपका balance successfully add हो गया.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🛍️ PRODUCT STORE",
                    callback_data="products"
                , style="primary")
            ],
            [
                InlineKeyboardButton(
                    "🏠 HOME",
                    callback_data="home"
                , style="primary")
            ],
        ])
    )


async def panel_api_order(pid, quantity=1, custom_notes=""):
    if not PANEL_API_KEY:
        raise RuntimeError("PANEL_API_KEY missing in .env")

    payload = {
        "key": PANEL_API_KEY,
        "action": "order",
        "pid": pid,
        "quantity": quantity,
        "custom_notes": custom_notes,
    }

    response = requests.post(
        PANEL_API_URL,
        json=payload,
        timeout=20,
    )

    try:
        result = response.json()
    except Exception:
        response.raise_for_status()
        raise RuntimeError(
            f"Panel Store returned invalid response (HTTP {response.status_code})"
        )

    # Panel Store can return a successful order even when HTTP handling
    # is unusual, so process the actual API JSON response first.
    if isinstance(result, dict) and result.get("status") == "success":
        return result

    if response.status_code >= 400:
        print("🔥 PANEL STORE HTTP ERROR:", response.status_code, flush=True)
        print("🔥 PANEL STORE RESPONSE:", result, flush=True)
        print("🔥 PANEL STORE REQUEST:", {
            "action": payload.get("action"),
            "pid": payload.get("pid"),
            "quantity": payload.get("quantity"),
            "custom_notes": payload.get("custom_notes"),
        }, flush=True)
        raise RuntimeError(
            f"Panel Store HTTP {response.status_code}: {result}"
        )

    if isinstance(result, dict):
        return result

    raise RuntimeError("Invalid Panel Store API response")


async def owner_buy_product(query, category_key, index, package_index):
    """Owner-only direct wholesale purchase from Panel Store."""

    if str(query.from_user.id) != str(OWNER_ID):
        await query.answer("❌ Access Denied", show_alert=True)
        return

    await query.answer()

    category = PRODUCTS.get(category_key)
    if not category:
        await query.message.reply_text("❌ Product category नहीं मिली।")
        return

    products = category.get("products", [])

    try:
        index = int(index)
        package_index = int(package_index)
    except (TypeError, ValueError):
        await query.message.reply_text("❌ Invalid product/package.")
        return

    if index < 0 or index >= len(products):
        await query.message.reply_text("❌ Invalid product.")
        return

    product = products[index]
    packages = product.get("packages", [])

    if package_index < 0 or package_index >= len(packages):
        await query.message.reply_text("❌ Invalid package.")
        return

    package = packages[package_index]

    if package.get("stock", True) is False:
        await query.answer("❌ OUT OF STOCK", show_alert=True)
        return

    pid = package.get("pid") or product.get("pid")

    if not pid:
        await query.message.reply_text(
            "⏳ <b>PRODUCT COMING SOON</b>\n\n"
            "इस package का PID अभी available नहीं है।",
            parse_mode="HTML"
        )
        return

    wholesale = get_wholesale_rate(pid)

    if wholesale is None:
        await query.message.reply_text(
            "❌ <b>WHOLESALE RATE NOT FOUND</b>\n\n"
            f"PID: <code>{pid}</code>",
            parse_mode="HTML"
        )
        return

    # Show confirmation before placing the real Panel Store order.
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "✅ BUY WHOLESALE",
                callback_data=f"ownerconfirm:{category_key}:{index}:{package_index}",
                style="success"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data=f"product:{category_key}:{index}",
                style="danger"
            )
        ]
    ])

    text = (
        "👑 <b>OWNER WHOLESALE PURCHASE</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"🛒 <b>{product['name']}</b>\n"
        f"⏱️ Validity: <b>{package['duration']}</b>\n"
        f"🆔 PID: <code>{pid}</code>\n\n"
        f"🌐 Website/Wholesale Price: <b>₹{wholesale:.2f}</b>\n"
        f"🏷️ Customer Price: ₹{package['price']:.2f}\n\n"
        "⚠️ Owner purchase में customer payment नहीं लगेगा।\n"
        "Panel Store के reseller balance से wholesale amount deduct होगा।\n\n"
        "क्या order करना है?"
    )

    await query.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )


async def owner_confirm_purchase(query, category_key, index, package_index):
    """Actually place Owner wholesale order."""

    if str(query.from_user.id) != str(OWNER_ID):
        await query.answer("❌ Access Denied", show_alert=True)
        return

    await query.answer("⏳ Order processing...")

    category = PRODUCTS.get(category_key)
    if not category:
        await query.message.reply_text("❌ Product category नहीं मिली।")
        return

    try:
        index = int(index)
        package_index = int(package_index)
    except (TypeError, ValueError):
        await query.message.reply_text("❌ Invalid product/package.")
        return

    products = category.get("products", [])

    if index < 0 or index >= len(products):
        await query.message.reply_text("❌ Invalid product.")
        return

    product = products[index]
    packages = product.get("packages", [])

    if package_index < 0 or package_index >= len(packages):
        await query.message.reply_text("❌ Invalid package.")
        return

    package = packages[package_index]
    pid = package.get("pid") or product.get("pid")

    try:
        pid = int(pid)
    except (TypeError, ValueError):
        await query.message.reply_text("❌ Invalid Panel Store PID.")
        return

    wholesale = get_wholesale_rate(pid)

    if not pid or wholesale is None:
        await query.message.reply_text("❌ Wholesale PID/rate available नहीं है।")
        return

    try:
        result = await panel_api_order(
            pid=pid,
            quantity=1,
            custom_notes="Owner wholesale purchase"
        )
    except Exception as e:
        logging.exception("OWNER WHOLESALE ORDER ERROR: %s", e)
        print("🔥 OWNER WHOLESALE ERROR:", type(e).__name__, str(e), flush=True)
        await query.message.reply_text(
            "❌ <b>ORDER FAILED</b>\n\n"
            "Panel Store API से order नहीं हो पाया।\n"
            "Panel Store balance/API check करो।",
            parse_mode="HTML"
        )
        return

    license_key = (
        result.get("license_key")
        or result.get("data", {}).get("license_key")
    )

    order_code = (
        result.get("order_code")
        or result.get("data", {}).get("order_code")
        or "N/A"
    )

    if not license_key:
        logging.error("OWNER ORDER NO LICENSE: %s", result)

        await query.message.reply_text(
            "⚠️ <b>ORDER RESPONSE RECEIVED</b>\n\n"
            f"PID: <code>{pid}</code>\n"
            f"Order: <code>{order_code}</code>\n\n"
            "लेकिन license key API response में नहीं मिली।",
            parse_mode="HTML"
        )
        return

    save_successful_key_histories(
        user_id=query.from_user.id,
        product=product["name"],
        duration=package["duration"],
        pid=pid,
        price=float(wholesale),
        license_key=license_key,
        order_code=order_code,
        payment_order_id=f"wholesale:{order_code}",
    )

    logging.info(
        "OWNER_SUCCESS_HISTORY_SAVED: user=%s order=%s",
        query.from_user.id,
        order_code,
    )

    remaining = (
        result.get("remaining_balance")
        or result.get("data", {}).get("remaining_balance")
    )

    text = (
        "👑 <b>OWNER PURCHASE SUCCESS</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"🛒 Product: <b>{product['name']}</b>\n"
        f"⏱️ Validity: <b>{package['duration']}</b>\n"
        f"🆔 PID: <code>{pid}</code>\n"
        f"💰 Wholesale Paid: <b>₹{wholesale:.2f}</b>\n"
        f"📦 Order: <code>{order_code}</code>\n\n"
        "🔑 <b>LICENSE KEY</b>\n"
        f"<code>{license_key}</code>"
    )

    if remaining is not None:
        text += (
            f"\n\n💳 Panel Balance Left: "
            f"<b>₹{remaining}</b>"
        )

    await query.message.reply_text(
        text,
        parse_mode="HTML"
    )


async def reseller_buy_product(query, category_key, index, package_index):
    await query.answer("⏳ Order processing...")
    user_id = query.from_user.id
    if str(user_id) not in RESELLERS:
        await query.answer("❌ Reseller access नहीं है।", show_alert=True)
        return
    category = PRODUCTS.get(category_key)
    try:
        product = category["products"][int(index)]
        package = product["packages"][int(package_index)]
    except (TypeError, ValueError, KeyError, IndexError):
        await query.message.reply_text("❌ Invalid product/package.")
        return
    if package.get("stock", True) is False:
        await query.answer("❌ OUT OF STOCK", show_alert=True)
        return
    pid = package.get("pid") or product.get("pid")
    wholesale = get_wholesale_rate(pid)
    if not pid or wholesale is None:
        await query.message.reply_text("❌ Wholesale PID/rate available नहीं है।", parse_mode="HTML")
        return
    balance = float(get_balance(user_id))
    if balance < float(wholesale):
        await query.message.reply_text(f"❌ <b>INSUFFICIENT BALANCE</b>\n\n💰 Required: <b>₹{float(wholesale):.2f}</b>\n💳 Your Balance: <b>₹{balance:.2f}</b>", parse_mode="HTML")
        return
    try:
        result = await panel_api_order(pid=pid, quantity=1, custom_notes=f"Reseller purchase {user_id}")
        license_key = result.get("license_key") or result.get("data", {}).get("license_key")
        order_code = result.get("order_code") or result.get("data", {}).get("order_code") or "N/A"
        if not license_key:
            await query.message.reply_text("⚠️ Order हुआ लेकिन license key नहीं मिली। Balance नहीं काटा गया।", parse_mode="HTML")
            return
    except Exception as e:
        logging.exception("RESELLER ORDER ERROR: %s", e)
        await query.message.reply_text("❌ <b>ORDER FAILED</b>\n\nPanel Store API से order नहीं हो पाया।\nBalance नहीं काटा गया।", parse_mode="HTML")
        return
    remove_balance(user_id, float(wholesale))
    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute('INSERT INTO wholesale_history (user_id, product, duration, pid, wholesale, license_key, order_code, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime("now", "localtime"))', (str(user_id), product["name"], package["duration"], str(pid), float(wholesale), license_key, order_code))
        conn.commit()
        conn.close()
    except Exception:
        logging.exception("RESELLER HISTORY SAVE ERROR")

    # Save reseller key purchase in User History
    try:
        save_purchase_history(
            user_id=user_id,
            product=product["name"],
            duration=package["duration"],
            pid=pid,
            price=float(wholesale),
            license_key=license_key,
            order_code=order_code,
            payment_order_id=f"wholesale:{order_code}",
        )
        logging.info(
            "RESELLER PURCHASE HISTORY SAVED: user=%s order=%s",
            user_id,
            order_code,
        )
    except Exception:
        logging.exception("RESELLER PURCHASE HISTORY SAVE ERROR")

    await query.message.reply_text(f"✅ <b>RESELLER ORDER SUCCESS</b>\n━━━━━━━━━━━━━━━━━━\n\n📦 Product: <b>{product['name']}</b>\n⏱️ Validity: <b>{package['duration']}</b>\n🆔 PID: <code>{pid}</code>\n💰 Paid: <b>₹{float(wholesale):.2f}</b>\n💳 Balance Left: <b>₹{float(get_balance(user_id)):.2f}</b>\n📦 Order: <code>{order_code}</code>\n\n🔑 <b>LICENSE KEY</b>\n<code>{license_key}</code>", parse_mode="HTML")

# ==================================================
# BUY PRODUCT
# ==================================================

def init_message_cleanup_db():
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS bot_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id TEXT NOT NULL,
            message_id INTEGER NOT NULL,
            created_at REAL NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def save_bot_message(message):
    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO bot_messages (chat_id, message_id, created_at) VALUES (?, ?, ?)",
            (str(message.chat_id), int(message.message_id), time.time())
        )
        conn.commit()
        conn.close()
    except Exception:
        logging.exception("MESSAGE SAVE ERROR")


async def delete_after_15_minutes(message):
    try:
        await asyncio.sleep(900)
        await message.delete()
    except Exception:
        pass

    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute(
            "DELETE FROM bot_messages WHERE chat_id=? AND message_id=?",
            (str(message.chat_id), int(message.message_id))
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


async def cleanup_old_bot_messages(bot):
    try:
        cutoff = time.time() - 900

        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute(
            "SELECT id, chat_id, message_id FROM bot_messages WHERE created_at <= ?",
            (cutoff,)
        )
        rows = cur.fetchall()

        for row_id, chat_id, message_id in rows:
            try:
                await bot.delete_message(
                    chat_id=int(chat_id),
                    message_id=int(message_id)
                )
            except Exception:
                pass

            cur.execute(
                "DELETE FROM bot_messages WHERE id=?",
                (row_id,)
            )

        conn.commit()
        conn.close()

    except Exception:
        logging.exception("OLD MESSAGE CLEANUP ERROR")


_original_extbot_send_message = ExtBot.send_message


async def _auto_delete_send_message(self, *args, **kwargs):
    message = await _original_extbot_send_message(self, *args, **kwargs)
    save_bot_message(message)
    asyncio.create_task(delete_after_15_minutes(message))
    return message


ExtBot.send_message = _auto_delete_send_message


_original_extbot_send_photo = ExtBot.send_photo


async def _auto_delete_send_photo(self, *args, **kwargs):
    message = await _original_extbot_send_photo(self, *args, **kwargs)
    save_bot_message(message)
    asyncio.create_task(delete_after_15_minutes(message))
    return message


ExtBot.send_photo = _auto_delete_send_photo


init_message_cleanup_db()


async def handle_payment_utr(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    order_id = PAYMENT_UTR_USERS.get(user_id)

    if not order_id:
        return

    utr = (update.message.text or "").strip()

    # UTR 12 digit होना चाहिए
    if not utr.isdigit() or len(utr) != 12:
        await update.message.reply_text(
            "❌ <b>Invalid UTR</b>\n\n"
            "कृपया सिर्फ <b>12 अंकों का UTR</b> भेजें।",
            parse_mode="HTML",
            reply_markup=ForceReply(
                selective=True,
                input_field_placeholder="12 अंकों का UTR डालें"
            )
        )
        return

    payment = get_payment_order(order_id)

    if not payment or str(payment.get("user_id")) != str(user_id):
        PAYMENT_UTR_USERS.pop(user_id, None)
        await update.message.reply_text(
            "❌ Payment order नहीं मिला या expire हो चुका है।"
        )
        return

    if payment.get("credited"):
        PAYMENT_UTR_USERS.pop(user_id, None)
        await update.message.reply_text(
            "✅ यह payment पहले ही credit हो चुका है।"
        )
        return

    utr = utr.upper()

    # UTR database में save
    update_payment_order(
        order_id,
        submitted_utr=utr
    )

    if order_id in PAYMENTS:
        PAYMENTS[order_id]["submitted_utr"] = utr

    PAYMENT_UTR_USERS.pop(user_id, None)

    # अब सिर्फ CHECK PAYMENT
    await update.message.reply_text(
        "✅ <b>UTR SUBMITTED</b>\n\n"
        f"🔢 UTR: <code>{utr}</code>\n\n"
        "अब नीचे <b>CHECK PAYMENT</b> दबाएँ।",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "✅ CHECK PAYMENT",
                    callback_data="check_payment",
                    style="success"
                )
            ]
        ])
    )


def save_successful_key_histories(
    user_id,
    product,
    duration,
    pid,
    price,
    license_key,
    order_code,
    payment_order_id=None,
):
    """Save a successful key purchase to both user and wholesale history."""

    if not license_key:
        return

    try:
        save_purchase_history(
            user_id=user_id,
            product=product,
            duration=duration,
            pid=pid,
            price=price,
            license_key=license_key,
            order_code=order_code,
            payment_order_id=payment_order_id,
        )
    except Exception:
        logging.exception("PURCHASE HISTORY SAVE ERROR")

    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()

        # Prevent duplicate wholesale-history entries
        exists = cur.execute(
            """
            SELECT id FROM wholesale_history
            WHERE order_code=?
            LIMIT 1
            """,
            (str(order_code or "N/A"),)
        ).fetchone()

        if not exists:
            cur.execute(
                """
                INSERT INTO wholesale_history
                (
                    user_id,
                    product,
                    duration,
                    pid,
                    wholesale,
                    order_code,
                    license_key,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now','localtime'))
                """,
                (
                    str(user_id),
                    str(product),
                    str(duration),
                    str(pid),
                    float(price),
                    str(order_code or "N/A"),
                    str(license_key),
                )
            )

        conn.commit()
        conn.close()

    except Exception:
        logging.exception("WHOLESALE HISTORY SAVE ERROR")

def get_wholesale_history(limit=500):
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS wholesale_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            product TEXT,
            duration TEXT,
            pid TEXT,
            wholesale REAL,
            order_code TEXT,
            license_key TEXT,
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        SELECT
            id,
            user_id,
            product,
            duration,
            pid,
            wholesale,
            license_key,
            order_code,
            created_at
        FROM wholesale_history
        ORDER BY id DESC
        LIMIT ?
    """, (int(limit),))

    rows = cur.fetchall()

    conn.close()
    return rows


def init_purchase_history_db():
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS purchase_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            product TEXT,
            duration TEXT,
            pid TEXT,
            price REAL,
            license_key TEXT,
            order_code TEXT,
            payment_order_id TEXT,
            created_at TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


def save_purchase_history(
    user_id,
    product,
    duration,
    pid,
    price,
    license_key,
    order_code,
    payment_order_id=None
):
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()

    if payment_order_id:
        exists = cur.execute(
            "SELECT id FROM purchase_history WHERE payment_order_id=? LIMIT 1",
            (str(payment_order_id),)
        ).fetchone()

        if exists:
            conn.close()
            return

    cur.execute("""
        INSERT INTO purchase_history
        (
            user_id,
            product,
            duration,
            pid,
            price,
            license_key,
            order_code,
            payment_order_id,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now','localtime'))
    """, (
        str(user_id),
        str(product),
        str(duration),
        str(pid),
        float(price),
        str(license_key),
        str(order_code or "N/A"),
        str(payment_order_id) if payment_order_id else None
    ))

    conn.commit()
    conn.close()


init_purchase_history_db()

# ==================================================
# HISTORY
# ==================================================

async def history(query):
    await query.answer()

    user_id = query.from_user.id

    conn = sqlite3.connect("keybot.db")
    rows = conn.execute("""
        SELECT
            product,
            duration,
            pid,
            price,
            license_key,
            order_code,
            created_at
        FROM purchase_history
        WHERE user_id=?
          AND license_key IS NOT NULL
          AND TRIM(license_key) <> ''
        ORDER BY id DESC
        LIMIT 100
    """, (str(user_id),)).fetchall()
    conn.close()

    if not rows:
        history_text = (
            "📭 <b>KEY PURCHASE HISTORY</b>\n\n"
            "अभी कोई successful key purchase history नहीं है।"
        )
    else:
        parts = []

        for product, duration, pid, price, license_key, order_code, created_at in rows:
            parts.append(
                f"📦 <b>{product}</b>\n"
                f"⏱️ Validity: <b>{duration}</b>\n"
                f"🆔 PID: <code>{pid}</code>\n"
                f"💰 Price: <b>₹{float(price):g}</b>\n"
                f"📦 Order: <code>{order_code}</code>\n"
                f"🔑 Key: <code>{license_key}</code>\n"
                f"🕒 {created_at}"
            )

        history_text = "\n\n━━━━━━━━━━━━━━━━━━\n\n".join(parts)

    await query.edit_message_text(
        "📜 <b>KEY PURCHASE HISTORY</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        + history_text,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="home",
                    style="danger"
                )
            ]
        ])
    )


# ==================================================
# TUTORIAL
# ==================================================

async def tutorial(query):
    await query.answer()

    await query.edit_message_text(
        "📚 <b>TUTORIAL</b>\n\n"
        "1️⃣ Product Store खोलें.\n"
        "2️⃣ Panel select करें.\n"
        "3️⃣ Plan select करें.\n"
        "4️⃣ Add Balance से payment करें.\n"
        "5️⃣ Payment verify होने के बाद अपना product खरीदें.\n\n"
        "अगर कोई समस्या आए तो 🆘 Support पर संपर्क करें.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("↩️ BACK", callback_data="home", style="danger")]
        ])
    )


# ==================================================
# SUPPORT
# ==================================================

async def support(query):
    await query.answer()

    await query.edit_message_text(
        "🆘 <b>SUPPORT</b>\n\n"
        "किसी भी समस्या के लिए नीचे Support button दबाएँ।\n\n"
        "📩 Order ID और अपनी समस्या जरूर भेजें।",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🆘 CONTACT SUPPORT",
                    url=OWNER_LINKS["support"],
                    style="primary"
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="home",
                    style="danger"
                )
            ]
        ])
    )

async def ludo_spin(query):
    import sqlite3
    import random
    from datetime import datetime, timezone, timedelta

    user_id = query.from_user.id
    is_owner = str(user_id) == str(OWNER_ID)

    db_path = "keybot.db"

    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS ludo_demo (
            user_id INTEGER PRIMARY KEY,
            balance REAL NOT NULL DEFAULT 0,
            last_spin TEXT
        )
    """)
    conn.commit()

    cur.execute(
        "SELECT balance, last_spin FROM ludo_demo WHERE user_id = ?",
        (user_id,)
    )
    row = cur.fetchone()

    balance = float(row[0]) if row else 0.0
    last_spin = row[1] if row else None

    now = datetime.now(timezone.utc)

    # Owner: unlimited spin.
    # 24-hour timer is only shown after spin.
    if last_spin and not is_owner:
        last_time = datetime.fromisoformat(last_spin)
        next_spin = last_time + timedelta(hours=24)

        if now < next_spin:
            remaining = next_spin - now
            hours = int(remaining.total_seconds() // 3600)
            minutes = int((remaining.total_seconds() % 3600) // 60)

            await query.answer()
            await query.edit_message_text(
                "🎲 <b>LUDO SPIN</b>\\n\\n"
                "⏳ अगला Spin available नहीं है.\\n\\n"
                f"🕐 फिर से try करें: <b>{hours}h {minutes}m</b> बाद\\n"
                f"💰 Balance: <b>₹{balance:.2f}</b>",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("↩️ BACK", callback_data="home", style="danger")]
                ])
            )
            conn.close()
            return

    # Demo/internal reward
    reward = random.choice([10, 20, 30])
    balance += reward

    cur.execute("""
        INSERT INTO ludo_demo (user_id, balance, last_spin)
        VALUES (?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            balance = excluded.balance,
            last_spin = excluded.last_spin
    """, (user_id, balance, now.isoformat()))

    conn.commit()
    conn.close()

    await query.answer("🎉 Spin Complete!")

    text = (
        "🎲 <b>LUDO SPIN</b>\\n\\n"
        "🎉 <b>SPIN COMPLETE!</b>\\n\\n"
        f"💰 Reward: <b>₹{reward}</b>\\n"
        f"📊 Record Balance: <b>₹{balance:.2f}</b>\\n\\n"
        "⏳ अगला Spin: <b>24 घंटे बाद</b>"
    )

    if is_owner:
        text += "\\n\\n👑 <b>OWNER MODE:</b> आप फिर से Spin कर सकते हैं।"

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🎲 SPIN AGAIN", callback_data="ludo", style="primary")],
        [InlineKeyboardButton("↩️ BACK", callback_data="home", style="danger")]
    ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )

async def downloads(query):
    await query.answer()

    await query.edit_message_text(
        "📥 <b>DOWNLOAD FILES</b>\n\n"
        "👇 नीचे button दबाकर सभी files/download channel खोलें।",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "📥 OPEN DOWNLOAD CHANNEL",
                    url=OWNER_LINKS["downloads"],
                    style="primary"
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="home",
                    style="danger"
                )
            ]
        ])
    )

async def handle_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if user_id not in BROADCAST_USERS:
        return

    if str(user_id) != str(OWNER_ID):
        BROADCAST_USERS.discard(user_id)
        return

    if not update.message or not update.message.text:
        return

    message = update.message.text.strip()

    if message.lower() == "/cancel":
        BROADCAST_USERS.discard(user_id)
        await update.message.reply_text("❌ Broadcast cancelled.")
        return

    BROADCAST_USERS.discard(user_id)

    # Load all registered users directly from database
    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM users")
        users = {int(row[0]) for row in cur.fetchall() if row[0]}
        conn.close()
    except Exception as e:
        logging.exception("Broadcast user database error: %s", e)
        users = set(USERS)

    sent = 0
    failed = 0

    for target_id in users:
        try:
            await context.bot.send_message(
                chat_id=target_id,
                text=message
            )
            sent += 1
        except Exception as e:
            failed += 1
            logging.warning(
                "Broadcast failed for %s: %s",
                target_id,
                e
            )

    await update.message.reply_text(
        "📢 <b>BROADCAST COMPLETE</b>\\n\\n"
        f"✅ Sent: <b>{sent}</b>\\n"
        f"❌ Failed: <b>{failed}</b>",
        parse_mode="HTML"
    )


async def handle_custom_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if user_id not in CUSTOM_DEPOSIT_USERS:
        return

    try:
        amount = float(update.message.text.strip())
    except (ValueError, AttributeError):
        await update.message.reply_text("❌ केवल amount भेजें। Example: 150")
        return

    if amount < 1 or amount > 10000:
        await update.message.reply_text("❌ Amount ₹1 से ₹10,000 के बीच होना चाहिए।")
        return

    CUSTOM_DEPOSIT_USERS.pop(user_id, None)

    if not UPI_ID:
        await update.message.reply_text("❌ Payment system configured नहीं है।")
        return

    try:
        response = requests.get(
            f"{FAMPAY_BASE}/qr.php",
            params={"upi": UPI_ID, "amount": amount},
            timeout=15,
        )
        response.raise_for_status()
        api = response.json()
    except Exception:
        logging.exception("CUSTOM QR API ERROR")
        await update.message.reply_text("❌ QR बनाने में error आया।")
        return

    if api.get("status") != "success":
        await update.message.reply_text("❌ Payment API ने QR create नहीं किया।")
        return

    qr_data = api.get("data") or {}
    order_id = qr_data.get("order_id")
    qr_url = qr_data.get("qr_url")
    try:
        returned_amount = float(qr_data.get("amount", amount))
    except (TypeError, ValueError):
        returned_amount = -1

    if not order_id or not qr_url or abs(returned_amount - amount) > 0.001:
        await update.message.reply_text("❌ Payment API ने invalid QR/amount दिया।")
        return

    try:
        save_payment_order(order_id, user_id, amount, payment_type="deposit")
    except sqlite3.IntegrityError:
        await update.message.reply_text("❌ Duplicate payment order मिला। नया QR generate करें।")
        return

    PAYMENTS[order_id] = {
        "user_id": user_id,
        "amount": amount,
        "status": "pending",
        "type": "deposit",
        "created_at": time.time(),
        "submitted_utr": None,
    }

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔐 SUBMIT UTR", callback_data="submit_utr", style="primary")],
        [InlineKeyboardButton("↩️ BACK", callback_data="deposit", style="danger")],
    ])

    caption = (
        "💰 <b>CUSTOM DEPOSIT</b>\n\n"
        f"💵 Amount: <b>₹{amount:g}</b>\n"
        f"🆔 Order ID: <code>{order_id}</code>\n"
        f"💳 UPI: <code>{qr_data.get('upi_id') or UPI_ID}</code>\n\n"
        "📲 QR scan करके payment करें।\n"
        "Payment के बाद UTR submit करके CHECK PAYMENT करें।"
    )

    try:
        qr_response = requests.get(qr_url, timeout=15)
        qr_response.raise_for_status()
        if "image" not in qr_response.headers.get("content-type", "").lower():
            raise ValueError("QR URL did not return image")
        sent_qr = await update.message.reply_photo(
            photo=qr_response.content,
            caption=caption,
            parse_mode="HTML",
            reply_markup=keyboard,
        )
        update_payment_order(order_id, message_id=sent_qr.message_id)
        PAYMENTS[order_id]["message_id"] = sent_qr.message_id
        asyncio.create_task(expire_qr_message(context.bot, user_id, order_id))
    except Exception:
        logging.exception("CUSTOM QR IMAGE ERROR")
        await update.message.reply_text(caption, parse_mode="HTML", reply_markup=keyboard)

async def owner_reseller_users(query):
    if str(query.from_user.id) != str(OWNER_ID):
        await query.answer("❌ Access Denied", show_alert=True)
        return

    await query.answer()

    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute("SELECT user_id, activated_at FROM reseller_users ORDER BY user_id")
        rows = cur.fetchall()
        conn.close()
    except sqlite3.Error:
        rows = []

    if not rows:
        await query.edit_message_text(
            "🤝 <b>RESELLER USERS</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "❌ अभी कोई reseller saved नहीं है.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "↩️ BACK",
                        callback_data="owner:back",
                        style="danger"
                    )
                ]
            ])
        )
        return

    buttons = []

    for uid, activated_at in rows:
        try:
            balance = float(BALANCES.get(int(uid), 0))
        except Exception:
            balance = 0.0

        active = bool(activated_at and float(activated_at) > 0)
        status = "🟢" if active else "🔴"

        buttons.append([
            InlineKeyboardButton(
                f"{status} 🤝 {uid} — ₹{balance:.2f}",
                callback_data=f"owner:reseller:{uid}",
                style="success" if active else "danger"
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            "↩️ BACK",
            callback_data="owner:back",
            style="danger"
        )
    ])

    await query.edit_message_text(
        "🤝 <b>RESELLER USERS</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"👥 Total Resellers: <b>{len(rows)}</b>\n"
        "🟢 Active   🔴 Deactivated",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def owner_reseller_details(query, user_id):
    if str(query.from_user.id) != str(OWNER_ID):
        await query.answer("❌ Access Denied", show_alert=True)
        return

    await query.answer()

    uid = str(user_id)

    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()

        cur.execute(
            "SELECT activated_at FROM reseller_users WHERE user_id=?",
            (uid,)
        )
        reseller_row = cur.fetchone()

        cur.execute(
            "SELECT first_name, last_name, username, phone FROM users WHERE user_id=?",
            (uid,)
        )
        user_row = cur.fetchone()

        conn.close()
    except sqlite3.Error:
        reseller_row = None
        user_row = None

    if not reseller_row:
        await query.answer(
            "❌ यह user reseller list में नहीं है.",
            show_alert=True
        )
        return

    activated_at = reseller_row[0]
    active = bool(activated_at and float(activated_at) > 0)

    if user_row:
        first_name, last_name, db_username, phone = user_row

        name = " ".join(
            x for x in [first_name or "", last_name or ""]
            if x
        ).strip() or "Not set"

        username = f"@{db_username}" if db_username else "Not set"
        phone = phone or "Not shared"
    else:
        name = "Not set"
        username = "Not set"
        phone = "Not shared"

    try:
        balance = float(BALANCES.get(int(uid), 0))
    except Exception:
        balance = 0.0

    if active:
        status = "🟢 ACTIVE"
        action_button = InlineKeyboardButton(
            "🔴 DEACTIVATE RESELLER",
            callback_data=f"owner:reseller:deactivate:{uid}",
            style="danger"
        )
    else:
        status = "🔴 DEACTIVATED"
        action_button = InlineKeyboardButton(
            "🟢 ACTIVATE RESELLER",
            callback_data=f"owner:reseller:activate:{uid}",
            style="success"
        )

    keyboard = InlineKeyboardMarkup([
        [action_button],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data="owner:resellers",
                style="danger"
            )
        ]
    ])

    await query.edit_message_text(
        "🤝 <b>RESELLER DETAILS</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"👤 Name: <b>{name}</b>\n"
        f"🔹 Username: <b>{username}</b>\n"
        f"📱 Mobile: <code>{phone}</code>\n"
        f"🆔 User ID: <code>{uid}</code>\n"
        f"🤝 Status: <b>{status}</b>\n"
        f"💰 Balance: <b>₹{balance:.2f}</b>\n\n"
        "👇 <b>Action चुनें:</b>",
        parse_mode="HTML",
        reply_markup=keyboard
    )

async def owner_users(query):
    if str(query.from_user.id) != str(OWNER_ID):
        await query.answer("❌ Access Denied", show_alert=True)
        return

    await query.answer()

    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM users")
        total_users = cur.fetchone()[0]
        conn.close()
    except sqlite3.Error:
        total_users = len(USERS)

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🔎 SEARCH USER",
                callback_data="owner:user_search",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data="owner:back",
                style="danger"
            )
        ]
    ])

    await query.edit_message_text(
        "👥 <b>USERS</b>\\n"
        "━━━━━━━━━━━━━━━━━━\\n\\n"
        f"👥 Total Users: <b>{total_users}</b>\\n\\n"
        "🔎 <b>Search User</b>\\n"
        "Name, Username, Mobile Number या User ID से search करें।",
        parse_mode="HTML",
        reply_markup=keyboard
    )

async def owner_user_details(query, user_id):
    if str(query.from_user.id) != str(OWNER_ID):
        await query.answer("❌ Access Denied", show_alert=True)
        return

    await query.answer()

    try:
        uid = int(user_id)
    except ValueError:
        await query.answer("❌ Invalid User ID", show_alert=True)
        return

    name = "Not set"
    username = "Not set"
    phone = "Not shared"

    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute(
            "SELECT first_name, last_name, username, phone FROM users WHERE user_id=?",
            (str(uid),)
        )
        row = cur.fetchone()
        conn.close()

        if row:
            first_name, last_name, db_username, db_phone = row
            full_name = " ".join(
                x for x in [first_name or "", last_name or ""]
                if x
            ).strip()
            name = full_name or "Not set"
            username = f"@{db_username}" if db_username else "Not set"
            phone = db_phone or "Not shared"

    except sqlite3.Error:
        pass

    try:
        balance = float(BALANCES.get(uid, 0))
    except (TypeError, ValueError):
        balance = 0.0

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "➕ ADD BALANCE",
                callback_data=f"owner:add:{uid}",
                style="success"
            )
        ],
        [
            InlineKeyboardButton(
                "➖ REMOVE BALANCE",
                callback_data=f"owner:remove:{uid}",
                style="danger"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ BACK",
                callback_data="owner:users",
                style="danger"
            )
        ]
    ])

    await query.edit_message_text(
        "👤 <b>USER DETAILS</b>\\n"
        "━━━━━━━━━━━━━━━━━━\\n\\n"
        f"👤 Name: <b>{name}</b>\\n"
        f"🔹 Username: <b>{username}</b>\\n"
        f"📱 Mobile: <code>{phone}</code>\\n"
        f"🆔 User ID: <code>{uid}</code>\\n"
        f"💰 Balance: <b>₹{balance:.2f}</b>\\n\\n"
        "👇 <b>Action चुनें:</b>",
        parse_mode="HTML",
        reply_markup=keyboard
    )

async def owner_balance_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    # OWNER ONLY
    if str(user.id) != str(OWNER_ID):
        return

    # USER SEARCH
    if context.user_data.get("owner_user_search"):
        search = update.message.text.strip()

        if not search:
            await update.message.reply_text("❌ Search खाली नहीं हो सकता.")
            return

        context.user_data.pop("owner_user_search", None)

        try:
            conn = sqlite3.connect("keybot.db")
            cur = conn.cursor()

            like = f"%{search}%"

            cur.execute(
                "SELECT user_id, first_name, last_name, username, phone "
                "FROM users "
                "WHERE CAST(user_id AS TEXT) LIKE ? "
                "OR username LIKE ? "
                "OR first_name LIKE ? "
                "OR last_name LIKE ? "
                "OR phone LIKE ? "
                "ORDER BY user_id",
                (like, like, like, like, like)
            )

            rows = cur.fetchall()
            conn.close()

        except sqlite3.Error:
            rows = []

        if not rows:
            await update.message.reply_text(
                "❌ <b>User नहीं मिला</b>\\n\\n"
                f"🔎 Search: <code>{search}</code>",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton(
                            "🔎 SEARCH AGAIN",
                            callback_data="owner:user_search",
                            style="primary"
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "↩️ USERS",
                            callback_data="owner:users",
                            style="danger"
                        )
                    ]
                ])
            )
            return

        buttons = []

        for uid, first_name, last_name, username, phone in rows:
            name = " ".join(
                x for x in [first_name or "", last_name or ""]
                if x
            ).strip() or "Unknown"

            display_username = f"@{username}" if username else "No username"

            buttons.append([
                InlineKeyboardButton(
                    f"👤 {name} | {display_username}",
                    callback_data=f"owner:user:{uid}",
                    style="primary"
                )
            ])

        buttons.append([
            InlineKeyboardButton(
                "↩️ USERS",
                callback_data="owner:users",
                style="danger"
            )
        ])

        await update.message.reply_text(
            "🔎 <b>SEARCH RESULTS</b>\\n"
            "━━━━━━━━━━━━━━━━━━\\n\\n"
            f"Search: <code>{search}</code>\\n"
            f"Found: <b>{len(rows)}</b>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    action = context.user_data.get("owner_balance_action")
    target_id = context.user_data.get("owner_balance_user")

    if not action or not target_id:
        return

    try:
        amount = float(update.message.text.strip().replace(",", ""))
    except ValueError:
        await update.message.reply_text(
            "❌ केवल सही amount भेजो.\\n\\n"
            "उदाहरण: <code>100</code>",
            parse_mode="HTML"
        )
        return

    if amount <= 0:
        await update.message.reply_text(
            "❌ Amount 0 से ज्यादा होना चाहिए."
        )
        return

    try:
        uid = int(target_id)
    except ValueError:
        context.user_data.pop("owner_balance_action", None)
        context.user_data.pop("owner_balance_user", None)
        await update.message.reply_text("❌ Invalid User ID")
        return

    owner_id = int(OWNER_ID)

    user_balance = float(get_balance(uid))
    owner_balance = float(get_balance(owner_id))

    if action == "add":
        # Owner -> User
        if amount > owner_balance:
            await update.message.reply_text(
                f"❌ Owner balance पर्याप्त नहीं है.\\n\\n"
                f"💰 Owner Balance: ₹{owner_balance:.2f}"
            )
            return

        remove_balance(owner_id, amount)
        add_balance(uid, amount)

        action_text = "➕ Added"

    elif action == "remove":
        # User -> Owner
        if amount > user_balance:
            await update.message.reply_text(
                f"❌ User का balance इतना नहीं है.\\n\\n"
                f"💰 User Balance: ₹{user_balance:.2f}"
            )
            return

        remove_balance(uid, amount)
        add_balance(owner_id, amount)

        action_text = "➖ Removed"

    else:
        context.user_data.clear()
        return

    new_user_balance = float(get_balance(uid))
    new_owner_balance = float(get_balance(owner_id))

    context.user_data.pop("owner_balance_action", None)
    context.user_data.pop("owner_balance_user", None)

    await update.message.reply_text(
        "✅ <b>BALANCE UPDATED</b>\\n\\n"
        f"👤 User ID: <code>{uid}</code>\\n"
        f"{action_text}: <b>₹{amount:.2f}</b>\\n\\n"
        f"💰 User Balance: <b>₹{new_user_balance:.2f}</b>\\n"
        f"👑 Owner Balance: <b>₹{new_owner_balance:.2f}</b>",
        parse_mode="HTML"
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data

    if data.startswith("owner:add:"):
        if str(query.from_user.id) != str(OWNER_ID):
            await query.answer("❌ Access Denied", show_alert=True)
            return

        uid = data.split(":")[2]
        context.user_data["owner_balance_action"] = "add"
        context.user_data["owner_balance_user"] = uid

        await query.answer()
        await query.edit_message_text(
            "➕ <b>ADD BALANCE</b>\n\n"
            f"🆔 User ID: <code>{uid}</code>\n\n"
            "💰 Amount भेजो:\n"
            "उदाहरण: <code>100</code>",
            parse_mode="HTML"
        )
        return

    if data.startswith("owner:remove:"):
        if str(query.from_user.id) != str(OWNER_ID):
            await query.answer("❌ Access Denied", show_alert=True)
            return

        uid = data.split(":")[2]
        context.user_data["owner_balance_action"] = "remove"
        context.user_data["owner_balance_user"] = uid

        await query.answer()
        await query.edit_message_text(
            "➖ <b>REMOVE BALANCE</b>\n\n"
            f"🆔 User ID: <code>{uid}</code>\n\n"
            "💰 Amount भेजो:\n"
            "उदाहरण: <code>50</code>",
            parse_mode="HTML"
        )
        return

    if data == "owner:resellers":
        await owner_reseller_users(query)
        return

    if data.startswith("owner:reseller:activate:"):
        if str(query.from_user.id) != str(OWNER_ID):
            await query.answer("❌ Access Denied", show_alert=True)
            return

        uid = data.split(":")[3]

        try:
            conn = sqlite3.connect("keybot.db")
            cur = conn.cursor()
            cur.execute(
                "UPDATE reseller_users SET activated_at=? WHERE user_id=?",
                (time.time(), uid)
            )
            conn.commit()
            conn.close()

            RESELLERS.add(uid)

            await query.answer("🟢 Reseller Activated", show_alert=True)
            await owner_reseller_details(query, uid)

        except sqlite3.Error:
            await query.answer(
                "❌ Database error",
                show_alert=True
            )

        return

    if data.startswith("owner:reseller:deactivate:"):
        if str(query.from_user.id) != str(OWNER_ID):
            await query.answer("❌ Access Denied", show_alert=True)
            return

        uid = data.split(":")[3]

        try:
            conn = sqlite3.connect("keybot.db")
            cur = conn.cursor()
            cur.execute(
                "UPDATE reseller_users SET activated_at=0 WHERE user_id=?",
                (uid,)
            )
            conn.commit()
            conn.close()

            RESELLERS.discard(uid)

            await query.answer("🔴 Reseller Deactivated", show_alert=True)
            await owner_reseller_details(query, uid)

        except sqlite3.Error:
            await query.answer(
                "❌ Database error",
                show_alert=True
            )

        return

    if data.startswith("owner:reseller:"):
        uid = data.split(":")[2]
        await owner_reseller_details(query, uid)
        return

    if data == "owner:users":
        await owner_users(query)
        return

    if data == "owner:user_search":
        if str(query.from_user.id) != str(OWNER_ID):
            await query.answer("❌ Access Denied", show_alert=True)
            return

        context.user_data["owner_user_search"] = True
        await query.answer()

        await query.edit_message_text(
            "🔎 <b>SEARCH USER</b>\\n"
            "━━━━━━━━━━━━━━━━━━\\n\\n"
            "Name, Username, Mobile Number या User ID भेजें।",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "❌ CANCEL",
                        callback_data="owner:users",
                        style="danger"
                    )
                ]
            ])
        )
        return

    data = query.data

    if data.startswith("owner:user:"):
        user_id = data.split(":")[2]
        await owner_user_details(query, user_id)
        return

    try:
        if data == "owner:home":
            if str(query.from_user.id) != str(OWNER_ID):
                await query.answer("Access Denied", show_alert=True)
                return
            await query.edit_message_text(
                "👑 <b>OWNER PANEL</b>\n\n"
                "नीचे से option चुनें:",
                parse_mode="HTML",
                reply_markup=owner_keyboard()
            )

        elif data == "open_admin":
            if str(query.from_user.id) != str(OWNER_ID):
                await query.answer("❌ Access Denied", show_alert=True)
                return

            await query.answer()
            await query.edit_message_text(
                "👑 <b>OWNER PANEL</b>\n\n"
                "Welcome Owner! नीचे से option चुनें:",
                parse_mode="HTML",
                reply_markup=owner_keyboard()
            )
            return

        elif data == "owner:back":
            await query.answer()
            await query.edit_message_text(
                "👑 <b>OWNER PANEL</b>\n\n"
                "Welcome Owner! नीचे से option चुनें:",
                parse_mode="HTML",
                reply_markup=owner_keyboard()
            )
            return

        elif data == "owner:close":
            await query.answer()
            try:
                await query.message.delete()
            except Exception:
                await query.edit_message_text("❌ Owner Panel closed.")
            return

        elif data == "owner:broadcast":
            await broadcast_menu(query)
            return

        elif data.startswith("ownerconfirm:"):
            parts = data.split(":")
            if len(parts) != 4:
                await query.answer("❌ Invalid order", show_alert=True)
                return

            await owner_confirm_purchase(
                query,
                parts[1],
                int(parts[2]),
                int(parts[3])
            )
            return

        elif data.startswith("ownerwcat:"):
            await query.answer()

            category_key = data.split(":", 1)[1]
            category = PRODUCTS.get(category_key)

            if not category:
                await query.answer("❌ Category not found", show_alert=True)
                return

            buttons = []

            # Running panels first, MAINTENANCE panels at bottom
            products = list(enumerate(category.get("products", [])))
            products.sort(
                key=lambda item: "MAINTENANCE" in item[1].get("name", "").upper()
            )

            for product_index, product in products:
                # Only show products which have at least one valid wholesale package
                valid_package = False
                for package in product.get("packages", []):
                    pid = package.get("pid") or product.get("pid")
                    if pid and get_wholesale_rate(pid) is not None:
                        if package.get("stock", True) is not False:
                            valid_package = True
                            break

                if not valid_package:
                    continue

                buttons.append([
                    InlineKeyboardButton(
                        panel_button_name(product["name"]),
                        callback_data=f"ownerwprod:{category_key}:{product_index}",
                        style="primary"
                    )
                ])

            buttons.append([
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data="owner:wholesale",
                    style="danger"
                )
            ])

            text = (
                f"📦 <b>{category['name']}</b>\\n"
                "━━━━━━━━━━━━━━━━━━\\n\\n"
                "🛡️ <b>SELECT PANEL</b>\\n"
                "सिर्फ Panel Name दिखाई देगा।"
            )

            await query.edit_message_text(
                text,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(buttons)
            )
            return

        elif data.startswith("ownerwprod:"):
            await query.answer()

            parts = data.split(":")
            category_key = parts[1]
            product_index = int(parts[2])

            category = PRODUCTS.get(category_key)
            if not category:
                return

            try:
                product = category["products"][product_index]
            except (IndexError, ValueError):
                await query.answer("❌ Invalid panel", show_alert=True)
                return

            buttons = []

            for package_index, package in enumerate(product.get("packages", [])):
                pid = package.get("pid") or product.get("pid")
                rate = get_wholesale_rate(pid)

                if not pid or rate is None:
                    continue

                if package.get("stock", True) is False:
                    continue

                buttons.append([
                    InlineKeyboardButton(
                        f"🛒 BUY {package['duration']} • 1 DEVICE — ₹{rate:.2f}",
                        callback_data=f"ownerbuy:{category_key}:{product_index}:{package_index}",
                        style="success"
                    )
                ])

            buttons.append([
                InlineKeyboardButton(
                    "↩️ BACK",
                    callback_data=f"ownerwcat:{category_key}",
                    style="danger"
                )
            ])

            text = (
                f"📦 <b>{product['name']}</b>\\n"
                "━━━━━━━━━━━━━━━━━━\\n\\n"
                "📱 <b>1 Device</b>\\n\\n"
                "नीचे package चुनकर direct order करें।"
            )

            await query.edit_message_text(
                text,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(buttons)
            )
            return

        elif data.startswith("ownerbuy:"):
            parts = data.split(":")
            if len(parts) != 4:
                await query.answer("❌ Invalid product", show_alert=True)
                return

            await owner_buy_product(
                query,
                parts[1],
                int(parts[2]),
                int(parts[3])
            )
            return

        elif data == "owner:wholesale_history":
            await query.answer()
            rows = get_wholesale_history(500)
            if not rows:
                text = "📜 <b>WHOLESALE HISTORY</b>\n━━━━━━━━━━━━━━━━━━\n\n📭 अभी कोई wholesale purchase history नहीं है।"
            else:
                lines = ["📜 <b>WHOLESALE HISTORY</b>", "━━━━━━━━━━━━━━━━━━", ""]
                for row in rows:
                    order_id, user_id, product_name, duration, pid, price, license_key, order_code, created_at = row
                    lines.append(f"🆔 <b>#{order_id}</b>\n📦 <b>{product_name}</b>\n⏱️ Validity: <b>{duration}</b>\n🆔 PID: <code>{pid}</code>\n💰 Paid: <b>₹{price:.2f}</b>\n📦 Order: <code>{order_code}</code>\n🔑 Key: <code>{license_key}</code>\n👤 Owner: <code>{user_id}</code>\n🕒 {created_at}\n━━━━━━━━━━━━━━━━━━")
                text = "\n".join(lines)
            buttons = [[InlineKeyboardButton("↩️ OWNER PANEL", callback_data="owner:back", style="danger")], [InlineKeyboardButton("❌ CLOSE", callback_data="owner:close", style="danger")]]
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))
            return
        elif data.startswith("owner:"):
            section = data.split(":", 1)[1]
            await owner_panel(query, section)
            return


        elif data == "reseller:activate":
            await reseller_activation(query)
            return

        elif data == "reseller:panel":
            await reseller_panel(query)
            return

        elif data == "home":
            await home(query)

        elif data == "products":
            await products_menu(query)

        elif data == "profile":
            await profile(query)

        elif data == "deposit":
            await deposit_menu(query)

        elif data == "custom_deposit":
            await custom_deposit(query)

        elif data.startswith("deposit:"):
            try:
                amount = int(data.split(":", 1)[1])
            except (ValueError, IndexError):
                await query.answer("Invalid amount", show_alert=True)
                return

            if amount not in (50, 100, 200, 500):
                await query.answer("Invalid amount", show_alert=True)
                return

            await create_qr(query, amount)

        elif data == "history":
            await history(query)

        elif data == "referral":
            await referral(query)

        elif data == "tutorial":
            await tutorial(query)

        elif data == "support":
            await support(query)

        elif data == "ludo":
            await ludo_spin(query)

        elif data == "downloads":
            await downloads(query)

        elif data.startswith("category:"):
            category_key = data.split(":", 1)[1]
            await category_menu(query, category_key)

        elif data.startswith("product:"):
            parts = data.split(":")
            category_key = parts[1]
            index = int(parts[2])
            await product_details(query, category_key, index)

        elif data.startswith("buy:"):
            parts = data.split(":")
            category_key = parts[1]
            index = int(parts[2])
            package_index = int(parts[3]) if len(parts) > 3 else 0
            await buy_product(query, category_key, index, package_index)

        elif data == "submit_utr":
            await request_payment_utr(query)

        elif data == "check_payment":
            await verify_payment(query)

        else:
            await query.answer("Unknown button", show_alert=True)

    except Exception as e:
        logging.exception("BUTTON HANDLER ERROR: %s", e)
        try:
            await query.answer("Something went wrong", show_alert=True)
        except Exception:
            pass

# ==================================================
# MAIN
# ==================================================


async def panel_api_balance():
    if not PANEL_API_KEY:
        raise RuntimeError("PANEL_API_KEY missing in .env")

    response = requests.post(
        PANEL_API_URL,
        json={
            "key": PANEL_API_KEY,
            "action": "balance",
        },
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


def owner_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "👥 USERS",
                callback_data="owner:users",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "📢 BROADCAST",
                callback_data="owner:broadcast",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "🛒 WHOLESALE STORE",
                callback_data="owner:wholesale",
                style="success"
            )
        ],
        [
            InlineKeyboardButton(
                "💳 PANEL BALANCE",
                callback_data="owner:balance",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "📦 ORDERS",
                callback_data="owner:orders",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "📜 WHOLESALE HISTORY",
                callback_data="owner:wholesale_history",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "🤝 RESELLER USERS",
                callback_data="owner:resellers",
                style="success"
            )
        ],
    ])

async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if str(update.effective_user.id) != str(OWNER_ID):
        await update.message.reply_text("❌ Access Denied")
        return

    await update.message.reply_text(
        "👑 <b>OWNER PANEL</b>\n\n"
        "Welcome Owner! नीचे से option चुनें:",
        parse_mode="HTML",
        reply_markup=owner_keyboard()
    )


async def broadcast_menu(query):
    if str(query.from_user.id) != str(OWNER_ID):
        await query.answer("Access Denied", show_alert=True)
        return

    await query.answer()

    BROADCAST_USERS.add(query.from_user.id)

    await query.message.reply_text(
        "📢 <b>BROADCAST</b>\\n\\n"
        "जो message सभी users को भेजना है, वह यहाँ भेजो.\\n\\n"
        "❌ Cancel करने के लिए /cancel भेजें.",
        parse_mode="HTML"
    )


async def owner_panel(query, section):
    await query.answer()

    if str(query.from_user.id) != str(OWNER_ID):
        await query.answer("Access Denied", show_alert=True)
        return

    if section == "dashboard":
        users = set(BALANCES.keys())
        total_balance = sum(BALANCES.values())
        text = (
            "📊 <b>OWNER DASHBOARD</b>\\n\\n"
            f"👥 Users: <b>{len(users)}</b>\\n"
            f"🛒 Orders: <b>{len(ORDERS)}</b>\\n"
            f"💳 Payments: <b>{len(PAYMENTS)}</b>\\n"
            f"💰 User Balance: <b>₹{total_balance}</b>"
        )

    elif section == "users":
        text = (
            "👥 <b>USERS</b>\\n\\n"
            f"Total Users: <b>{len(set(BALANCES.keys()))}</b>"
        )

    elif section == "payments":
        pending = sum(1 for x in PAYMENTS.values()
                      if x.get("status") == "pending")
        paid = sum(1 for x in PAYMENTS.values()
                   if x.get("status") == "paid")
        text = (
            "💳 <b>PAYMENTS</b>\\n\\n"
            f"📌 Total: <b>{len(PAYMENTS)}</b>\\n"
            f"⏳ Pending: <b>{pending}</b>\\n"
            f"✅ Paid: <b>{paid}</b>"
        )

    elif section == "orders":
        completed = sum(1 for x in ORDERS.values()
                        if x.get("status") == "completed")
        text = (
            "🛒 <b>ORDERS</b>\\n\\n"
            f"📦 Total: <b>{len(ORDERS)}</b>\\n"
            f"✅ Completed: <b>{completed}</b>"
        )

    elif section == "balance":
        try:
            result = await panel_api_balance()
            data = result.get("data", result)
            balance = data.get("balance", result.get("balance", "N/A"))
            currency = data.get("currency", result.get("currency", "INR"))
            text = (
                "💰 <b>PANEL STORE BALANCE</b>\\n\\n"
                f"💵 Balance: <b>{balance} {currency}</b>\\n\\n"
                "🌐 Panel Store API connected."
            )
        except Exception:
            text = "❌ <b>PANEL BALANCE ERROR</b>\\n\\nAPI balance check failed."

    elif section == "total":
        text = (
            "📈 <b>TOTAL / TUTORIAL</b>\\n\\n"
            "🎥 Tutorial देखने के लिए नीचे button दबाएँ।"
        )
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🎥 WATCH TUTORIAL", url=OWNER_LINKS["tutorial"], style="primary")],
            [InlineKeyboardButton("↩️ BACK", callback_data="owner:back", style="danger")],
        ])
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=keyboard)
        return

    elif section == "downloads":
        text = (
            "📥 <b>DOWNLOAD FILES</b>\\n\\n"
            "📂 अपनी files/download channel खोलने के लिए नीचे button दबाएँ।"
        )
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("📥 OPEN DOWNLOAD CHANNEL", url=OWNER_LINKS["downloads"], style="primary")],
            [InlineKeyboardButton("❌ CLOSE", callback_data="owner:close", style="danger")],
        ])
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=keyboard)
        return

    elif section == "support":
        text = (
            "🆘 <b>SUPPORT</b>\\n\\n"
            "किसी भी समस्या के लिए Support से संपर्क करें।"
        )
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🆘 CONTACT SUPPORT", url=OWNER_LINKS["support"], style="primary")],
            [InlineKeyboardButton("❌ CLOSE", callback_data="owner:close", style="danger")],
        ])
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=keyboard)
        return

    elif section == "links":
        text = (
            "🔗 <b>YOUR LINKS</b>\\n\\n"
            f"📥 Download: <code>{OWNER_LINKS['downloads']}</code>\\n"
            f"🆘 Support: <code>{OWNER_LINKS['support']}</code>\\n"
            f"🎥 Tutorial: <code>{OWNER_LINKS['tutorial']}</code>\\n\\n"
            "इन links को बाद में तुम्हारे अपने links से replace कर सकते हैं।"
        )

    elif section == "ludo":
        import sqlite3

        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS owner_ludo_record (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount REAL NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()

        cur.execute("SELECT COALESCE(SUM(amount), 0), COUNT(*) FROM owner_ludo_record")
        total, count = cur.fetchone()
        conn.close()

        text = (
            "🎲 <b>LUDO RECORD</b>\\n\\n"
            f"💰 Total Record: <b>₹{total:.2f}</b>\\n"
            f"📝 Entries: <b>{count}</b>\\n\\n"
            "नीचे amount चुनकर सिर्फ Owner Record में add करें:"
        )

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("₹10", callback_data="owner:ludo_add:10", style="primary"),
                InlineKeyboardButton("₹20", callback_data="owner:ludo_add:20", style="primary"),
                InlineKeyboardButton("₹30", callback_data="owner:ludo_add:30", style="primary"),
            ],
            [
                InlineKeyboardButton("₹50", callback_data="owner:ludo_add:50", style="primary"),
                InlineKeyboardButton("₹100", callback_data="owner:ludo_add:100", style="primary"),
            ],
            [
                InlineKeyboardButton("↩️ OWNER PANEL", callback_data="owner:back"),
                InlineKeyboardButton("❌ CLOSE", callback_data="owner:close", style="danger"),
            ],
        ])

        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=keyboard
        )
        return

    elif section.startswith("ludo_add:"):
        import sqlite3
        from datetime import datetime, timezone

        try:
            amount = float(section.split(":", 1)[1])
        except (ValueError, IndexError):
            await query.answer("Invalid amount", show_alert=True)
            return

        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS owner_ludo_record (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount REAL NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        cur.execute(
            "INSERT INTO owner_ludo_record (amount, created_at) VALUES (?, ?)",
            (amount, datetime.now(timezone.utc).isoformat())
        )
        conn.commit()

        cur.execute("SELECT COALESCE(SUM(amount), 0), COUNT(*) FROM owner_ludo_record")
        total, count = cur.fetchone()
        conn.close()

        await query.answer(f"₹{amount:.2f} record added")

        text = (
            "🎲 <b>LUDO RECORD</b>\\n\\n"
            f"✅ Added: <b>₹{amount:.2f}</b>\\n"
            f"💰 Total Record: <b>₹{total:.2f}</b>\\n"
            f"📝 Entries: <b>{count}</b>\\n\\n"
            "यह सिर्फ Owner का record है।"
        )

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("₹10", callback_data="owner:ludo_add:10", style="primary"),
                InlineKeyboardButton("₹20", callback_data="owner:ludo_add:20", style="primary"),
                InlineKeyboardButton("₹30", callback_data="owner:ludo_add:30", style="primary"),
            ],
            [
                InlineKeyboardButton("₹50", callback_data="owner:ludo_add:50", style="primary"),
                InlineKeyboardButton("₹100", callback_data="owner:ludo_add:100", style="primary"),
            ],
            [
                InlineKeyboardButton("↩️ OWNER PANEL", callback_data="owner:back"),
                InlineKeyboardButton("❌ CLOSE", callback_data="owner:close", style="danger"),
            ],
        ])

        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=keyboard
        )
        return

    elif section == "wholesale":
        # Owner-only wholesale store: category -> panel -> package
        buttons = []

        for category_key, category in PRODUCTS.items():
            # Always show every category in Wholesale Store
            buttons.append([
                InlineKeyboardButton(
                    category["name"],
                    callback_data=f"ownerwcat:{category_key}",
                    style="success"
                )
            ])

        buttons.append([
            InlineKeyboardButton(
                "↩️ OWNER PANEL",
                callback_data="owner:back",
                style="primary"
            )
        ])

        buttons.append([
            InlineKeyboardButton(
                "❌ CLOSE",
                callback_data="owner:close",
                style="danger"
            )
        ])

        text = (
            "📦 <b>OWNER WHOLESALE STORE</b>\\n"
            "━━━━━━━━━━━━━━━━━━\\n\\n"
            "🛡️ <b>SELECT CATEGORY</b>\\n\\n"
            "पहले category चुनें, फिर panel और उसके बाद package।"
        )

        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    elif section == "wholesale_rates":
        lines = [
            "💰 <b>WHOLESALE RATES</b>",
            "━━━━━━━━━━━━━━━━━━",
            ""
        ]

        for category_key, category in PRODUCTS.items():
            for product in category.get("products", []):
                for package in product.get("packages", []):
                    pid = package.get("pid") or product.get("pid")
                    if not pid:
                        continue

                    rate = get_wholesale_rate(pid)
                    if rate is None:
                        continue

                    lines.append(
                        f"{product['name'].removeprefix('🛒 ')} — "
                        f"{package['duration']} — "
                        f"PID {pid} — <b>₹{rate}</b>"
                    )

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "📦 OPEN WHOLESALE STORE",
                    callback_data="owner:wholesale",
                    style="success"
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ OWNER PANEL",
                    callback_data="owner:back"
                )
            ]
        ])

        await query.edit_message_text(
            "\n".join(lines),
            parse_mode="HTML",
            reply_markup=keyboard
        )
        return

    elif section == "settings":
        text = (
            "⚙️ <b>SETTINGS</b>\\n\\n"
            f"👑 Owner ID: <code>{OWNER_ID}</code>\\n"
            "🌐 Panel API: <b>Configured</b>\\n"
            "💳 Payment API: <b>Configured</b>\\n"
            "📌 Product PIDs: <b>बाद में add होंगे</b>"
        )

    else:
        text = "❌ Unknown section"

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("↩️ OWNER PANEL", callback_data="owner:back")],
        [InlineKeyboardButton("❌ CLOSE", callback_data="owner:close", style="danger")],
    ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )


def acquire_single_instance_lock():
    lock_path = "/data/data/com.termux/files/home/KeyBot/.bot.lock"

    lock_file = open(lock_path, "w")

    try:
        fcntl.flock(
            lock_file.fileno(),
            fcntl.LOCK_EX | fcntl.LOCK_NB
        )
    except BlockingIOError:
        print("⚠️ BOT ALREADY RUNNING")
        print("❌ दूसरा bot instance start नहीं होगा.")
        raise SystemExit(0)

    lock_file.write(str(__import__("os").getpid()))
    lock_file.flush()

    return lock_file


def main():
    # केवल एक Telegram polling instance चलने दें
    _single_instance_lock = acquire_single_instance_lock()

    if not BOT_TOKEN:
        print("❌ BOT_TOKEN missing in .env")
        return

    from telegram.request import HTTPXRequest

    request = HTTPXRequest(
        connect_timeout=30.0,
        read_timeout=30.0,
        write_timeout=30.0,
        pool_timeout=30.0,
        httpx_kwargs={"trust_env": False},
    )

    app = (
        Application
        .builder()
        .token(BOT_TOKEN)
        .request(request)
        .get_updates_request(request)
        .build()
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("frontpanel", front_panel))
    app.add_handler(MessageHandler(
        filters.Regex(r"(?i)^\s*(front\s*panel|frontpanel|front)\s*$"),
        front_panel,
    ))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(MessageHandler(
        filters.CONTACT,
        handle_shared_contact,
    ))
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        handle_payment_utr,
    ), group=-3)
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        owner_balance_input,
    ))
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        handle_broadcast,
    ), group=-2)
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        handle_custom_deposit,
    ), group=-1)
    app.add_handler(CallbackQueryHandler(button_handler))

    print("🤖 Bot Started...")

    # Cleanup bot messages that are already older than 15 minutes
    try:
        cleanup_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(cleanup_loop)
        cleanup_loop.run_until_complete(
            cleanup_old_bot_messages(app.bot)
        )
        print("🧹 OLD MESSAGES CLEANED")
    except Exception as e:
        print("⚠️ MESSAGE CLEANUP:", e)

    print("🚀 Starting Telegram polling...")
    app.run_polling(
        drop_pending_updates=False,
        close_loop=True,
    )


if __name__ == "__main__":
    main()
