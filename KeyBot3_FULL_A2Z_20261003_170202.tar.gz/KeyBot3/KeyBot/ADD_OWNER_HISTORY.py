from pathlib import Path

p = Path("bot.py")
lines = p.read_text(encoding="utf-8").splitlines(True)

if any("OWNER_SUCCESS_HISTORY_SAVED" in line for line in lines):
    print("ℹ️ OWNER HISTORY ALREADY ADDED")
    raise SystemExit

target = "    remaining = (\n"

try:
    idx = lines.index(target)
except ValueError:
    raise RuntimeError("Owner remaining marker not found")

insert = [
    "    save_successful_key_histories(\n",
    "        user_id=query.from_user.id,\n",
    "        product=product[\"name\"],\n",
    "        duration=package[\"duration\"],\n",
    "        pid=pid,\n",
    "        price=float(wholesale),\n",
    "        license_key=license_key,\n",
    "        order_code=order_code,\n",
    "        payment_order_id=f\"wholesale:{order_code}\",\n",
    "    )\n",
    "\n",
    "    logging.info(\n",
    "        \"OWNER_SUCCESS_HISTORY_SAVED: user=%s order=%s\",\n",
    "        query.from_user.id,\n",
    "        order_code,\n",
    "    )\n",
    "\n",
]

lines[idx:idx] = insert

p.write_text("".join(lines), encoding="utf-8")

print("✅ OWNER SUCCESS -> BOTH HISTORIES")
