import asyncio
import fcntl
import sqlite3
from pathlib import Path
import os
import logging
import requests
import time

from dotenv import load_dotenv
load_dotenv(dotenv_path=Path(__file__).resolve().parent / '.env')
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove, ForceReply
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    filters,
    ExtBot,
)

# ==================================================
# CONFIG
# ==================================================

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
FAMPAY_API_KEY = os.getenv("FAMPAY_API_KEY")
UPI_ID = os.getenv("UPI_ID")
OWNER_ID = os.getenv("OWNER_ID")
PANEL_API_KEY = os.getenv("PANEL_API_KEY")

FAMPAY_BASE = "https://famgateway.in"
PANEL_API_URL = "https://www.panelstore.shop/api/v1/index.php"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

# ==================================================
# DATA
# ==================================================

BALANCES = {}
USERS = set()
RESELLERS = set()
RESELLER_VALIDITY = 30 * 24 * 60 * 60

def init_reseller_db():
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS reseller_users "
        "(user_id TEXT PRIMARY KEY, activated_at REAL NOT NULL)"
    )
    conn.commit()
    conn.close()

def activate_reseller(user_id):
    uid = str(user_id)
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "INSERT OR REPLACE INTO reseller_users (user_id, activated_at) VALUES (?, ?)",
        (uid, time.time())
    )
    conn.commit()
    conn.close()
    RESELLERS.add(uid)

def get_reseller_total_saved(user_id):
    uid = str(user_id)
    total_saved = 0.0

    try:
        conn = sqlite3.connect("keybot.db")
        cur = conn.cursor()
        cur.execute(
            "SELECT pid, duration, wholesale FROM wholesale_history WHERE user_id=?",
            (uid,)
        )
        rows = cur.fetchall()
        conn.close()
    except sqlite3.Error:
        return 0.0

    for pid, duration, wholesale in rows:
        for category in PRODUCTS.values():
            for product in category.get("products", []):
                for package in product.get("packages", []):
                    package_pid = package.get("pid") or product.get("pid")
                    if str(package_pid) == str(pid) and package.get("duration") == duration:
                        retail = float(package.get("price", 0))
                        total_saved += max(0.0, retail - float(wholesale))
                        break

    return total_saved


def get_reseller_activation(user_id):
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "SELECT activated_at FROM reseller_users WHERE user_id=?",
        (str(user_id),)
    )
    row = cur.fetchone()
    conn.close()
    return row[0] if row else None

def is_reseller_active(user_id):
    activated_at = get_reseller_activation(user_id)

    if not activated_at:
        RESELLERS.discard(str(user_id))
        return False

    if time.time() - float(activated_at) >= RESELLER_VALIDITY:
        RESELLERS.discard(str(user_id))
        return False

    RESELLERS.add(str(user_id))
    return True

init_reseller_db()
PAYMENTS = {}
PAYMENT_UTR_USERS = {}

# ==================================================
# PAYMENT / WALLET DATABASE
# ==================================================

def init_payment_db():
    conn = sqlite3.connect("keybot.db", timeout=30)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS wallets (
            user_id TEXT PRIMARY KEY,
            balance REAL NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS payment_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id TEXT NOT NULL UNIQUE,
            user_id TEXT NOT NULL,
            requested_amount REAL NOT NULL,
            verified_amount REAL,
            submitted_utr TEXT,
            verified_utr TEXT,
            transaction_id TEXT,
            payment_type TEXT NOT NULL DEFAULT 'deposit',
            status TEXT NOT NULL DEFAULT 'PENDING',
            credited INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            message_id INTEGER
        )
    """)
    cur.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS idx_payment_verified_utr
        ON payment_transactions(verified_utr)
        WHERE verified_utr IS NOT NULL AND verified_utr <> ''
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS wallet_ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            entry_type TEXT NOT NULL,
            amount REAL NOT NULL,
            balance_before REAL NOT NULL,
            balance_after REAL NOT NULL,
            reference TEXT,
            order_id TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
        )
    """)
    conn.commit()
    conn.close()



def init_dynamic_products_db():
    conn = sqlite3.connect("keybot.db", timeout=30)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS dynamic_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_key TEXT NOT NULL,
            name TEXT NOT NULL,
            pid INTEGER NOT NULL,
            duration TEXT NOT NULL,
            reseller_price REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            UNIQUE(category_key, pid)
        )
    """)
    conn.commit()
    conn.close()



def init_product_overrides_db():
    conn = sqlite3.connect("keybot.db", timeout=30)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS product_overrides (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_key TEXT NOT NULL,
            original_pid INTEGER NOT NULL,
            package_index INTEGER NOT NULL DEFAULT 0,
            name TEXT,
            new_pid INTEGER,
            duration TEXT,
            reseller_price REAL,
            updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            UNIQUE(category_key, original_pid, package_index)
        )
    """)
    conn.commit()
    conn.close()


def save_product_override(category_key, original_pid, package_index,
                          name, new_pid, duration, reseller_price,
                          user_price=None):
    conn = sqlite3.connect("keybot.db", timeout=30)
    conn.execute("""
        INSERT INTO product_overrides
        (category_key, original_pid, package_index, name, new_pid,
         duration, reseller_price, user_price)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(category_key, original_pid, package_index)
        DO UPDATE SET
            name=excluded.name,
            new_pid=excluded.new_pid,
            duration=excluded.duration,
            reseller_price=excluded.reseller_price,
            user_price=excluded.user_price,
            updated_at=datetime('now','localtime')
    """, (
        category_key,
        int(original_pid),
        int(package_index),
        name,
        int(new_pid),
        duration,
        float(reseller_price),
        float(user_price) if user_price is not None else None
    ))
    conn.commit()
    conn.close()


def load_product_overrides():
    try:
        conn = sqlite3.connect("keybot.db", timeout=30)
        rows = conn.execute("""
            SELECT category_key, original_pid, package_index,
                   name, new_pid, duration, reseller_price, user_price
            FROM product_overrides
            ORDER BY id ASC
        """).fetchall()
        conn.close()
    except sqlite3.Error:
        logging.exception("PRODUCT OVERRIDE LOAD ERROR")
        return

    for (
        category_key,
        original_pid,
        package_index,
        name,
        new_pid,
        duration,
        reseller_price,
        user_price
    ) in rows:

        category = PRODUCTS.get(category_key)
        if not category:
            continue

        for product in category.get("products", []):
            packages = product.get("packages", [])

            if package_index < 0 or package_index >= len(packages):
                continue

            package = packages[package_index]

            if str(package.get("pid")) != str(original_pid):
                continue

            if name:
                product["name"] = name

            if new_pid:
                package["pid"] = int(new_pid)

            if duration:
                package["duration"] = duration

            # Normal customer price
            if user_price is not None:
                package["price"] = float(user_price)

            # Reseller price
            if reseller_price is not None:
                package["wholesale"] = float(reseller_price)

            break


def load_dynamic_products():
    global PRODUCTS

    conn = sqlite3.connect("keybot.db")
    conn.row_factory = sqlite3.Row

    rows = conn.execute("""
        SELECT id, category_key, name, pid, duration,
               reseller_price, user_price
        FROM dynamic_products
        ORDER BY id ASC
    """).fetchall()

    conn.close()

    # पहले से मौजूद static products को सुरक्षित रखते हुए
    # dynamic products को name के अंदर multiple packages में group करें.
    for category_key in (
        "android_nonroot",
        "android_root",
        "iphone",
        "pc",
    ):
        category = PRODUCTS.get(category_key)
        if not category:
            continue

        static_products = category.get("products", [])

        # Dynamic products को अलग रखें
        grouped = {}

        for row in rows:
            if row["category_key"] != category_key:
                continue

            name = row["name"]

            if name not in grouped:
                grouped[name] = {
                    "name": name,
                    "packages": []
                }

            grouped[name]["packages"].append({
                "duration": row["duration"],
                "price": float(
                    row["user_price"]
                    if row["user_price"] is not None
                    else row["reseller_price"]
                ),
                "wholesale": float(row["reseller_price"]),
                "reseller_price": float(row["reseller_price"]),
                "pid": int(row["pid"]),
                "dynamic_id": int(row["id"]),
            })

        category["products"] = static_products + list(grouped.values())



def get_dynamic_product_rows(category_key):
    conn = sqlite3.connect("keybot.db", timeout=30)
    rows = conn.execute(
        "SELECT id, name, pid, duration, reseller_price, user_price "
        "FROM dynamic_products "
        "WHERE category_key=? ORDER BY id ASC",
        (category_key,)
    ).fetchall()
    conn.close()
    return rows


def get_dynamic_product(product_id):
    conn = sqlite3.connect("keybot.db", timeout=30)
    row = conn.execute(
        "SELECT id, category_key, name, pid, duration, "
        "reseller_price, user_price "
        "FROM dynamic_products WHERE id=?",
        (product_id,)
    ).fetchone()
    conn.close()
    return row


def load_balances_from_db():
    try:
        conn = sqlite3.connect("keybot.db", timeout=30)
        rows = conn.execute("SELECT user_id, balance FROM wallets").fetchall()
        conn.close()
        for uid, balance in rows:
            try:
                BALANCES[int(uid)] = float(balance)
            except (TypeError, ValueError):
                BALANCES[uid] = float(balance)
    except sqlite3.Error:
        logging.exception("WALLET LOAD ERROR")


def get_balance(user_id):
    uid = str(user_id)
    try:
        conn = sqlite3.connect("keybot.db", timeout=30)
        row = conn.execute("SELECT balance FROM wallets WHERE user_id=?", (uid,)).fetchone()
        conn.close()
        if row is not None:
            balance = float(row[0])
            try:
                BALANCES[int(user_id)] = balance
            except Exception:
                BALANCES[user_id] = balance
            return balance
    except sqlite3.Error:
        logging.exception("GET BALANCE ERROR")
    return float(BALANCES.get(user_id, 0) or 0)


def add_balance(user_id, amount, reference=None, order_id=None):
    amount = float(amount)
    if amount <= 0:
        raise ValueError("Balance amount must be positive")
    uid = str(user_id)
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT balance FROM wallets WHERE user_id=?", (uid,)).fetchone()
        before = float(row[0]) if row else 0.0
        after = before + amount
        conn.execute(
            "INSERT INTO wallets(user_id,balance,updated_at) VALUES(?,?,datetime('now','localtime')) "
            "ON CONFLICT(user_id) DO UPDATE SET balance=excluded.balance, updated_at=excluded.updated_at",
            (uid, after),
        )
        conn.execute(
            "INSERT INTO wallet_ledger(user_id,entry_type,amount,balance_before,balance_after,reference,order_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (uid, "CREDIT", amount, before, after, reference, order_id),
        )
        conn.commit()
        BALANCES[user_id] = after
        return after
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def refund_purchase_payment(order_id, user_id, amount):
    """Refund a verified purchase QR payment exactly once."""
    amount = float(amount)
    if amount <= 0:
        return False

    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute("BEGIN IMMEDIATE")

        row = conn.execute(
            "SELECT credited, status FROM payment_transactions "
            "WHERE order_id=? AND user_id=?",
            (str(order_id), str(user_id)),
        ).fetchone()

        if not row:
            raise ValueError("Purchase payment not found")

        credited, status = row

        # Already completed/refunded payment must never be credited again.
        if int(credited or 0) == 1 or str(status).upper() == "REFUNDED":
            conn.rollback()
            return False

        wallet_row = conn.execute(
            "SELECT balance FROM wallets WHERE user_id=?",
            (str(user_id),),
        ).fetchone()

        before = float(wallet_row[0]) if wallet_row else 0.0
        after = before + amount

        conn.execute(
            "INSERT INTO wallets(user_id,balance,updated_at) "
            "VALUES(?,?,datetime('now','localtime')) "
            "ON CONFLICT(user_id) DO UPDATE SET "
            "balance=excluded.balance, updated_at=excluded.updated_at",
            (str(user_id), after),
        )

        conn.execute(
            "INSERT INTO wallet_ledger("
            "user_id,entry_type,amount,balance_before,balance_after,"
            "reference,order_id"
            ") VALUES(?,?,?,?,?,?,?)",
            (
                str(user_id),
                "CREDIT",
                amount,
                before,
                after,
                "Purchase payment refund",
                str(order_id),
            ),
        )

        conn.execute(
            "UPDATE payment_transactions SET "
            "status='REFUNDED', credited=1, "
            "verified_amount=?, "
            "updated_at=datetime('now','localtime') "
            "WHERE order_id=? AND user_id=?",
            (amount, str(order_id), str(user_id)),
        )

        conn.commit()

        try:
            BALANCES[int(user_id)] = after
        except Exception:
            BALANCES[user_id] = after

        return True

    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def remove_balance(user_id, amount):
    amount = float(amount)
    if amount <= 0:
        return get_balance(user_id)
    uid = str(user_id)
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT balance FROM wallets WHERE user_id=?", (uid,)).fetchone()
        before = float(row[0]) if row else 0.0
        after = max(0.0, before - amount)
        conn.execute(
            "INSERT INTO wallets(user_id,balance,updated_at) VALUES(?,?,datetime('now','localtime')) "
            "ON CONFLICT(user_id) DO UPDATE SET balance=excluded.balance, updated_at=excluded.updated_at",
            (uid, after),
        )
        conn.execute(
            "INSERT INTO wallet_ledger(user_id,entry_type,amount,balance_before,balance_after,reference,order_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (uid, "DEBIT", before-after, before, after, "manual/product debit", None),
        )
        conn.commit()
        BALANCES[user_id] = after
        return after
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def save_payment_order(
    order_id,
    user_id,
    amount,
    payment_type="deposit",
    message_id=None,
    product_price=None,
    balance_to_use=None,
    category_key=None,
    product_index=None,
    package_index=None,
    product_pid=None,
):
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute(
            "INSERT INTO payment_transactions "
            "(order_id,user_id,requested_amount,payment_type,status,message_id,"
            "product_price,balance_to_use,category_key,product_index,"
            "package_index,product_pid) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                str(order_id),
                str(user_id),
                float(amount),
                payment_type,
                "PENDING",
                message_id,
                product_price,
                balance_to_use,
                category_key,
                product_index,
                package_index,
                product_pid,
            ),
        )
        conn.commit()
    finally:
        conn.close()


def update_payment_order(order_id, **fields):
    allowed = {
        "submitted_utr", "verified_utr", "transaction_id", "verified_amount",
        "status", "credited", "message_id"
    }
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return
    fields["updated_at"] = "__NOW__"
    sets = []
    values = []
    for key, value in fields.items():
        if value == "__NOW__":
            sets.append("updated_at=datetime('now','localtime')")
        else:
            sets.append(f"{key}=?")
            values.append(value)
    values.append(str(order_id))
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute(f"UPDATE payment_transactions SET {', '.join(sets)} WHERE order_id=?", values)
        conn.commit()
    finally:
        conn.close()


def get_payment_order(order_id):
    conn = sqlite3.connect("keybot.db", timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute("SELECT * FROM payment_transactions WHERE order_id=?", (str(order_id),)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def find_pending_payment(user_id):
    # Prefer the in-memory record while the bot is running because purchase/reseller
    # payments also carry product metadata there. DB is the restart-safe fallback.
    for order_id, payment in reversed(list(PAYMENTS.items())):
        if payment.get("user_id") == user_id and payment.get("status") in ("pending", "verifying"):
            row = get_payment_order(order_id) or {}
            return {**row, "order_id": order_id, **payment}

    conn = sqlite3.connect("keybot.db", timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            "SELECT * FROM payment_transactions WHERE user_id=? AND status IN ('PENDING','VERIFYING') "
            "ORDER BY id DESC LIMIT 1",
            (str(user_id),),
        ).fetchone()
        if row:
            result = dict(row)

            # DB row को in-memory payment format में normalize करें
            result["type"] = result.get("payment_type")
            result["category"] = result.get("category_key")
            result["pid"] = result.get("product_pid")
            result["amount"] = result.get("requested_amount")

            return result
    finally:
        conn.close()
    return None


def claim_and_credit_deposit(order_id, user_id, amount, verified_utr, transaction_id):
    """Atomically credit one verified payment exactly once."""
    uid = str(user_id)
    conn = sqlite3.connect("keybot.db", timeout=30)
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute(
            "SELECT user_id, requested_amount, credited, status, verified_utr FROM payment_transactions WHERE order_id=?",
            (str(order_id),),
        ).fetchone()
        if not row:
            raise ValueError("Payment order not found")
        db_uid, requested, credited, status, old_utr = row
        if str(db_uid) != uid:
            raise ValueError("Payment owner mismatch")
        if int(credited) == 1:
            return False, "already_credited", None
        if status == "SUCCESS" and old_utr:
            return False, "already_processed", None

        # UTR can never credit two different orders.
        dup = conn.execute(
            "SELECT order_id, user_id FROM payment_transactions "
            "WHERE verified_utr=? AND order_id<>? LIMIT 1",
            (str(verified_utr), str(order_id)),
        ).fetchone()
        if dup:
            return False, "duplicate_utr", None

        wallet = conn.execute("SELECT balance FROM wallets WHERE user_id=?", (uid,)).fetchone()
        before = float(wallet[0]) if wallet else 0.0
        after = before + float(amount)
        conn.execute(
            "INSERT INTO wallets(user_id,balance,updated_at) VALUES(?,?,datetime('now','localtime')) "
            "ON CONFLICT(user_id) DO UPDATE SET balance=excluded.balance, updated_at=excluded.updated_at",
            (uid, after),
        )
        conn.execute(
            "INSERT INTO wallet_ledger(user_id,entry_type,amount,balance_before,balance_after,reference,order_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (uid, "CREDIT", float(amount), before, after, "Fampay verified payment", str(order_id)),
        )
        conn.execute(
            "UPDATE payment_transactions SET verified_amount=?, verified_utr=?, transaction_id=?, "
            "status='SUCCESS', credited=1, updated_at=datetime('now','localtime') WHERE order_id=? AND credited=0",
            (float(amount), str(verified_utr), str(transaction_id or ""), str(order_id)),
        )
        conn.commit()
        BALANCES[user_id] = after
        return True, "credited", after
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

init_payment_db()
init_dynamic_products_db()
load_balances_from_db()

async def expire_qr_message(bot, user_id, order_id):
    try:
        await asyncio.sleep(300)

        payment = PAYMENTS.get(order_id)
        if not payment or payment.get("status") != "pending":
            return

        payment["status"] = "expired"

        try:
            update_payment_order(order_id, status="EXPIRED")
        except Exception:
            logging.exception("PAYMENT DB EXPIRY UPDATE ERROR")

        message_id = payment.get("message_id")
        if not message_id:
            return

        # पहले पुराना QR/photo message हटाओ
        try:
            await bot.delete_message(
                chat_id=user_id,
                message_id=message_id
            )
        except Exception:
            logging.exception("QR MESSAGE DELETE ERROR")

        # फिर उसी chat में expiry message दिखाओ
        try:
            keyboard = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "↩️ BACK",
                        callback_data="deposit",
                        style="danger"
                    )
                ]
            ])

            await bot.send_message(
                chat_id=user_id,
                text=(
                    "⌛ <b>QR CODE EXPIRED</b>\\n\\n"
                    "यह QR Code 5 मिनट के बाद expire हो गया है।\\n"
                    "💳 इस QR पर अब payment न करें।\\n\\n"
                    "नीचे BACK दबाकर नया QR generate करें।"
                ),
                parse_mode="HTML",
                reply_markup=keyboard
            )
        except Exception:
            logging.exception("QR AUTO EXPIRY MESSAGE ERROR")

    except Exception:
        logging.exception("QR AUTO EXPIRY ERROR")

CUSTOM_DEPOSIT_USERS = {}
BROADCAST_USERS = set()

OWNER_LINKS = {
    "downloads": "https://t.me/ALLINONEAPKCHANEEL",
    "support": "https://t.me/Santoshyaadav",
    "tutorial": "https://t.me/balamodkeyapk",
}

ORDERS = {}

# ==================================================
# PRODUCTS
# ==================================================

PRODUCTS = {
    "android_nonroot": {
        "name": "🤖 ANDROID NON ROOT PANEL",
        "products": [
            {
                "name": "📦 DRIP CLIENT APKMOD",
                "packages": [
                    {"duration": "1 Day", "price": 50, "pid": 109},
                    {"duration": "3 Days", "price": 130, "pid": 110},
                    {"duration": "7 Days", "price": 230, "pid": 111},
                    {"duration": "15 Days", "price": 370, "pid": 112},
                    {"duration": "30 Days", "price": 550, "pid": 113},
                ],
            },
            {
                "name": "🟠 PATOTEAM ORANGE",
                "packages": [
                    {"duration": "3 Days", "price": 210, "pid": 156},
                    {"duration": "7 Days", "price": 350, "pid": 157},
                    {"duration": "15 Days", "price": 585, "pid": 158},
                    {"duration": "30 Days", "price": 950, "pid": 159},
                ],
            },
            {
                "name": "🛡️ DRIP CLIENT PROXY APK",
                "packages": [
                    {"duration": "1 Day", "price": 60, "pid": 114},
                    {"duration": "3 Days", "price": 140, "pid": 115},
                    {"duration": "7 Days", "price": 250, "pid": 116},
                    {"duration": "30 Days", "price": 600, "pid": 117},
                ],
            },
            {
                "name": "🧪 HG CHEATS APK",
                "packages": [
                    {"duration": "1 Day", "price": 55, "pid": 122},
                    {"duration": "7 Days", "price": 140, "pid": 123},
                    {"duration": "10 Days", "price": 179, "pid": 124},
                    {"duration": "30 Days", "price": 425, "pid": 125},
                ],
            },
            {
                "name": "🔧 PRIME MOD APK",
                "packages": [
                    {"duration": "1 Day", "price": 72, "pid": 129},
                    {"duration": "3 Days", "price": 90, "pid": 130},
                    {"duration": "7 Days", "price": 270, "pid": 131},
                ],
            },
            {
                "name": "🔴 HG PROXY APK",
                "packages": [
                    {"duration": "1 Day", "price": 70, "pid": 126},
                    {"duration": "7 Days", "price": 220, "pid": 127},
                    {"duration": "10 Days", "price": 290},
                    {"duration": "30 Days", "price": 585, "pid": 128},
                ],
            },
            {
                "name": "💀 CTB MOD APK",
                "packages": [
                    {"duration": "12 Hour", "price": 20, "pid": 136},
                    {"duration": "1 Day", "price": 30, "pid": 137},
                    {"duration": "3 Days", "price": 80, "pid": 138},
                    {"duration": "7 Days", "price": 150, "pid": 139},
                ],
            },
            {
                "name": "🔧 PATOTEAM BLUE",
                "packages": [
                    {"duration": "3 Days", "price": 175, "pid": 140, "stock": False},
                    {"duration": "7 Days", "price": 350, "pid": 141},
                    {"duration": "15 Days", "price": 520, "pid": 142},
                    {"duration": "30 Days", "price": 850, "pid": 143},
                ],
            },
            {
                "name": "🦂 ABCD WIRE APK",
                "packages": [
                    {"duration": "12 Hour", "price": 25, "pid": 132},
                    {"duration": "1 Day", "price": 40, "pid": 133},
                    {"duration": "3 Days", "price": 100, "pid": 134},
                    {"duration": "7 Days", "price": 160, "pid": 135},
                ],
            },
            {
                "name": "🟦 DRIP WIRE APK",
                "packages": [
                    {"duration": "6 Hour", "price": 35, "pid": 118},
                    {"duration": "12 Hour", "price": 50, "pid": 119},
                    {"duration": "1 Day", "price": 90, "pid": 120},
                    {"duration": "7 Days", "price": 350, "pid": 121},
                ],
            },
            {
                "name": "👹 BALA MOD APK",
                "packages": [
                    {"duration": "1 Hour", "price": 15, "pid": 160},
                    {"duration": "2 Hour", "price": 22, "pid": 161},
                    {"duration": "3 Hour", "price": 32, "pid": 162},
                    {"duration": "4 Hour", "price": 40, "pid": 163},
                    {"duration": "5 Hour", "price": 50, "pid": 164},
                    {"duration": "6 Hour", "price": 60, "pid": 165},
                    {"duration": "7 Hour", "price": 72, "pid": 166},
                    {"duration": "8 Hour", "price": 80, "pid": 167},
                    {"duration": "9 Hour", "price": 85, "pid": 168},
                    {"duration": "10 Hour", "price": 88, "pid": 169},
                    {"duration": "1 Day", "price": 245, "pid": 170},
                    {"duration": "2 Days", "price": 480, "pid": 171},
                    {"duration": "3 Days", "price": 650, "pid": 172},
                    {"duration": "7 Days", "price": 1500, "pid": 173},
                    {"duration": "30 Days", "price": 5500, "pid": 174},
                ],
            },
            {
                "name": "🤖 AIMHACK [NONROOT+iOS]",
                "packages": [
                    {"duration": "1 Hour", "price": 20, "pid": 234},
                    {"duration": "3 Hour", "price": 40, "pid": 235},
                    {"duration": "6 Hour", "price": 55, "pid": 236},
                    {"duration": "12 Hour", "price": 90, "pid": 237},
                    {"duration": "1 Day", "price": 120, "pid": 238},
                    {"duration": "3 Days", "price": 190, "pid": 239},
                    {"duration": "7 Days", "price": 360, "pid": 240},
                    {"duration": "30 Days", "price": 900, "pid": 241},
                ],
            },
            {
                "name": "⚔️ HEX BLADE APKMOD",
                "packages": [
                    {"duration": "1 Day", "price": 70, "pid": 179},
                    {"duration": "3 Days", "price": 130, "pid": 180},
                    {"duration": "7 Days", "price": 230, "pid": 181},
                    {"duration": "15 Days", "price": 350, "pid": 182},
                    {"duration": "30 Days", "price": 580, "pid": 183},
                ],
            },
            {"name": "☠️ NINE X MODS APK", "packages": [{"duration": "10 Days", "price": 350, "pid": 224}, {"duration": "20 Days", "price": 680, "pid": 225}, {"duration": "30 Days", "price": 1100, "pid": 226}]},
            {"name": "⚔️ XREG APKMOD", "packages": [{"duration": "1 Hour", "price": 15, "pid": 227}, {"duration": "3 Hours", "price": 33, "pid": 228}, {"duration": "6 Hours", "price": 60, "pid": 229}, {"duration": "12 Hours", "price": 94, "pid": 230}, {"duration": "1 Day", "price": 105, "pid": 231}, {"duration": "3 Days", "price": 125, "pid": 232}, {"duration": "30 Days", "price": 550, "pid": 233}]},
    {
        "name": "👹 TROLL MODZ APK",
        "packages": [
            {"duration": "1 Hour", "price": 15, "pid": 276},
            {"duration": "3 Hours", "price": 25, "pid": 277},
            {"duration": "6 Hours", "price": 40, "pid": 278},
            {"duration": "12 Hours", "price": 55, "pid": 279},
            {"duration": "1 Day", "price": 80, "pid": 280},
            {"duration": "3 Days", "price": 140, "pid": 281},
            {"duration": "7 Days", "price": 250, "pid": 282},
            {"duration": "15 Days", "price": 350, "pid": 283},
            {"duration": "30 Days", "price": 550, "pid": 284},
        ],
    },
        ],
    },

    "android_root": {
        "name": "🤖 ANDROID ROOT PANEL",
        "products": [
            {
                "name": "😡 ANGRY MOD APK",
                "packages": [
                    {"duration": "1 Day", "price": 75, "pid": 144},
                    {"duration": "7 Days", "price": 320, "pid": 145},
                    {"duration": "15 Days", "price": 530, "pid": 146},
                    {"duration": "30 Days", "price": 750, "pid": 147},
                ],
            },
            {
                "name": "👑 DRIP CILENT ROOT APK",
                "packages": [
                    {"duration": "1 Day", "price": 70, "pid": 149},
                    {"duration": "7 Days", "price": 320, "pid": 150},
                    {"duration": "30 Days", "price": 650, "pid": 151},
                ],
            },
            {
                "name": "⚡ RAPID CORE APK",
                "packages": [
                    {"duration": "1 Day", "price": 70, "pid": 189},
                    {"duration": "7 Days", "price": 240, "pid": 190},
                    {"duration": "14 Days", "price": 350, "pid": 191},
                    {"duration": "30 Days", "price": 520, "pid": 192},
                ],
            },
            {
                "name": "💀 BR MODS APK",
                "packages": [
                    {"duration": "1 Day", "price": 50, "pid": 193},
                    {"duration": "7 Days", "price": 220, "pid": 197},
                    {"duration": "15 Days", "price": 320, "pid": 198},
                    {"duration": "30 Days", "price": 500, "pid": 199},
                ],
            },
            {
                "name": "🛡️ SILENT CHEATS SAFE",
                "packages": [
                    {"duration": "1 Day", "price": 75, "pid": 203},
                    {"duration": "3 Days", "price": 130, "pid": 204},
                    {"duration": "7 Days", "price": 250, "pid": 205},
                    {"duration": "14 Days", "price": 500, "pid": 206},
                    {"duration": "30 Days", "price": 720, "pid": 207},
                ],
            },
            {
                "name": "⚔️ HEX BLADE APK",
                "packages": [
                    {"duration": "1 Day", "price": 75, "pid": 184},
                    {"duration": "3 Days", "price": 150, "pid": 185},
                    {"duration": "7 Days", "price": 250, "pid": 186},
                    {"duration": "15 Days", "price": 380, "pid": 187},
                    {"duration": "30 Days", "price": 620, "pid": 188},
                ],
            },
            {"name": "🩸 SILENT CHEATS BRUTAL", "packages": [{"duration": "1 Day", "price": 75, "pid": 208}, {"duration": "3 Days", "price": 125, "pid": 209}, {"duration": "7 Days", "price": 250, "pid": 210}, {"duration": "14 Days", "price": 500, "pid": 211}, {"duration": "30 Days", "price": 720, "pid": 212}]},
            {"name": "💀 HAXX-CKER PRO", "packages": [{"duration": "5 Days", "price": 200, "pid": 218}, {"duration": "10 Days", "price": 400, "pid": 219}]},
            {"name": "👿 ZYTRON PRO APK", "packages": [{"duration": "1 Day", "price": 70, "pid": 242}, {"duration": "7 Days", "price": 210, "pid": 243}, {"duration": "15 Days", "price": 350, "pid": 244}]},
        ],
    },

    "iphone": {
        "name": "🍎 IPHONE PANEL",
        "products": [
            {
                "name": "🛒 ESING CERTIFICATE",
                "packages": [
                    {"duration": "1 Year", "price": 500, "pid": 148},
                ],
            },
            {
                "name": "⚡ ALPHA REGEDIT EXTERNAL",
                "packages": [
                    {"duration": "1 Day", "price": 90, "pid": 152},
                    {"duration": "3 Days", "price": 180, "pid": 153},
                    {"duration": "7 Days", "price": 350, "pid": 154},
                    {"duration": "30 Days", "price": 800, "pid": 155},
                ],
            },
        ],
    },

    "pc": {
        "name": "💻 PC PANEL",
        "products": [
            {
                "name": "💻 BR MODS PC",
                "packages": [
                    {"duration": "1 Day", "price": 75, "pid": 200},
                    {"duration": "10 Days", "price": 320, "pid": 201},
                    {"duration": "30 Days", "price": 600, "pid": 202},
                ],
            },            {
                "name": "🖥️ PC LOGO BYPASS NON ROOT",
                "packages": [
                    {"duration": "30 Day", "price": 400, "pid": 246},
                ],
            },
        ],
    },
}

WHOLESALE_RATES = {
    276: 7,
    277: 12,
    278: 20,
    279: 28,
    280: 40,
    281: 75,
    282: 125,
    283: 230,
    284: 450,
    246: 300,

    109: 25,
    110: 60,
    111: 110,
    112: 180,
    113: 275,
    114: 30,
    115: 70,
    116: 125,
    117: 300,
    118: 18,
    119: 25,
    120: 45,
    121: 175,
    122: 40,
    123: 100,
    124: 140,
    125: 250,
    126: 45,
    127: 100,
    128: 350,
    129: 36,
    130: 75,
    131: 145,
    132: 10,
    133: 25,
    134: 50,
    135: 89,
    136: 10,
    137: 15,
    138: 40,
    139: 70,
    140: 100,
    141: 200,
    142: 250,
    143: 400,
    144: 40,
    145: 90,
    146: 150,
    147: 200,
    148: 250,

    149: 45,
    150: 130,
    151: 330,
    152: 50,
    153: 99,
    154: 190,
    155: 410,
    156: 150,
    157: 200,
    158: 300,
    159: 500,
    234: 12,
    235: 25,
    236: 33,
    237: 45,
    238: 65,
    239: 135,
    240: 243,
    241: 650,
    160: 7,
    161: 15,
    162: 21,
    163: 30,
    164: 42,
    165: 47,
    166: 56,
    167: 65,
    168: 69,
    169: 70,
    170: 185,
    171: 365,
    172: 530,
    173: 1250,
    174: 5000,
    179: 37,
    180: 69,
    181: 110,
    182: 190,
    183: 290,
    184: 40,
    185: 70,
    186: 120,
    187: 200,
    188: 300,
    189: 30,
    190: 149,
    191: 199,
    192: 320,
    193: 35,
    197: 90,
    198: 150,
    199: 290,
    200: 45,
    201: 160,
    202: 300,
    203: 45,
    204: 75,
    205: 125,
    206: 225,
    207: 350,
    208: 50,
    209: 75,
    210: 125,
    211: 250,
    212: 360,
    218: 160,
    219: 300,
    224: 250,
    225: 495,
    226: 750,
    227: 10,
    228: 18,
    229: 30,
    230: 47,
    231: 65,
    232: 100,
    233: 450,
    242: 50,
    243: 120,
    244: 200,
}

init_product_overrides_db()
load_dynamic_products()
load_product_overrides()
def get_reseller_price(package, product=None):
    wholesale = package.get("wholesale")
    if wholesale is not None:
        return float(wholesale)

    pid = package.get("pid")
    if not pid and product:
        pid = product.get("pid")

    rate = get_wholesale_rate(pid) if pid else None
    return float(rate) if rate is not None else None


def get_wholesale_rate(pid):
    try:
        return WHOLESALE_RATES.get(int(pid))
    except (TypeError, ValueError):
        return None



# ==================================================
# MAIN MENU
# ==================================================

def main_menu(user_id=None):
    rows = [
        [
            InlineKeyboardButton(
                "🛍️ PRODUCT STORE",
                callback_data="products",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "👤 MY PROFILE",
                callback_data="profile",
                style="primary"
            ),
            InlineKeyboardButton(
                "💰 ADD BALANCE",
                callback_data="deposit",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "📜 ALL HISTORY",
                callback_data="history",
                style="primary"
            ),
            InlineKeyboardButton(
                "🎁 REFERRAL",
                callback_data="referral",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "📚 TUTORIAL",
                callback_data="tutorial",
                style="primary"
            ),
            InlineKeyboardButton(
                "🆘 SUPPORT",
                callback_data="support",
                style="primary"
            )
        ],
        [
            InlineKeyboardButton(
                "🎲 LUDO SPIN",
                callback_data="ludo",
                style="primary"
            ),
            InlineKeyboardButton(
                "📥 DOWNLOAD FILES",
                callback_data="downloads",
                style="primary"
            )
        ],
    ]

    if str(user_id) == str(OWNER_ID):
        rows.append([
            InlineKeyboardButton(
                "👑 WHOLESALE STORE",
                callback_data="owner:wholesale",
                style="success"
            )
        ])
    else:
        rows.append([
            InlineKeyboardButton(
                "🤝 RESELLER PANEL",
                callback_data="reseller:panel",
                style="success"
            )
        ])
    return InlineKeyboardMarkup(rows)



async def front_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Open the same front/store panel from a text command."""
    USERS.add(update.effective_user.id)
    await update.message.reply_text(
        "🏠 <b>FRONT PANEL</b>\n\n"
        "👇 Select an option below:",
        parse_mode="HTML",
        reply_markup=main_menu(update.effective_user.id),
    )


# ==================================================
# START
# ==================================================

def init_user_db():
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS users "
        "(user_id TEXT PRIMARY KEY, username TEXT, first_name TEXT, last_name TEXT, phone TEXT, created_at TEXT, updated_at TEXT)"
    )
    conn.commit()
    conn.close()


def save_user(update):
    user = update.effective_user
    if not user:
        return

    uid = str(user.id)
    username = user.username or ""
    first_name = user.first_name or ""
    last_name = user.last_name or ""

    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()

    cur.execute("SELECT user_id FROM users WHERE user_id=?", (uid,))
    exists = cur.fetchone()

    if exists:
        cur.execute(
            "UPDATE users SET username=?, first_name=?, last_name=?, "
            "updated_at=datetime('now', 'localtime') WHERE user_id=?",
            (username, first_name, last_name, uid),
        )
    else:
        cur.execute(
            "INSERT INTO users "
            "(user_id, username, first_name, last_name, phone, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, '', datetime('now', 'localtime'), datetime('now', 'localtime'))",
            (uid, username, first_name, last_name),
        )

    conn.commit()
    conn.close()
    USERS.add(user.id)


def get_user_phone(user_id):
    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "SELECT phone FROM users WHERE user_id=?",
        (str(user_id),)
    )
    row = cur.fetchone()
    conn.close()
    return row[0] if row and row[0] else None


def save_user_phone(update):
    user = update.effective_user
    contact = update.effective_message.contact if update.effective_message else None

    if not user or not contact:
        return

    if contact.user_id and int(contact.user_id) != int(user.id):
        return

    conn = sqlite3.connect("keybot.db")
    cur = conn.cursor()
    cur.execute(
        "UPDATE users SET phone=?, updated_at=datetime('now', 'localtime') WHERE user_id=?",
        (contact.phone_number, str(user.id)),
    )
    conn.commit()
    conn.close()


init_user_db()


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user(update)

    user_id = update.effective_user.id

    if not get_user_phone(user_id):
        await update.message.reply_text(
            "📱 <b>CONTACT SAVE</b>\n\n"
            "पहले अपना contact share करें।\n"
            "इसके बाद आपका My Profile खुलेगा।",
            parse_mode="HTML",
            reply_markup=ReplyKeyboardMarkup(
                [[KeyboardButton("📱 SHARE CONTACT", request_contact=True)]],
                resize_keyboard=True,
                one_time_keyboard=True
            )
        )
        return

    text = (
        "✨ <b>WELCOME TO THE STORE</b> ✨\n\n"
        "🛍️ <b>Product Store</b> : All key purchase & instantly delivery\n"
        "👤 <b>My Profile</b> : Check your account information\n"
        "💰 <b>Add Balance</b> : Deposit balance & secure service\n"
        "📜 <b>All History</b> : Check all key purchase history\n"
        "🎁 <b>Referral</b> : Invite friends & earn rewards\n"
        "📚 <b>Tutorial</b> : View tutorial and work this bot\n"
        "🆘 <b>Support</b> : Bot problem fixed for support admin\n"
        "🎲 <b>Ludo Spin</b> : Demo game\n"
        "📥 <b>Download Files</b> : Download latest files for safety\n\n"
        "👇 <b>Select an option below</b>"
    )

    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=main_menu(user_id)
    )


async def handle_shared_contact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user(update)
    save_user_phone(update)

    user = update.effective_user
    phone = get_user_phone(user.id) or "Not shared"
    username = f"@{user.username}" if user.username else "Not set"
    name = user.full_name or user.first_name or "Not set"

    text = (
        "👤 <b>MY PROFILE</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"👤 Name: <b>{name}</b>\n"
        f"🔹 Username: <b>{username}</b>\n"
        f"📱 Phone: <code>{phone}</code>\n"
        f"🆔 User ID: <code>{user.id}</code>\n"
        f"💰 Balance: <b>₹{get_balance(user.id)}</b>\n\n"
        "🔐 Account status: Active"
    )

    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove()
    )


# ==================================================
# HOME
# ==================================================

async def home(query):

    await query.answer()

    await query.edit_message_text(
        "🏠 <b>STORE HOME</b>\n\n"
        "Welcome to our digital store.\n\n"
        "👇 Select an option:",
        parse_mode="HTML",
        reply_markup=main_menu(query.from_user.id)
    )


def panel_button_name(name):
    """Return the product name without adding a shopping-cart emoji."""
    return str(name or "").strip()


# ==================================================
# PRODUCTS MENU
# ==================================================

async def reseller_panel(query):
    user_id = query.from_user.id
    await query.answer()

    # Force reseller status from database
    activation = get_reseller_activation(user_id)

    if activation:
        try:
            if time.time() - float(activation) < RESELLER_VALIDITY:
                RESELLERS.add(str(user_id))
            else:
                RESELLERS.discard(str(user_id))
        except (TypeError, ValueError):
            RESELLERS.discard(str(user_id))
    else:
        RESELLERS.discard(str(user_id))

    # Always sync reseller status from database
    activation = get_reseller_activation(user_id)
    if activation:
        try:
            if time.time() - float(activation) < RESELLER_VALIDITY:
                RESELLERS.add(str(user_id))
        except (TypeError, ValueError):
            pass

    if not is_reseller_active(user_id):
        text = (
            "🤝 <b>RESELLER PANEL</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "🔴 <b>Reseller Not Active</b>\n\n"
            "Reseller activate करने के लिए ₹100 activation payment करें."
        )
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "💳 ACTIVATE ₹100",
                    callback_data="reseller:activate",
                    style="success"
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ HOME",
                    callback_data="home",
                    style="danger"
                )
            ]
        ])
    else:
        activated_at = get_reseller_activation(user_id)
        activated = (
            time.strftime("%d-%m-%Y", time.localtime(activated_at))
            if activated_at else "N/A"
        )

        text = (
            "🤝 <b>RESELLER PANEL</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "🟢 <b>Reseller Active</b>\n"
            f"📅 Activated: <b>{activated}</b>\n\n"
            f"💰 <b>Total Saved:</b> ₹{get_reseller_total_saved(user_id):.2f}"
        )

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🛍️ PRODUCT STORE",
                    callback_data="products",
                    style="primary"
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ HOME",
                    callback_data="home",
                    style="danger"
                )
            ]
        ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )

async def reseller_activation(query):
    await query.answer()

    user_id = query.from_user.id

    if is_reseller_active(user_id):
        await query.answer(
            "🟢 Reseller already active",
            show_alert=True
        )
        return

    await create_qr(query, 100, payment_type="reseller_activation")


async def products_menu(query):
    await query.answer(cache_time=1)

    text = (
        "🛒 <b>SELECT PRODUCT PANEL</b>\n\n"
        "🛡️ <b>Choose a panel to view its products:</b>"
    )

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🤖 ANDROID NON ROOT PANEL", callback_data="category:android_nonroot", style="primary")],
        [InlineKeyboardButton("🤖 ANDROID ROOT PANEL", callback_data="category:android_root", style="primary")],
        [InlineKeyboardButton("🍎 IPHONE PANEL", callback_data="category:iphone", style="primary")],
        [InlineKeyboardButton("💻 PC PANEL", callback_data="category:pc", style="primary")],
        [InlineKeyboardButton("↩️ BACK", callback_data="home", style="danger")],
    ])

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard
    )


async def category_menu(query, category_key):
    await query.answer()

    category = PRODUCTS.get(category_key)
    if not category:
        await query.answer("❌ Category not found", show_alert=True)
        return

    products = category.get("products", [])

    # Running products first, MAINTENANCE products at the bottom
    products_with_index = list(enumerate(products))
    products_with_index.sort(
        key=lambda item: "MAINTENANCE" in item[1].get("name", "").upper()
    )

    buttons = []

    for index, product in products_with_index:
        buttons.append([
            InlineKeyboardButton(
                panel_button_name(product["name"]),
                callback_data=f"product:{category_key}:{index}",
                style="primary"
            )
        ])

    if not buttons:
        buttons.append([
            InlineKeyboardButton(
                "⏳ COMING SOON",
                callback_data="home",
                style="primary"
            )
        ])

    buttons.append([
        InlineKeyboardButton(
            "↩️ BACK",
            callback_data="products",
            style="danger"
        )
    ])

    await query.edit_message_text(
        f"🛒 <b>{category['name']}</b>\n\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "🛡️ <b>SELECT PANEL</b>\n"
        "━━━━━━━━━━━━━━━━━━",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def product_details(query, category_key, index):
    await query.answer()

    category = PRODUCTS.get(category_key)

    if not category:
        return

    try:
        product = category["products"][int(index)]
    except (ValueError, IndexError):
        await query.answer("❌ Invalid product", show_alert=True)
        return

    buttons = []

    for package_index, package in enumerate(product.get("packages", [])):
        duration = package["duration"]
        retail_price = package["price"]
        pid = package.get("pid") or product.get("pid")

        if is_reseller_active(query.from_user.id):
            reseller_price = get_reseller_price(package, product)
            price = reseller_price if reseller_price is not None else retail_price
        else:
            price = retail_price

        stock = package.get("stock", True)

        if stock:
            buttons.append([
                InlineKeyboardButton(
                    f"🛒 BUY {duration.upper()} — ₹{price:.2f}",
                    callback_data=f"buy:{category_key}:{index}:{package_index}",
                    style="success"
                )
            ])
        else:
            buttons.append([
                InlineKeyboardButton(
                    f"⛔ OUT OF STOCK — {duration} — ₹{price:.2f}",
                    callback_data=f"buy:{category_key}:{index}:{package_index}",
                    style="danger"
                )
            ])

    buttons.append([
        InlineKeyboardButton(
            "↩️ BACK",
            callback_data=f"category:{category_key}",
            style="danger"
        )
    ])

    text = (
        f"🛒 <b>{category['name']} - {product['name']} PACKAGES</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
    )

    for package in product.get("packages", []):
        retail_price = float(package.get("price", 0))

        if is_reseller_active(query.from_user.id):
            reseller_price = get_reseller_price(package, product)
            display_price = reseller_price if reseller_price is not None else retail_price
        else:
            display_price = retail_price

        text += (
            f"\n🛒 ⏱️ <b>Validity: {package['duration']}</b>\n"
            f"💰 <b>Price: ₹{display_price:.2f}</b>\n"
            f"📱 <b>Limit: 1 Device</b> | 📦⚡ <b>Instant Delivery</b>\n"
        )

    text += (
        "\n🛡️ <b>Select package below to instantly purchase:</b>"
    )

    markup = InlineKeyboardMarkup(buttons)

    # Product Store pages may be photo messages.
    # Telegram requires edit_message_caption() for photo messages.
    if query.message and query.message.photo:
        await query.edit_message_caption(
            caption=text,
            parse_mode="HTML",
            reply_markup=markup
        )
    else:
        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=markup
        )


async def reseller_store_menu(query):
    await query.answer()
    buttons = []
    for key, category in PRODUCTS.items():
        buttons.append([InlineKeyboardButton(category["name"], callback_data=f"reseller:category:{key}", style="primary")])
    buttons.append([InlineKeyboardButton("↩️ BACK", callback_data="home", style="danger")])
    await query.edit_message_text("🤝 <b>RESELLER STORE</b>\n━━━━━━━━━━━━━━━━━━\n\n🛒 <b>Wholesale Price Store</b>\n\nनीचे panel चुनें:", parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

async def reseller_category_menu(query, category_key):
    await query.answer()
    if str(query.from_user.id) not in RESELLERS:
        await query.answer("❌ Reseller access नहीं है।", show_alert=True)
        return
    category = PRODUCTS.get(category_key)
    if not category:
        await query.answer("❌ Category not found", show_alert=True)
        return
    buttons = []
    for index, product in enumerate(category.get("products", [])):
        buttons.append([InlineKeyboardButton(product["name"], callback_data=f"reseller:product:{category_key}:{index}", style="primary")])
    buttons.append([InlineKeyboardButton("↩️ BACK", callback_data="reseller:store", style="danger")])
    await query.edit_message_text(f"🤝 <b>{category['name']}</b>\n━━━━━━━━━━━━━━━━━━\n\n🛒 <b>SELECT PRODUCT</b>", parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

async def reseller_product_details(query, category_key, index):
    await query.answer()
    if str(query.from_user.id) not in RESELLERS:
        await query.answer("❌ Reseller access नहीं है।", show_alert=True)
        return
    category = PRODUCTS.get(category_key)
    try:
        product = category["products"][int(index)]
    except (TypeError, ValueError, KeyError, IndexError):
        await query.answer("❌ Invalid product", show_alert=True)
        return
    buttons = []
    text = f"📦 <b>{category['name']} - {product['name']} PACKAGES</b>\n━━━━━━━━━━━━━━━━━━\n\n"
    for package_index, package in enumerate(product.get("packages", [])):
        rate = get_reseller_price(package, product)
        if rate is None:
            continue
        text += f"⏱️ <b>{package['duration']}</b> — ₹{rate:.2f}\n"
        buttons.append([InlineKeyboardButton(f"🛒 BUY {package['duration'].upper()} — ₹{rate:.2f}", callback_data=f"reseller:buy:{category_key}:{index}:{package_index}", style="success")])
    buttons.append([InlineKeyboardButton("↩️ BACK", callback_data=f"reseller:category:{category_key}", style="danger")])
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

async def reseller_buy_product(query, category_key, index, package_index):
    await query.answer("⏳ Order processing...")
    user_id = query.from_user.id

    if str(user_id) not in RESELLERS:
        await query.answer("❌ Reseller access नहीं है।", show_alert=True)
        return

    category = PRODUCTS.get(category_key)
    try:
        product = category["products"][int(index)]
        package = product["packages"][int(package_index)]
    except (TypeError, ValueError, KeyError, IndexError):
        await query.message.reply_text("❌ Invalid product/package.")
        return

    if package.get("stock", True) is False:
        await query.answer("❌ OUT OF STOCK", show_alert=True)
        return

    pid = package.get("pid") or product.get("pid")
    price = get_reseller_price(package, product)

    if price is None:
        await query.message.reply_text(
            "❌ Reseller Price available नहीं है.",
            parse_mode="HTML"
        )
        return

    price = float(price)
    balance = float(get_balance(user_id))

    if balance >= price:
        try:
            result = await panel_api_order(
                pid=pid,
                quantity=1,
                custom_notes=f"Reseller purchase {user_id}"
            )

            if not result or result.get("status") not in ("success", "SUCCESS", True):
                await query.message.reply_text(
                    "❌ Order failed.\n\n"
                    "Balance से कोई पैसा नहीं काटा गया।"
                )
                return

            license_key = result.get("license_key") or result.get("key")
            order_code = result.get("order_code") or result.get("order_id")

            if not license_key:
                await query.message.reply_text(
                    "❌ License key नहीं मिली.\n\n"
                    "Balance से कोई पैसा नहीं काटा गया।"
                )
                return

            remove_balance(user_id, price)

            try:
                save_wholesale_history(
                    user_id=user_id,
                    pid=pid,
                    duration=package.get("duration", ""),
                    wholesale_price=price,
                    product_name=product.get("name", ""),
                    license_key=license_key,
                    order_code=order_code,
                    user_price=float(
                        package.get("price", product.get("price", price))
                    ),
                )
            except Exception:
                logging.exception("RESELLER HISTORY SAVE ERROR")

            await query.message.reply_text(
                "🎉 <b>ORDER SUCCESSFUL</b>\n"
                "━━━━━━━━━━━━━━━━━━\n\n"
                f"📦 Product: <b>{product['name']}</b>\n"
                f"⏱️ Validity: <b>{package.get('duration', 'Package')}</b>\n"
                f"💰 Price: <b>₹{price:.2f}</b>\n"
                f"🔑 License Key: <code>{license_key}</code>\n"
                f"🆔 Order: <code>{order_code or 'N/A'}</code>\n\n"
                f"💳 Remaining Balance: <b>₹{get_balance(user_id):.2f}</b>",
                parse_mode="HTML"
            )
            return

        except Exception as e:
            logging.exception("RESELLER DIRECT ORDER ERROR: %s", e)
            await query.message.reply_text(
                "❌ Order processing में error आया.\n\n"
                "Balance से कोई पैसा नहीं काटा गया।"
            )
            return

    # Balance कम है — सिर्फ shortfall का QR बनेगा.
    shortfall = round(price - balance, 2)

    await create_purchase_qr(
        query=query,
        amount=shortfall,
        category_key=category_key,
        product_index=index,
        package_index=package_index,
        pid=pid,
        product_price=price,
        balance_to_use=balance,
        purchase_type="reseller_purchase",
    )


async def buy_product(query, category_key, index, package_index=None):
    await query.answer()

    category = PRODUCTS.get(category_key)
    if not category:
        await query.message.reply_text("❌ Product category नहीं मिली।")
        return

    products = category.get("products", [])

    try:
        index = int(index)
    except (TypeError, ValueError):
        await query.message.reply_text("❌ Invalid product.")
        return

    if index < 0 or index >= len(products):
        await query.message.reply_text("❌ Invalid product.")
        return

    product = products[index]
    packages = product.get("packages", [])

    if package_index is None:
        package_index = 0

    try:
        package_index = int(package_index)
    except (TypeError, ValueError):
        await query.message.reply_text("❌ Invalid package.")
        return

    if package_index < 0 or package_index >= len(packages):
        await query.message.reply_text("❌ Invalid package.")
        return

    package = packages[package_index]

    if package.get("stock", True) is False:
        await query.answer("❌ OUT OF STOCK", show_alert=True)
        return

    pid = package.get("pid") or product.get("pid")

    retail_price = float(
        package.get("price", product.get("price", 0))
    )

    user_id = query.from_user.id

    if is_reseller_active(user_id):
        reseller_price = get_reseller_price(package, product)
        price = float(reseller_price) if reseller_price is not None else retail_price
        purchase_type = "reseller_purchase"
    else:
        price = retail_price
        purchase_type = "purchase"

    if not pid:
        await query.message.reply_text(
            "⏳ <b>PRODUCT COMING SOON</b>\n\n"
            "इस product का PID अभी add नहीं किया गया है.\n\n"
            "PID मिलने के बाद automatic purchase और key delivery चालू हो जाएगी.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(
                    "↩️ HOME",
                    callback_data="home",
                    style="primary"
                )]
            ])
        )
        return

    if price <= 0:
        await query.message.reply_text("❌ Product price invalid है.")
        return

    balance = float(get_balance(user_id))

    # Full balance available — direct key.
    if balance >= price:
        try:
            result = await panel_api_order(
                pid=pid,
                quantity=1,
                custom_notes=f"Product purchase {user_id}"
            )

            if not result or result.get("status") not in ("success", "SUCCESS", True):
                await query.message.reply_text(
                    "❌ Order failed.\n\n"
                    "Balance से कोई पैसा नहीं काटा गया।"
                )
                return

            license_key = result.get("license_key") or result.get("key")
            order_code = result.get("order_code") or result.get("order_id")

            if not license_key:
                await query.message.reply_text(
                    "❌ License key नहीं मिली.\n\n"
                    "Balance से कोई पैसा नहीं काटा गया।"
                )
                return

            remove_balance(user_id, price)

            # Save successful purchase in History
            try:
                history_order_id = f"wallet_{user_id}_{pid}_{int(time.time() * 1000)}"
                conn = sqlite3.connect("keybot.db", timeout=30)
                conn.execute(
                    "INSERT INTO payment_transactions "
                    "(order_id,user_id,requested_amount,verified_amount,"
                    "payment_type,status,credited,product_price,balance_to_use,"
                    "category_key,product_index,package_index,product_pid,"
                    "license_key,order_code,product_name,duration,updated_at) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now','localtime'))",
                    (
                        history_order_id,
                        str(user_id),
                        float(price),
                        float(price),
                        purchase_type,
                        "SUCCESS",
                        1,
                        float(price),
                        float(price),
                        category_key,
                        int(index),
                        int(package_index),
                        int(pid),
                        str(license_key),
                        str(order_code or ""),
                        str(product.get("name", "")),
                        str(package.get("duration", "")),
                    ),
                )
                conn.commit()
                conn.close()
                logging.info("DIRECT PURCHASE HISTORY SAVED: %s", history_order_id)
            except Exception:
                logging.exception("DIRECT PURCHASE HISTORY SAVE ERROR")

            if purchase_type == "reseller_purchase":
                try:
                    save_wholesale_history(
                        user_id=user_id,
                        pid=pid,
                        duration=package.get("duration", ""),
                        wholesale_price=price,
                        product_name=product.get("name", ""),
                        license_key=license_key,
                        order_code=order_code,
                        user_price=float(
                            package.get("price", product.get("price", price))
                        ),
                    )
                except Exception:
                    logging.exception("RESELLER HISTORY SAVE ERROR")

            await query.message.reply_text(
                "🎉 <b>ORDER SUCCESSFUL</b>\n"
                "━━━━━━━━━━━━━━━━━━\n\n"
                f"📦 Product: <b>{product['name']}</b>\n"
                f"⏱️ Validity: <b>{package.get('duration', 'Package')}</b>\n"
                f"💰 Price: <b>₹{price:.2f}</b>\n"
                f"🔑 License Key: <code>{license_key}</code>\n"
                f"🆔 Order: <code>{order_code or 'N/A'}</code>\n\n"
                f"💳 Remaining Balance: <b>₹{get_balance(user_id):.2f}</b>",
                parse_mode="HTML"
            )
            return

        except Exception as e:
            logging.exception("DIRECT PRODUCT ORDER ERROR: %s", e)
            await query.message.reply_text(
                "❌ Order processing में error आया.\n\n"
                "Balance से कोई पैसा नहीं काटा गया।"
            )
            return

    # Balance कम है — सिर्फ बाकी amount का QR बनेगा.
    shortfall = round(price - balance, 2)

    await create_purchase_qr(
        query=query,
        amount=shortfall,
        category_key=category_key,
        product_index=index,
        package_index=package_index,
        pid=pid,
        product_price=price,
        balance_to_use=balance,
        purchase_type=purchase_type,
    )


